import type { Config } from "tailwindcss";

/**
 * Ntinginya Tech design tokens (V2.0: dark navy + green).
 * Every colour on the site comes from this file. Do not add one-off hex values in components.
 */
const config: Config = {
  content: ["./src/**/*.{ts,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        navy: { DEFAULT: "#001B3F", blue: "#1E3A8A" },
        ink: "#07121A", // dark page background
        card: "#102938", // card surface
        brand: { DEFAULT: "#00B981", light: "#34D399" },
        fg: { DEFAULT: "#F8FAFC", 2: "#CBD5E1", 3: "#94A3B8" }, // primary, secondary, muted text
        success: "#00B981",
        warning: "#F59E0B",
        danger: "#EF4444",
        info: "#38BDF8",
      },
      fontFamily: {
        sans: ["var(--font-inter)", "ui-sans-serif", "system-ui", "sans-serif"],
        serif: ["var(--font-inter)", "ui-sans-serif", "system-ui", "sans-serif"],
      },
      boxShadow: {
        card: "0 12px 32px -16px rgba(0, 0, 0, 0.6)",
        glow: "0 0 0 1px rgba(52, 211, 153, 0.28), 0 18px 44px -18px rgba(0, 185, 129, 0.35)",
      },
      keyframes: {
        "fade-up": {
          from: { opacity: "0", transform: "translateY(14px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
        "fade-in": { from: { opacity: "0" }, to: { opacity: "1" } },
      },
      animation: {
        "fade-up": "fade-up 0.6s cubic-bezier(0.2, 0.7, 0.2, 1) both",
        "fade-in": "fade-in 0.5s ease-out both",
      },
    },
  },
  plugins: [],
};

export default config;
