# Contact form setup (Resend + Netlify)

This page explains how the contact form sends email, what you must configure, and how to fix the usual problems.

## Why the form said "Sending from this page is not available right now"

That message was shown when the server answered HTTP 501, which the old code returned whenever **any one** of these three
settings was missing in the running Netlify site: `RESEND_API_KEY`, `CONTACT_TO_EMAIL`, `CONTACT_FROM_EMAIL`.
It was a configuration problem, not a code bug, and it cannot be seen from the website itself.

What changed in V2.0:

- Only `RESEND_API_KEY` is needed now. `CONTACT_TO_EMAIL` defaults to `ntinginyatech@gmail.com`, and
  `CONTACT_FROM_EMAIL` defaults to Resend's test sender (see "Sender" below).
- Every message is also saved in the database and appears in **Admin > Messages**, even if email fails.
- Each message shows whether its email notification was `sent`, `failed` or `not configured`.
- **Admin > Settings > Email delivery** shows which variables are set (never their values) and can send a real test email
  that reports exactly what Resend answered.

## How it works

1. A visitor submits the form. The browser sends it to `/api/contact` on your site (a Next.js Route Handler, which Netlify
   runs as a serverless function).
2. The server validates and cleans the input, checks the spam trap and the rate limit.
3. The server asks Resend to email the message to you. The API key is read only on the server.
4. The server saves the message in Supabase (if Supabase is configured).
5. The visitor sees "success" only if Resend accepted the email **or** the message was saved. Otherwise they see the
   "could not send" message with your email, phone and WhatsApp.

## What you need

| Variable | Required | Value |
| --- | --- | --- |
| `RESEND_API_KEY` | Yes | Create at resend.com > API Keys. Starts with `re_`. Server only. |
| `CONTACT_TO_EMAIL` | No | Defaults to `ntinginyatech@gmail.com`. |
| `CONTACT_FROM_EMAIL` | No, until you verify a domain | Example: `Ntinginya Tech <website@your-verified-domain>` |

Never add `NEXT_PUBLIC_` in front of `RESEND_API_KEY`. That would publish it to every visitor.

## Step by step

1. Go to https://resend.com and create an account. **Use `ntinginyatech@gmail.com` to sign up** (see "Sender" for why).
2. Open **API Keys > Create API Key**. Give it "Sending access". Copy it now, Resend shows it only once.
3. In Netlify open your site > **Site configuration > Environment variables > Add a variable**.
   Add `RESEND_API_KEY` with the key. Tick every scope (Builds, Functions, Runtime) and, if offered, mark it as a secret.
4. **Trigger a new deploy** (Deploys > Trigger deploy > Deploy site). Netlify applies new variables only to deploys made
   after you add them.
5. Sign in at `/admin`, open **Settings**, and press **Send a test email**. Then send a real message from the Contact page.

## Sender (the "from" address)

Resend will only send from an address on a domain you have verified, with one exception: the test sender
`onboarding@resend.dev`. The test sender needs no setup but has a strict rule: **Resend delivers those emails only to the
address that owns the Resend account.**

- With the default settings, messages reach `ntinginyatech@gmail.com` only if the Resend account was created with
  `ntinginyatech@gmail.com`.
- For a permanent setup, verify a domain: Resend > Domains > Add Domain, then add the DNS records Resend shows at
  your domain provider. When Resend shows the domain as verified, set `CONTACT_FROM_EMAIL` in Netlify, for example
  `Ntinginya Tech <website@your-domain>`, and redeploy.

This project does not include a verified domain because none has been connected yet.

## Common errors and fixes

| What you see | Cause | Fix |
| --- | --- | --- |
| Message appears in Admin > Messages with **email not configured** | `RESEND_API_KEY` is missing in the deployed site | Add it in Netlify, redeploy |
| **email failed** and the test email says "only send testing emails to your own email address" | Test sender in use, but the Resend account email differs from `CONTACT_TO_EMAIL` | Sign up to Resend with the same address, or verify a domain |
| Test email says the domain "is not verified" | `CONTACT_FROM_EMAIL` uses a domain Resend has not verified | Verify the domain in Resend, or clear `CONTACT_FROM_EMAIL` to use the test sender |
| HTTP 401 or "API key is invalid" | Wrong or revoked key | Create a new key in Resend and update Netlify |
| HTTP 422 / "Invalid `from` field" | Wrong format in `CONTACT_FROM_EMAIL` | Use `Name <address@your-domain>` |
| Email sent but not in the inbox | Gmail filtered it | Check Spam. Verifying a domain improves delivery |
| Visitors see "Please wait a few minutes" | The spam limit (5 messages per 10 minutes per visitor) | Wait, or use email or WhatsApp |
| Visitors see the "could not send" message and nothing is saved | Neither Resend nor Supabase is configured | Add `RESEND_API_KEY` and the Supabase variables |

To read the technical reason for a failure, open Netlify > **Logs > Functions** and look for lines starting with
`Email:` or `Contact form:`. Those lines never contain secrets.

## Testing checklist

1. Open the Contact page and try to send an empty form. You should see friendly validation messages.
2. Fill the form and send it. The button shows "Sending" and then the success message.
3. Check `ntinginyatech@gmail.com` (and Spam) for `[Website] ...`.
4. Open `/admin/messages`. The message is there, unread, with an email status.
5. Press **Reply via email**. Your email app opens with the visitor's address filled in.
6. Press **Mark as read**. The "unread" label disappears.
