# CMS and admin dashboard setup (for beginners)

After this setup you can sign in at `/admin` from your phone, write articles, upload images, publish them on
**News & Insights**, and read contact messages, without touching any code.

You need three free accounts: **Supabase** (database, sign-in, image storage), **Resend** (email) and **Netlify** (hosting, which you already use).
Allow about 45 minutes the first time.

Everything below was written against the project files, but it has not been run against your accounts. If a button is
named differently in Supabase or Netlify when you follow it, look for the closest match.

---

## 1. Create the Supabase project

1. Go to https://supabase.com and sign in (or create an account).
2. Press **New project**. Choose an organization, name it `ntinginya-tech`, choose a strong **database password** and save it
   in a password manager, and choose the region closest to your visitors.
3. Wait until the project has finished setting up.

## 2. Create the database

1. In Supabase open **SQL Editor > New query**.
2. Open the file `supabase/schema.sql` from this project, copy everything, paste it into the editor and press **Run**.
   It creates the tables, the security rules (Row Level Security), the image storage bucket named `media` and the eight starter categories.
   It is safe to run again.
3. Open **Table Editor**. You should see `posts`, `categories`, `media`, `contact_messages`, `site_settings`, `activity_logs` and more.

## 3. Configure sign-in (Authentication)

1. **Turn off public sign-up.** Authentication > Sign In / Providers (or "Providers" / "Settings"): switch **off**
   "Allow new users to sign up". This is important: it means nobody can register themselves. (You add people from the dashboard.)
2. **Site URL and redirect URL.** Authentication > URL Configuration:
   - Site URL: your website address, for example `https://your-site.netlify.app` (later your real domain).
   - Redirect URLs: add `https://your-site.netlify.app/admin/auth/confirm` (and the same path on your real domain later).
3. **Make password-reset links work on a phone (recommended).** Authentication > Email Templates > **Reset Password**.
   Replace the link in the template with:

   ```
   <a href="{{ .SiteURL }}/admin/auth/confirm?token_hash={{ .TokenHash }}&type=recovery&next=/admin/reset-password">Reset password</a>
   ```

   This style works even if you open the email in a different browser or app than the one you used to ask for it.
4. **Email limits.** Supabase's built-in email sender allows only a few emails per hour. For real use, add your own SMTP under
   Authentication > SMTP Settings. Resend offers SMTP (host `smtp.resend.com`, user `resend`, password your Resend API key), which needs a verified domain.

## 4. Check image storage

Storage > you should see a **public** bucket named `media` (created by `schema.sql`). Visitors can view images by link.
Only the website's server can upload or delete them.

## 5. Create your admin account

1. Authentication > Users > **Add user > Create new user**. Enter your email and a strong password (10+ characters). Tick **Auto Confirm User**.
2. Make yourself the owner. In **SQL Editor** run this, changing the email and name:

   ```sql
   insert into public.profiles (id, full_name, role, is_active)
   select id, 'Your Name', 'owner', true from auth.users where email = 'you@example.com'
   on conflict (id) do update set role = 'owner', is_active = true, full_name = excluded.full_name;
   ```

   Check that it worked: `select id, full_name, role from public.profiles;` shows your row with role `owner`.

Only accounts with the role `owner` or `admin` can open the dashboard. New users are created as `author`, which cannot sign in to the dashboard yet.

## 6. Get your Supabase keys

Project Settings > **API** (or "API Keys"):

| Netlify variable | Where it comes from | Secret? |
| --- | --- | --- |
| `NEXT_PUBLIC_SUPABASE_URL` | Project URL | No |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | The `anon` / public key | No (it is public by design) |
| `SUPABASE_SERVICE_ROLE_KEY` | The `service_role` key | **Yes. Never share it, never commit it, never prefix it with NEXT_PUBLIC_.** |

If your project shows the newer "publishable" and "secret" keys, look for a "Legacy API keys" tab and use its `anon` and
`service_role` keys, which is the setup this project was written for.

## 7. Set up Resend (email)

Follow `docs/CONTACT_FORM_SETUP.md`. In short: create a Resend account with `ntinginyatech@gmail.com`, create an API key, and add it as `RESEND_API_KEY`.

## 8. Add the variables in Netlify

Netlify > your site > **Site configuration > Environment variables > Add a variable**. Add:

```
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
RESEND_API_KEY=
CONTACT_TO_EMAIL=ntinginyatech@gmail.com
CONTACT_FROM_EMAIL=            (leave out until a domain is verified in Resend)
NEXT_PUBLIC_SITE_URL=          (your real domain, once it is connected)
```

Give each variable all scopes (Builds, Functions, Runtime). Mark the service role key and the Resend key as secrets.
The file `.env.example` in the project lists the same names with no values.

## 9. Deploy

Push the project to your Git repository (Netlify deploys it) or press **Deploys > Trigger deploy**.
Environment variables only apply to deploys made **after** you added them, so deploy again after any change.
Netlify runs `npm run build` (already set in `netlify.toml`).

## 10. Sign in

Open `https://your-site/admin`. You are sent to `/admin/login`. Sign in with the email and password from step 5.
If the login page lists missing configuration, add those variables in Netlify and deploy again.

The **Overview** page shows a warning if anything required is missing, and **Settings** shows the status of each variable.

## 11. Write and publish your first article (from a phone)

1. **Posts > New post**.
2. Type a title. The web address (slug) fills in by itself.
3. Write the article. Use the toolbar (it scrolls sideways on a phone) for headings, bold, links, lists, quotes, tables, code and images.
4. **Featured image > Choose image > Upload an image.** Pick a photo from your gallery or take one. It is shrunk before upload.
   Add a short description (alt text) for accessibility.
5. Choose a **category**, add tags, and (optionally) fill in the SEO fields.
6. Press **Save draft**. Drafts are not visible to visitors.
7. When ready, press **Publish**. Open `/news`: the article is there straight away. Its page is `/news/your-slug`.
8. To hide it again: **Unpublish** (back to draft) or **Archive**.

A ready-made test article is available: run `supabase/welcome-post.sql` in the SQL Editor to create
"Welcome to Ntinginya Tech News & Insights" as a **draft** in the category "Ntinginya Tech Updates". Then publish it from **Posts**.

## 12. Test the contact form

Follow the checklist at the end of `docs/CONTACT_FORM_SETUP.md`.

---

## Adding people later

Owner only: **Authors & users > Add a person**. Roles today: `owner` and `admin` can use the dashboard.
`editor` and `author` exist in the code and database for the future, but cannot sign in to the dashboard yet.

## Forgot your password

`/admin/login > Forgot your password?`. The reset link is emailed by Supabase (see step 3).
If email is not working, you can set a new password in Supabase: Authentication > Users > your user > Send password recovery, or reset it there.

## Good to know

- **Backups:** on Supabase's free plan you are responsible for exporting your data. Export regularly (Database > Backups or the SQL Editor).
- **Inactivity:** free Supabase projects may be paused after a period without activity. If `/news` or `/admin` stops working, check the project status in Supabase.
- **Security:** the dashboard checks your role on the server for every page and every action. Article HTML is cleaned before it is saved and again before it is shown.
- **Images:** JPEG, PNG and WebP only, up to 5 MB after shrinking. SVG and GIF are refused on purpose.
