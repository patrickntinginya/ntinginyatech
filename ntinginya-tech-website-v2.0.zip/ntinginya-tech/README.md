# Ntinginya Tech website (V2.0)

Next.js 15 (App Router), React 19, TypeScript, Tailwind CSS 3, Supabase (database, sign-in, storage), Resend (email), TipTap (article editor).

Two parts in one project:

- **Public website** (`src/app/(site)`): Home, About, Solutions, Products, Agriculture, Innovation, Masterclass, R&D, News & Insights, Contact, Privacy, Terms.
- **Admin dashboard / CMS** (`src/app/admin`): posts, categories, media, contact messages, users, SEO, settings, activity log.

## Read these first

- `docs/CMS_SETUP.md`: Supabase, Netlify and first article, step by step.
- `docs/CONTACT_FORM_SETUP.md`: Resend, sender rules, testing, common errors.

## Run locally

```bash
npm install
cp .env.example .env.local     # fill in the values you have
npm run dev                    # http://localhost:3000
```

The public site works without any variables (News shows an empty state). `/admin` and the contact form need the variables below.

Before every deploy:

```bash
npm run typecheck
npm run lint
npm run build
npm run start
```

## Environment variables

| Variable | Required | Notes |
| --- | --- | --- |
| `NEXT_PUBLIC_SITE_URL` | Recommended | Real domain. Falls back to Netlify's `URL`, then localhost. |
| `NEXT_PUBLIC_SUPABASE_URL` | For CMS | Public. |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | For CMS | Public by design. Row Level Security protects the data. |
| `SUPABASE_SERVICE_ROLE_KEY` | For CMS | **Server-only secret.** Never prefix with `NEXT_PUBLIC_`. |
| `RESEND_API_KEY` | For email | **Server-only secret.** |
| `CONTACT_TO_EMAIL` | No | Defaults to `ntinginyatech@gmail.com`. |
| `CONTACT_FROM_EMAIL` | No | Defaults to Resend's test sender until a domain is verified. |

## Structure

```
supabase/schema.sql          Tables, Row Level Security, storage bucket, starter categories
supabase/welcome-post.sql    Optional draft test article
docs/                        CMS_SETUP.md, CONTACT_FORM_SETUP.md
src/
  middleware.ts              Sends signed-out visitors from /admin to /admin/login
  app/
    layout.tsx               Fonts, global metadata (title/description from Settings)
    (site)/                  Public pages + header/footer
      news/, news/[slug]/    News & Insights (published posts only)
    admin/
      (auth)/                login, forgot-password, reset-password
      (panel)/               overview, posts, categories, media, messages, users, seo, settings, activity
      actions/               Server Actions (every one re-checks the user's role)
      auth/confirm/          Password-reset link handler
    api/contact/route.ts     Contact form: validate, email via Resend, save to database
    sitemap.ts robots.ts manifest.ts icon.svg apple-icon.tsx opengraph-image.tsx
  components/
    admin/                   Editor, media picker, forms, navigation
    news/ layout/ sections/ ui/ visuals/
  lib/
    auth.ts                  Roles and permissions (owner/admin now; editor/author prepared)
    admin-db.ts              The only way admin code gets a database client (checks permission first)
    cms/                     Queries, sanitizer, slugs, labels
    supabase/                Browser-safe, server and service-role clients
    email.ts                 Resend sending (server only)
  config/site.ts             Company facts and site URL
  content/                   Static page content (products, areas, research, etc.)
tailwind.config.ts, src/app/globals.css   Design tokens: dark navy + green
```

## Design system

All colours are tokens in `tailwind.config.ts`: deep navy `#001B3F`, navy blue `#1E3A8A`, green `#00B981` / `#34D399`, page background `#07121A`,
card `#102938`, text `#F8FAFC` / `#CBD5E1` / `#94A3B8`. Do not add one-off hex values in components.

## Security notes

- Row Level Security is on for every table. Visitors can read only published posts, categories, tags, settings and author names.
- Admin pages and actions verify the signed-in user and role on the server every time. The middleware is only a first gate.
- The service-role key and Resend key are read only in server code (`server-only` import).
- Article HTML is sanitized on save and again on render. Uploads are checked by file signature, size and type.
- Rate limits are in memory (per server instance). Add a shared store or bot protection if abuse grows.
- Privacy Policy and Terms have not been reviewed by a lawyer.

## Deploy on Netlify

Build settings are in `netlify.toml`. Add the environment variables, deploy, then follow `docs/CMS_SETUP.md`.
Google Fonts are downloaded at build time, so the build needs internet access (Netlify has it).
