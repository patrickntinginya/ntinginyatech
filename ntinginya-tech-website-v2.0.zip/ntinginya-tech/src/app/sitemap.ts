import type { MetadataRoute } from "next";
import { siteConfig } from "@/config/site";
import { products } from "@/content/products";
import { getPublishedSlugs } from "@/lib/cms/queries";

// Refreshed every 5 minutes, and immediately when a post is published or unpublished.
export const revalidate = 300;

const staticRoutes = [
  "/",
  "/about",
  "/solutions",
  "/products",
  "/agriculture",
  "/innovation",
  "/masterclass",
  "/research",
  "/news",
  "/contact",
  "/privacy",
  "/terms",
];

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const lastModified = new Date();
  const posts = await getPublishedSlugs(); // published posts only: drafts never appear here
  const entries: MetadataRoute.Sitemap = [
    ...staticRoutes.map((path) => ({
      url: `${siteConfig.url}${path === "/" ? "" : path}`,
      lastModified,
      changeFrequency: (path === "/" || path === "/news" ? "weekly" : "monthly") as "weekly" | "monthly",
      priority: path === "/" ? 1 : path === "/privacy" || path === "/terms" ? 0.2 : 0.8,
    })),
    ...products.map((p) => ({
      url: `${siteConfig.url}/products/${p.slug}`,
      lastModified,
      changeFrequency: "monthly" as const,
      priority: 0.6,
    })),
    ...posts.map((p) => ({
      url: `${siteConfig.url}/news/${p.slug}`,
      lastModified: new Date(p.updated_at),
      changeFrequency: "monthly" as const,
      priority: 0.7,
    })),
  ];
  return entries;
}
