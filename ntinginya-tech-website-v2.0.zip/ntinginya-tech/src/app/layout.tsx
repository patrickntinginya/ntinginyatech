import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import type { ReactNode } from "react";
import { siteConfig } from "@/config/site";
import { getSiteSettings } from "@/lib/settings";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

/** Defaults for every page. The owner can change the title and description in /admin/settings. */
export async function generateMetadata(): Promise<Metadata> {
  const s = await getSiteSettings();
  return {
    metadataBase: new URL(siteConfig.url),
    title: { default: s.defaultSeoTitle, template: `%s | ${s.siteTitle}` },
    description: s.defaultSeoDescription,
    applicationName: s.siteTitle,
    keywords: [
      "Ntinginya Tech",
      "Tanzania technology company",
      "software development Tanzania",
      "digital platforms",
      "agriculture technology",
      "livestock technology",
      "AgriTech innovation",
      "business software",
    ],
    // Each page sets its own canonical URL through buildMetadata(). Icons come from app/icon.svg and app/apple-icon.tsx.
    openGraph: {
      type: "website",
      siteName: s.siteTitle,
      title: s.defaultSeoTitle,
      description: s.defaultSeoDescription,
      url: "/",
    },
    twitter: { card: "summary_large_image", title: s.defaultSeoTitle, description: s.defaultSeoDescription },
    robots: { index: true, follow: true },
  };
}

export const viewport: Viewport = {
  themeColor: "#07121A",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={inter.variable}>
      <body>{children}</body>
    </html>
  );
}
