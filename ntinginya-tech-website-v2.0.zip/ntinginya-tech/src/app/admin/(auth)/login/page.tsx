import Link from "next/link";
import { SubmitButton } from "@/components/admin/SubmitButton";
import { Field, inputClass } from "@/components/admin/ui";
import { LogoMark } from "@/components/layout/Logo";
import { safeAdminPath } from "@/lib/auth";
import { configChecks, isSupabaseAdminConfigured } from "@/lib/env";
import { signInAction } from "../../actions/auth";

type SP = { error?: string; next?: string; notice?: string };

const MESSAGES: Record<string, string> = {
  invalid: "That email or password is not correct.",
  unauthorized: "That account is not allowed to use the dashboard.",
  rate: "Too many attempts. Please wait a few minutes and try again.",
  config: "The dashboard is not set up yet. See the list below.",
};

export default async function LoginPage({ searchParams }: { searchParams: Promise<SP> | SP }) {
  const sp = await searchParams;
  const next = safeAdminPath(sp.next);
  const error = sp.error ? MESSAGES[sp.error] : undefined;
  const missing = isSupabaseAdminConfigured() ? [] : configChecks().filter((c) => c.required && !c.ok && c.name.includes("SUPABASE"));

  return (
    <div className="card-surface p-6 sm:p-8">
      <div className="flex items-center gap-3">
        <LogoMark />
        <div>
          <h1 className="text-xl font-bold text-fg">Admin sign in</h1>
          <p className="text-sm text-fg-3">Ntinginya Tech dashboard</p>
        </div>
      </div>

      {error ? <p role="alert" className="mt-6 rounded-lg border border-danger/40 bg-danger/10 p-3 text-[0.9375rem] text-fg">{error}</p> : null}
      {sp.notice === "signed-out" ? <p role="status" className="mt-6 rounded-lg border border-brand/40 bg-brand/10 p-3 text-[0.9375rem] text-fg">You have signed out.</p> : null}
      {missing.length > 0 ? (
        <div className="mt-6 rounded-lg border border-warning/40 bg-warning/10 p-3 text-sm text-fg">
          <p className="font-semibold">Missing configuration on the server:</p>
          <ul className="mt-1 list-disc pl-5">{missing.map((m) => <li key={m.name}>{m.name}</li>)}</ul>
          <p className="mt-2">Add them in the Netlify environment and redeploy. See docs/CMS_SETUP.md.</p>
        </div>
      ) : null}

      <form action={signInAction} className="mt-6 space-y-5">
        <input type="hidden" name="next" value={next} />
        <Field label="Email" htmlFor="email">
          <input id="email" name="email" type="email" required autoComplete="username" inputMode="email" className={inputClass} />
        </Field>
        <Field label="Password" htmlFor="password">
          <input id="password" name="password" type="password" required autoComplete="current-password" className={inputClass} />
        </Field>
        <SubmitButton size="lg" className="w-full" pendingLabel="Signing in…">Sign in</SubmitButton>
      </form>

      <div className="mt-6 flex flex-wrap justify-between gap-3 text-sm">
        <Link href="/admin/forgot-password" className="text-brand-light underline underline-offset-4">Forgot your password?</Link>
        <Link href="/" className="text-fg-2 underline underline-offset-4">Back to the website</Link>
      </div>
    </div>
  );
}
