import Link from "next/link";
import { redirect } from "next/navigation";
import { SubmitButton } from "@/components/admin/SubmitButton";
import { Field, inputClass } from "@/components/admin/ui";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { resetPasswordAction } from "../../actions/auth";

type SP = { error?: string };
const MESSAGES: Record<string, string> = {
  weak: "Use a password of at least 10 characters.",
  mismatch: "The two passwords do not match.",
  failed: "The password could not be changed. Please try again.",
};

export default async function ResetPasswordPage({ searchParams }: { searchParams: Promise<SP> | SP }) {
  const sp = await searchParams;
  // Only someone who opened a valid reset link (or is signed in) can be here.
  const supabase = await createSupabaseServerClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/admin/forgot-password?error=expired");

  return (
    <div className="card-surface p-6 sm:p-8">
      <h1 className="text-xl font-bold text-fg">Choose a new password</h1>
      {sp.error && MESSAGES[sp.error] ? <p role="alert" className="mt-4 rounded-lg border border-danger/40 bg-danger/10 p-3 text-[0.9375rem] text-fg">{MESSAGES[sp.error]}</p> : null}
      <form action={resetPasswordAction} className="mt-6 space-y-5">
        <Field label="New password" htmlFor="password" hint="At least 10 characters.">
          <input id="password" name="password" type="password" required minLength={10} maxLength={72} autoComplete="new-password" className={inputClass} />
        </Field>
        <Field label="Repeat the new password" htmlFor="confirm">
          <input id="confirm" name="confirm" type="password" required minLength={10} maxLength={72} autoComplete="new-password" className={inputClass} />
        </Field>
        <SubmitButton size="lg" className="w-full" pendingLabel="Saving…">Save password</SubmitButton>
      </form>
      <p className="mt-6 text-sm"><Link href="/admin/login" className="text-brand-light underline underline-offset-4">Back to sign in</Link></p>
    </div>
  );
}
