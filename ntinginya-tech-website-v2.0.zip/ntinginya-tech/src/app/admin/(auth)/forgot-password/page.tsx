import Link from "next/link";
import { SubmitButton } from "@/components/admin/SubmitButton";
import { Field, inputClass } from "@/components/admin/ui";
import { forgotPasswordAction } from "../../actions/auth";

type SP = { sent?: string; error?: string };

export default async function ForgotPasswordPage({ searchParams }: { searchParams: Promise<SP> | SP }) {
  const sp = await searchParams;
  return (
    <div className="card-surface p-6 sm:p-8">
      <h1 className="text-xl font-bold text-fg">Reset your password</h1>
      {sp.sent ? (
        <p role="status" className="mt-4 rounded-lg border border-brand/40 bg-brand/10 p-3 text-[0.9375rem] text-fg">
          If that email belongs to an account, a reset link is on its way. Open it on this phone or computer. It expires after a short time.
        </p>
      ) : (
        <>
          {sp.error === "expired" ? <p role="alert" className="mt-4 rounded-lg border border-danger/40 bg-danger/10 p-3 text-[0.9375rem] text-fg">That reset link has expired or was already used. Request a new one.</p> : null}
          {sp.error === "rate" ? <p role="alert" className="mt-4 rounded-lg border border-danger/40 bg-danger/10 p-3 text-[0.9375rem] text-fg">Too many requests. Please wait a few minutes.</p> : null}
          <p className="mt-2 text-[0.9375rem] text-fg-2">Enter your account email and we will send you a link to choose a new password.</p>
          <form action={forgotPasswordAction} className="mt-6 space-y-5">
            <Field label="Email" htmlFor="email">
              <input id="email" name="email" type="email" required autoComplete="email" inputMode="email" className={inputClass} />
            </Field>
            <SubmitButton size="lg" className="w-full" pendingLabel="Sending…">Send reset link</SubmitButton>
          </form>
        </>
      )}
      <p className="mt-6 text-sm"><Link href="/admin/login" className="text-brand-light underline underline-offset-4">Back to sign in</Link></p>
    </div>
  );
}
