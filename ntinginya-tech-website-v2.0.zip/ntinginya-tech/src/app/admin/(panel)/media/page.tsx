/* eslint-disable @next/next/no-img-element */
import { CopyButton } from "@/components/admin/CopyButton";
import { MediaUploader } from "@/components/admin/MediaUploader";
import { SubmitButton } from "@/components/admin/SubmitButton";
import { Empty, Notice, PageHeader, Pager, Panel, inputClass } from "@/components/admin/ui";
import { buttonStyles } from "@/components/ui/Button";
import { listMediaItems } from "@/lib/cms/admin-queries";
import { formatBytes, formatDate } from "@/lib/format";
import { deleteMediaAction } from "../../actions/media";

type SP = { q?: string; page?: string; notice?: string; error?: string };
const SIZE = 24;

export default async function MediaPage({ searchParams }: { searchParams: Promise<SP> | SP }) {
  const sp = await searchParams;
  const q = (sp.q ?? "").trim().slice(0, 80);
  const page = Math.max(1, Number.parseInt(sp.page ?? "1", 10) || 1);
  const { rows, total } = await listMediaItems({ q, page, limit: SIZE });
  const hrefFor = (n: number) => `/admin/media?${new URLSearchParams({ ...(q ? { q } : {}), ...(n > 1 ? { page: String(n) } : {}) }).toString()}`;

  return (
    <>
      <PageHeader title="Media library" description="Images for your articles. Upload from your phone camera or gallery." />
      <Notice notice={sp.notice} error={sp.error} />

      <Panel title="Upload an image">
        <MediaUploader />
      </Panel>

      <form action="/admin/media" method="get" role="search" className="mt-8 flex max-w-md gap-2">
        <label htmlFor="q" className="sr-only">
          Search images
        </label>
        <input id="q" name="q" type="search" defaultValue={q} maxLength={80} placeholder="Search images" className={inputClass} />
        <button type="submit" className={buttonStyles({ variant: "secondary" })}>
          Search
        </button>
      </form>

      <div className="mt-6">
        {rows.length === 0 ? (
          <Empty>{q ? "No images match your search." : "No images yet. Upload your first image above."}</Empty>
        ) : (
          <ul className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
            {rows.map((m) => (
              <li key={m.id} className="card-surface overflow-hidden">
                <img src={m.url} alt={m.alt ?? ""} loading="lazy" className="aspect-[4/3] w-full object-cover" />
                <div className="p-4">
                  <p className="truncate font-semibold text-fg">{m.filename}</p>
                  <p className="mt-0.5 text-sm text-fg-3">
                    {formatBytes(m.size_bytes)}
                    {m.width && m.height ? ` · ${m.width}×${m.height}` : ""} · {formatDate(m.created_at)}
                  </p>
                  {m.alt ? <p className="mt-1 text-sm text-fg-2">{m.alt}</p> : <p className="mt-1 text-sm text-warning">No description (alt text)</p>}
                  <div className="mt-3 flex flex-wrap gap-2">
                    <CopyButton value={m.url} label="Copy link" />
                    <form action={deleteMediaAction}>
                      <input type="hidden" name="id" value={m.id} />
                      <SubmitButton variant="danger" confirm="Delete this image? Articles that use it will lose the picture.">
                        Delete
                      </SubmitButton>
                    </form>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      <Pager page={page} total={total} size={SIZE} hrefFor={hrefFor} />
    </>
  );
}
