import { SubmitButton } from "@/components/admin/SubmitButton";
import { Field, Notice, PageHeader, Panel, inputClass } from "@/components/admin/ui";
import { listAdminCategories } from "@/lib/cms/admin-queries";
import { deleteCategoryAction, saveCategoryAction } from "../../actions/categories";

type SP = { notice?: string; error?: string };

export default async function CategoriesPage({ searchParams }: { searchParams: Promise<SP> | SP }) {
  const sp = await searchParams;
  const categories = await listAdminCategories();

  return (
    <>
      <PageHeader title="Categories" description="Group articles on News & Insights. Deleting a category never deletes its posts." />
      <Notice notice={sp.notice} error={sp.error} />

      <Panel title="Add a category">
        <form action={saveCategoryAction} className="grid gap-4 sm:grid-cols-2">
          <Field label="Name" htmlFor="new-name">
            <input id="new-name" name="name" required minLength={2} maxLength={80} className={inputClass} />
          </Field>
          <Field label="Web address (slug)" htmlFor="new-slug" hint="Optional. Made from the name when empty.">
            <input id="new-slug" name="slug" maxLength={80} className={inputClass} />
          </Field>
          <div className="sm:col-span-2">
            <Field label="Description" htmlFor="new-description">
              <input id="new-description" name="description" maxLength={300} className={inputClass} />
            </Field>
          </div>
          <div className="sm:col-span-2">
            <SubmitButton pendingLabel="Adding…">Add category</SubmitButton>
          </div>
        </form>
      </Panel>

      <ul className="mt-6 space-y-4">
        {categories.map((c) => (
          <li key={c.id}>
            <Panel>
              <form action={saveCategoryAction} className="grid gap-4 sm:grid-cols-2">
                <input type="hidden" name="id" value={c.id} />
                <Field label="Name" htmlFor={`name-${c.id}`}>
                  <input id={`name-${c.id}`} name="name" required minLength={2} maxLength={80} defaultValue={c.name} className={inputClass} />
                </Field>
                <Field label="Web address (slug)" htmlFor={`slug-${c.id}`}>
                  <input id={`slug-${c.id}`} name="slug" maxLength={80} defaultValue={c.slug} className={inputClass} />
                </Field>
                <div className="sm:col-span-2">
                  <Field label="Description" htmlFor={`desc-${c.id}`}>
                    <input id={`desc-${c.id}`} name="description" maxLength={300} defaultValue={c.description ?? ""} className={inputClass} />
                  </Field>
                </div>
                <div className="flex flex-wrap items-center gap-2 sm:col-span-2">
                  <SubmitButton variant="tech" pendingLabel="Saving…">Save</SubmitButton>
                  <span className="text-sm text-fg-3">{c.posts} {c.posts === 1 ? "post" : "posts"}</span>
                </div>
              </form>
              <form action={deleteCategoryAction} className="mt-3 border-t border-fg-3/15 pt-3">
                <input type="hidden" name="id" value={c.id} />
                <SubmitButton variant="danger" confirm={`Delete the category "${c.name}"? Its posts will stay, without a category.`}>
                  Delete category
                </SubmitButton>
              </form>
            </Panel>
          </li>
        ))}
      </ul>
    </>
  );
}
