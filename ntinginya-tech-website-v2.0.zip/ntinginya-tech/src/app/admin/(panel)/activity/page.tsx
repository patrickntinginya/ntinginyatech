import { Empty, PageHeader, Pager, Panel } from "@/components/admin/ui";
import { listActivity } from "@/lib/cms/admin-queries";
import { activityLabel } from "@/lib/cms/labels";
import { formatDateTime } from "@/lib/format";

export default async function ActivityPage({ searchParams }: { searchParams: Promise<{ page?: string }> | { page?: string } }) {
  const sp = await searchParams;
  const page = Math.max(1, Number.parseInt(sp.page ?? "1", 10) || 1);
  const { rows, total } = await listActivity(page);

  return (
    <>
      <PageHeader title="Activity" description="A record of who did what. Entries cannot be edited from the dashboard." />
      {rows.length === 0 ? (
        <Empty>Nothing has been recorded yet.</Empty>
      ) : (
        <Panel>
          <ul className="divide-y divide-fg-3/15">
            {rows.map((a) => (
              <li key={a.id} className="flex flex-col gap-0.5 py-3 sm:flex-row sm:items-center sm:justify-between sm:gap-6">
                <p className="min-w-0 text-[0.9375rem] text-fg">
                  <span className="font-semibold">{a.user_label ?? "System"}</span> · {activityLabel(a.action)}
                  {a.target_label ? <span className="break-words text-fg-2">: {a.target_label}</span> : null}
                </p>
                <p className="shrink-0 text-sm text-fg-3">{formatDateTime(a.created_at)}</p>
              </li>
            ))}
          </ul>
        </Panel>
      )}
      <Pager page={page} total={total} size={50} hrefFor={(n) => (n > 1 ? `/admin/activity?page=${n}` : "/admin/activity")} />
    </>
  );
}
