import { PostEditor } from "@/components/admin/PostEditor";
import { PageHeader } from "@/components/admin/ui";
import { siteConfig } from "@/config/site";
import { requireStaff } from "@/lib/auth";
import { listAdminCategories, listAuthors } from "@/lib/cms/admin-queries";

export default async function NewPostPage() {
  const staff = await requireStaff("posts:write");
  const [categories, authors] = await Promise.all([listAdminCategories(), listAuthors()]);

  return (
    <>
      <PageHeader title="New post" description="Save it as a draft first, or publish straight away. Drafts are never visible to visitors." />
      <PostEditor categories={categories} authors={authors} currentUserId={staff.id} siteUrl={siteConfig.url} />
    </>
  );
}
