import { notFound } from "next/navigation";
import { PostEditor } from "@/components/admin/PostEditor";
import { SubmitButton } from "@/components/admin/SubmitButton";
import { Notice, PageHeader, Panel } from "@/components/admin/ui";
import { siteConfig } from "@/config/site";
import { requireStaff } from "@/lib/auth";
import { getAdminPost, listAdminCategories, listAuthors } from "@/lib/cms/admin-queries";
import { deletePostAction } from "../../../../actions/posts";

type Props = { params: Promise<{ id: string }> | { id: string }; searchParams: Promise<{ notice?: string; error?: string }> | { notice?: string; error?: string } };

export default async function EditPostPage({ params, searchParams }: Props) {
  const staff = await requireStaff("posts:write");
  const { id } = await params;
  const sp = await searchParams;

  // Malformed ids are treated as "not found" instead of reaching the database.
  if (!/^[0-9a-f-]{36}$/i.test(id)) notFound();
  const post = await getAdminPost(id);
  if (!post) notFound();
  const [categories, authors] = await Promise.all([listAdminCategories(), listAuthors()]);

  return (
    <>
      <PageHeader title="Edit post" description={post.title} />
      <Notice notice={sp.notice} error={sp.error} />
      <PostEditor key={post.id} post={post} categories={categories} authors={authors} currentUserId={staff.id} siteUrl={siteConfig.url} />

      <Panel title="Delete this post" className="mt-10">
        <p className="mb-4 text-[0.9375rem] text-fg-2">Deleting removes the post for good. If you only want to hide it, use Unpublish or Archive instead.</p>
        <form action={deletePostAction}>
          <input type="hidden" name="id" value={post.id} />
          <SubmitButton variant="danger" confirm="Delete this post permanently? This cannot be undone.">
            Delete post
          </SubmitButton>
        </form>
      </Panel>
    </>
  );
}
