import Link from "next/link";
import { ExternalLink, FilePlus2, Search } from "lucide-react";
import { SubmitButton } from "@/components/admin/SubmitButton";
import { Empty, Notice, PageHeader, Pager, Panel, StatusPill, inputClass } from "@/components/admin/ui";
import { buttonStyles } from "@/components/ui/Button";
import { ADMIN_PAGE_SIZE, listAdminPosts } from "@/lib/cms/admin-queries";
import { formatDateTime } from "@/lib/format";
import { cn } from "@/lib/cn";
import { deletePostAction, setPostStatusAction } from "../../actions/posts";

type SP = { q?: string; status?: string; page?: string; notice?: string; error?: string };

const TABS = [
  { value: "", label: "All" },
  { value: "draft", label: "Drafts" },
  { value: "published", label: "Published" },
  { value: "archived", label: "Archived" },
];

function href(q: string, status: string, page = 1) {
  const sp = new URLSearchParams();
  if (q) sp.set("q", q);
  if (status) sp.set("status", status);
  if (page > 1) sp.set("page", String(page));
  const qs = sp.toString();
  return qs ? `/admin/posts?${qs}` : "/admin/posts";
}

function StatusForm({ id, to, children, confirm }: { id: string; to: string; children: string; confirm?: string }) {
  return (
    <form action={setPostStatusAction}>
      <input type="hidden" name="id" value={id} />
      <input type="hidden" name="to" value={to} />
      <SubmitButton variant="secondary" confirm={confirm}>
        {children}
      </SubmitButton>
    </form>
  );
}

export default async function PostsPage({ searchParams }: { searchParams: Promise<SP> | SP }) {
  const sp = await searchParams;
  const q = (sp.q ?? "").trim().slice(0, 80);
  const status = ["draft", "published", "archived"].includes(sp.status ?? "") ? (sp.status as string) : "";
  const page = Math.max(1, Number.parseInt(sp.page ?? "1", 10) || 1);
  const { rows, total } = await listAdminPosts({ q, status, page });

  return (
    <>
      <PageHeader
        title="Posts"
        description="Write, publish and manage News & Insights articles."
        actions={
          <Link href="/admin/posts/new" className={buttonStyles({ variant: "primary", className: "gap-2" })}>
            <FilePlus2 aria-hidden="true" className="h-4 w-4" />
            New post
          </Link>
        }
      />
      <Notice notice={sp.notice} error={sp.error} />

      <div className="mb-6 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <nav aria-label="Filter by status">
          <ul className="flex flex-wrap gap-2">
            {TABS.map((t) => (
              <li key={t.value}>
                <Link
                  href={href(q, t.value)}
                  aria-current={status === t.value ? "page" : undefined}
                  className={cn(
                    "inline-flex min-h-11 items-center rounded-full border px-4 text-sm font-semibold",
                    status === t.value ? "border-brand bg-brand/15 text-brand-light" : "border-fg-3/30 text-fg-2 hover:border-brand-light hover:text-fg",
                  )}
                >
                  {t.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        <form action="/admin/posts" method="get" role="search" className="flex w-full max-w-md gap-2">
          {status ? <input type="hidden" name="status" value={status} /> : null}
          <label htmlFor="q" className="sr-only">
            Search posts
          </label>
          <input id="q" name="q" type="search" defaultValue={q} maxLength={80} placeholder="Search by title or slug" className={inputClass} />
          <button type="submit" className={buttonStyles({ variant: "secondary", className: "gap-2" })}>
            <Search aria-hidden="true" className="h-4 w-4" />
            Search
          </button>
        </form>
      </div>

      {rows.length === 0 ? (
        <Empty>
          {q || status ? "No posts match. Try a different filter." : "No posts yet. Press New post to write your first article."}
        </Empty>
      ) : (
        <ul className="space-y-4">
          {rows.map((p) => (
            <li key={p.id}>
              <Panel>
                <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <StatusPill status={p.status} />
                      {p.category ? <span className="text-sm text-fg-3">{p.category.name}</span> : null}
                    </div>
                    <h2 className="mt-2 text-lg font-semibold leading-snug text-fg">
                      <Link href={`/admin/posts/${p.id}/edit`} className="hover:text-brand-light">
                        {p.title}
                      </Link>
                    </h2>
                    <p className="mt-1 break-all text-sm text-fg-3">/news/{p.slug}</p>
                    <p className="mt-1 text-sm text-fg-3">
                      Updated {formatDateTime(p.updated_at)}
                      {p.author?.full_name ? ` · ${p.author.full_name}` : ""}
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <Link href={`/admin/posts/${p.id}/edit`} className={buttonStyles({ variant: "tech" })}>
                      Edit
                    </Link>
                    {p.status === "published" ? (
                      <Link href={`/news/${p.slug}`} target="_blank" rel="noopener" className={buttonStyles({ variant: "secondary", className: "gap-1.5" })}>
                        View
                        <ExternalLink aria-hidden="true" className="h-4 w-4" />
                        <span className="sr-only">(opens in a new tab)</span>
                      </Link>
                    ) : null}
                    {p.status === "published" ? (
                      <StatusForm id={p.id} to="draft" confirm="Unpublish this article? It will disappear from the website.">
                        Unpublish
                      </StatusForm>
                    ) : (
                      <StatusForm id={p.id} to="published">
                        Publish
                      </StatusForm>
                    )}
                    {p.status !== "archived" ? (
                      <StatusForm id={p.id} to="archived" confirm="Archive this article? It will not be public.">
                        Archive
                      </StatusForm>
                    ) : null}
                    <form action={deletePostAction}>
                      <input type="hidden" name="id" value={p.id} />
                      <SubmitButton variant="danger" confirm="Delete this post permanently? This cannot be undone.">
                        Delete
                      </SubmitButton>
                    </form>
                  </div>
                </div>
              </Panel>
            </li>
          ))}
        </ul>
      )}

      <Pager page={page} total={total} size={ADMIN_PAGE_SIZE} hrefFor={(n) => href(q, status, n)} />
    </>
  );
}
