import Link from "next/link";
import { AlertTriangle, FilePlus2, Inbox } from "lucide-react";
import { Empty, Notice, PageHeader, Panel, StatusPill } from "@/components/admin/ui";
import { buttonStyles } from "@/components/ui/Button";
import { requireStaff } from "@/lib/auth";
import { getDashboard } from "@/lib/cms/admin-queries";
import { activityLabel } from "@/lib/cms/labels";
import { emailRouting } from "@/lib/email";
import { configChecks } from "@/lib/env";
import { formatDateTime } from "@/lib/format";

type SP = { notice?: string; error?: string };

function Stat({ label, value, note }: { label: string; value: number; note?: string }) {
  return (
    <div className="card-surface p-5">
      <p className="text-sm font-medium text-fg-2">{label}</p>
      <p className="mt-1 text-3xl font-bold tracking-tight text-fg">{value}</p>
      {note ? <p className="mt-1 text-sm text-fg-3">{note}</p> : null}
    </div>
  );
}

export default async function OverviewPage({ searchParams }: { searchParams: Promise<SP> | SP }) {
  const staff = await requireStaff();
  const sp = await searchParams;
  const { counts, recentPosts, recentMessages, recentActivity } = await getDashboard();

  const missing = configChecks().filter((c) => c.required && !c.ok);
  const routing = emailRouting();
  const emailReady = !missing.some((m) => m.name === "RESEND_API_KEY");

  return (
    <>
      <PageHeader
        title={`Welcome, ${staff.fullName.split(" ")[0]}`}
        description="Everything here comes from your live database."
        actions={
          <Link href="/admin/posts/new" className={buttonStyles({ variant: "primary", className: "gap-2" })}>
            <FilePlus2 aria-hidden="true" className="h-4 w-4" />
            New post
          </Link>
        }
      />
      <Notice notice={sp.notice} error={sp.error} />

      {missing.length > 0 ? (
        <div role="alert" className="mb-6 flex gap-3 rounded-xl border border-warning/40 bg-warning/10 p-4 text-[0.9375rem] text-fg">
          <AlertTriangle aria-hidden="true" className="mt-0.5 h-5 w-5 shrink-0 text-warning" />
          <div>
            <p className="font-semibold">Setup is incomplete</p>
            <p className="mt-1 text-fg-2">
              {emailReady
                ? "Some required settings are missing:"
                : "Contact form emails are NOT being sent until RESEND_API_KEY is added in Netlify. Messages are still saved in your inbox here. Missing:"}{" "}
              {missing.map((m) => m.name).join(", ")}. See docs/CONTACT_FORM_SETUP.md.
            </p>
          </div>
        </div>
      ) : routing.usingTestSender ? (
        <div className="mb-6 rounded-xl border border-info/40 bg-info/10 p-4 text-[0.9375rem] text-fg-2">
          Contact emails use Resend&apos;s test sender. That works only while the Resend account belongs to {routing.to}. Verify a domain in Resend to remove this limit.
        </div>
      ) : null}

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-3 xl:grid-cols-5">
        <Stat label="Total posts" value={counts.posts} note={counts.archived ? `${counts.archived} archived` : undefined} />
        <Stat label="Published" value={counts.published} />
        <Stat label="Drafts" value={counts.drafts} />
        <Stat label="Categories" value={counts.categories} />
        <Stat label="Messages" value={counts.messages} note={counts.unread ? `${counts.unread} unread` : "None unread"} />
      </div>

      <div className="mt-8 grid gap-6 xl:grid-cols-2">
        <Panel title="Recent posts">
          {recentPosts.length === 0 ? (
            <Empty>No posts yet. Write the first one.</Empty>
          ) : (
            <ul className="divide-y divide-fg-3/15">
              {recentPosts.map((p) => (
                <li key={p.id} className="flex items-center justify-between gap-3 py-3">
                  <div className="min-w-0">
                    <Link href={`/admin/posts/${p.id}/edit`} className="block truncate font-semibold text-fg hover:text-brand-light">
                      {p.title}
                    </Link>
                    <p className="text-sm text-fg-3">Updated {formatDateTime(p.updated_at)}</p>
                  </div>
                  <StatusPill status={p.status} />
                </li>
              ))}
            </ul>
          )}
        </Panel>

        <Panel title="Recent messages">
          {recentMessages.length === 0 ? (
            <Empty>No contact messages yet.</Empty>
          ) : (
            <ul className="divide-y divide-fg-3/15">
              {recentMessages.map((m) => (
                <li key={m.id} className="flex items-center justify-between gap-3 py-3">
                  <div className="min-w-0">
                    <Link href="/admin/messages" className="block truncate font-semibold text-fg hover:text-brand-light">
                      {m.subject}
                    </Link>
                    <p className="truncate text-sm text-fg-3">
                      {m.name} · {formatDateTime(m.created_at)}
                    </p>
                  </div>
                  <StatusPill status={m.status} />
                </li>
              ))}
            </ul>
          )}
          <Link href="/admin/messages" className={buttonStyles({ variant: "secondary", className: "mt-4 gap-2" })}>
            <Inbox aria-hidden="true" className="h-4 w-4" />
            Open inbox
          </Link>
        </Panel>

        <Panel title="Recent activity" className="xl:col-span-2">
          {recentActivity.length === 0 ? (
            <Empty>Nothing has happened yet.</Empty>
          ) : (
            <ul className="divide-y divide-fg-3/15">
              {recentActivity.map((a) => (
                <li key={a.id} className="flex flex-col gap-0.5 py-3 sm:flex-row sm:items-center sm:justify-between">
                  <p className="text-[0.9375rem] text-fg">
                    <span className="font-semibold">{a.user_label ?? "System"}</span> · {activityLabel(a.action)}
                    {a.target_label ? <span className="text-fg-2">: {a.target_label}</span> : null}
                  </p>
                  <p className="text-sm text-fg-3">{formatDateTime(a.created_at)}</p>
                </li>
              ))}
            </ul>
          )}
          <Link href="/admin/activity" className="mt-4 inline-block text-sm font-semibold text-brand-light underline underline-offset-4">
            See all activity
          </Link>
        </Panel>
      </div>
    </>
  );
}
