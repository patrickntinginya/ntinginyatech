import { SubmitButton } from "@/components/admin/SubmitButton";
import { Field, Notice, PageHeader, Panel, StatusPill, inputClass } from "@/components/admin/ui";
import { requireStaff } from "@/lib/auth";
import { listUsers } from "@/lib/cms/admin-queries";
import { formatDate } from "@/lib/format";
import { createUserAction, setUserActiveAction, setUserRoleAction } from "../../actions/users";

type SP = { notice?: string; error?: string };

const ROLE_HELP: Record<string, string> = {
  owner: "Full control, including users.",
  admin: "Can use the whole dashboard except managing users.",
  editor: "Prepared for the future. Cannot open the dashboard yet.",
  author: "Prepared for the future. Cannot open the dashboard yet.",
};

export default async function UsersPage({ searchParams }: { searchParams: Promise<SP> | SP }) {
  const staff = await requireStaff("users:manage"); // owners only
  const sp = await searchParams;
  const users = await listUsers();

  return (
    <>
      <PageHeader
        title="Authors and users"
        description="Only the owner can add people. There is no public sign-up, so nobody can register themselves."
      />
      <Notice notice={sp.notice} error={sp.error} />

      <Panel title="People with an account">
        <ul className="divide-y divide-fg-3/15">
          {users.map((u) => {
            const locked = u.role === "owner" || u.id === staff.id;
            return (
              <li key={u.id} className="flex flex-col gap-3 py-4 lg:flex-row lg:items-center lg:justify-between">
                <div className="min-w-0">
                  <p className="font-semibold text-fg">{u.full_name || u.email}</p>
                  <p className="break-all text-sm text-fg-3">{u.email}</p>
                  <p className="mt-1 text-sm text-fg-3">
                    Added {formatDate(u.created_at)} · {ROLE_HELP[u.role] ?? ""}
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <StatusPill status={u.is_active ? "published" : "archived"} label={`${u.role}${u.is_active ? "" : " (inactive)"}`} />
                  {!locked ? (
                    <>
                      <form action={setUserRoleAction} className="flex items-center gap-2">
                        <input type="hidden" name="id" value={u.id} />
                        <label htmlFor={`role-${u.id}`} className="sr-only">
                          Role for {u.full_name || u.email}
                        </label>
                        <select id={`role-${u.id}`} name="role" defaultValue={u.role} className={`${inputClass} w-auto`}>
                          <option value="admin">admin</option>
                          <option value="editor">editor</option>
                          <option value="author">author</option>
                        </select>
                        <SubmitButton variant="secondary">Set role</SubmitButton>
                      </form>
                      <form action={setUserActiveAction}>
                        <input type="hidden" name="id" value={u.id} />
                        <input type="hidden" name="active" value={u.is_active ? "false" : "true"} />
                        <SubmitButton variant={u.is_active ? "danger" : "primary"} confirm={u.is_active ? "Deactivate this person? They will lose access immediately." : undefined}>
                          {u.is_active ? "Deactivate" : "Activate"}
                        </SubmitButton>
                      </form>
                    </>
                  ) : null}
                </div>
              </li>
            );
          })}
        </ul>
      </Panel>

      <Panel title="Add a person" className="mt-6">
        <form action={createUserAction} className="grid gap-4 sm:grid-cols-2">
          <Field label="Full name" htmlFor="full_name">
            <input id="full_name" name="full_name" required minLength={2} maxLength={100} autoComplete="off" className={inputClass} />
          </Field>
          <Field label="Email" htmlFor="new-email">
            <input id="new-email" name="email" type="email" required autoComplete="off" className={inputClass} />
          </Field>
          <Field label="Role" htmlFor="new-role" hint="Only owners and admins can open the dashboard today.">
            <select id="new-role" name="role" defaultValue="admin" className={inputClass}>
              <option value="admin">admin</option>
              <option value="editor">editor</option>
              <option value="author">author</option>
            </select>
          </Field>
          <Field label="Temporary password" htmlFor="new-password" hint="At least 10 characters. Share it privately, then ask them to use Forgot password to choose their own.">
            <input id="new-password" name="password" type="password" required minLength={10} maxLength={72} autoComplete="new-password" className={inputClass} />
          </Field>
          <div className="sm:col-span-2">
            <SubmitButton pendingLabel="Creating…">Create account</SubmitButton>
          </div>
        </form>
      </Panel>
    </>
  );
}
