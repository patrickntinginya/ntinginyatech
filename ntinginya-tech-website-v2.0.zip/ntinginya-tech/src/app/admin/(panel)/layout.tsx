import type { Metadata } from "next";
import Link from "next/link";
import type { ReactNode } from "react";
import { ExternalLink, LogOut } from "lucide-react";
import { AdminNav } from "@/components/admin/AdminNav";
import { SubmitButton } from "@/components/admin/SubmitButton";
import { LogoMark } from "@/components/layout/Logo";
import { requireStaff } from "@/lib/auth";
import { getUnreadCount } from "@/lib/cms/admin-queries";
import { signOutAction } from "../actions/auth";

export const metadata: Metadata = { title: { absolute: "Admin | Ntinginya Tech" }, robots: { index: false, follow: false } };
export const dynamic = "force-dynamic";

export default async function PanelLayout({ children }: { children: ReactNode }) {
  // Each page and action checks access again: a layout check alone is never enough.
  const staff = await requireStaff();
  const unread = await getUnreadCount();

  return (
    <div className="min-h-screen bg-ink">
      <a href="#admin-main" className="skip-link">Skip to main content</a>
      <header className="sticky top-0 z-40 border-b border-fg-3/15 bg-navy/95 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-7xl items-center justify-between gap-3 px-4 sm:px-6 lg:h-20 lg:px-8">
          <Link href="/admin" className="flex items-center gap-3 rounded-md" aria-label="Ntinginya Tech admin, overview">
            <LogoMark />
            <span className="text-[0.9375rem] font-semibold text-fg">Admin</span>
          </Link>
          <div className="flex items-center gap-2">
            <span className="hidden text-sm text-fg-3 md:inline">{staff.fullName}</span>
            <Link href="/" target="_blank" rel="noopener" className="inline-flex min-h-11 items-center gap-1.5 rounded-lg px-3 text-sm font-medium text-fg-2 hover:text-fg">
              <ExternalLink aria-hidden="true" className="h-4 w-4" />
              <span className="hidden sm:inline">View site</span>
              <span className="sr-only">(opens in a new tab)</span>
            </Link>
            <form action={signOutAction}>
              <SubmitButton variant="secondary" className="gap-2">
                <LogOut aria-hidden="true" className="h-4 w-4" />
                Sign out
              </SubmitButton>
            </form>
          </div>
        </div>
      </header>
      <div className="mx-auto max-w-7xl lg:grid lg:grid-cols-[14.5rem_minmax(0,1fr)] lg:gap-8 lg:px-8">
        <AdminNav unread={unread} isOwner={staff.role === "owner"} />
        <main id="admin-main" className="min-w-0 px-4 py-6 sm:px-6 lg:px-0 lg:py-10">
          {children}
        </main>
      </div>
    </div>
  );
}
