import { SubmitButton } from "@/components/admin/SubmitButton";
import { TestEmailForm } from "@/components/admin/TestEmailForm";
import { Field, Notice, PageHeader, Panel, StatusPill, inputClass } from "@/components/admin/ui";
import { requireStaff } from "@/lib/auth";
import { getSettingsRow } from "@/lib/cms/admin-queries";
import { emailRouting } from "@/lib/email";
import { configChecks } from "@/lib/env";
import { SOCIAL_LABELS, mergeSettings, type SiteSettings } from "@/lib/settings";
import { saveSettingsAction } from "../../actions/settings";

type SP = { notice?: string; error?: string };

export default async function SettingsPage({ searchParams }: { searchParams: Promise<SP> | SP }) {
  await requireStaff("settings:write");
  const sp = await searchParams;
  const s = mergeSettings(await getSettingsRow());
  const routing = emailRouting();

  return (
    <>
      <PageHeader title="Site settings" description="Contact details and search text used across the website. Changes go live straight away." />
      <Notice notice={sp.notice} error={sp.error} />

      <form action={saveSettingsAction} className="space-y-6">
        <Panel title="Website">
          <div className="space-y-5">
            <Field label="Site title" htmlFor="siteTitle">
              <input id="siteTitle" name="siteTitle" required minLength={2} maxLength={80} defaultValue={s.siteTitle} className={inputClass} />
            </Field>
            <Field label="Site description" htmlFor="siteDescription" hint="At least 20 characters.">
              <textarea id="siteDescription" name="siteDescription" required minLength={20} maxLength={320} rows={3} defaultValue={s.siteDescription} className={inputClass} />
            </Field>
          </div>
        </Panel>

        <Panel title="Contact details">
          <div className="grid gap-5 sm:grid-cols-2">
            <Field label="Contact email" htmlFor="contactEmail">
              <input id="contactEmail" name="contactEmail" type="email" required maxLength={200} defaultValue={s.contactEmail} className={inputClass} />
            </Field>
            <Field label="Phone" htmlFor="phone" hint="Include the country code, for example +255 784 949 095.">
              <input id="phone" name="phone" type="tel" required maxLength={30} defaultValue={s.phone} className={inputClass} />
            </Field>
            <Field label="WhatsApp number" htmlFor="whatsapp" hint="Used for the Chat on WhatsApp buttons.">
              <input id="whatsapp" name="whatsapp" type="tel" required maxLength={30} defaultValue={s.whatsapp} className={inputClass} />
            </Field>
            <Field label="Location" htmlFor="location" hint="Do not add an address unless you want it public.">
              <input id="location" name="location" maxLength={100} defaultValue={s.location} className={inputClass} />
            </Field>
          </div>
          <p className="mt-4 text-sm text-fg-3">
            This changes what visitors see. Contact form emails go to {routing.to}, which is set with CONTACT_TO_EMAIL in Netlify.
          </p>
        </Panel>

        <Panel title="Social links">
          <p className="mb-4 text-[0.9375rem] text-fg-2">Leave empty for accounts you do not have. Links must start with https://</p>
          <div className="grid gap-5 sm:grid-cols-2">
            {(Object.keys(SOCIAL_LABELS) as (keyof SiteSettings["socials"])[]).map((key) => (
              <Field key={key} label={SOCIAL_LABELS[key]} htmlFor={`social_${key}`}>
                <input id={`social_${key}`} name={`social_${key}`} type="url" maxLength={300} defaultValue={s.socials[key]} className={inputClass} />
              </Field>
            ))}
          </div>
        </Panel>

        <Panel title="Default SEO">
          <div className="space-y-5">
            <Field label="Default SEO title" htmlFor="defaultSeoTitle" hint="Used on the home page and any page without its own title. Up to 70 characters.">
              <input id="defaultSeoTitle" name="defaultSeoTitle" maxLength={70} defaultValue={s.defaultSeoTitle} className={inputClass} />
            </Field>
            <Field label="Default SEO description" htmlFor="defaultSeoDescription" hint="Up to 200 characters.">
              <textarea id="defaultSeoDescription" name="defaultSeoDescription" maxLength={200} rows={3} defaultValue={s.defaultSeoDescription} className={inputClass} />
            </Field>
          </div>
        </Panel>

        <SubmitButton size="lg" pendingLabel="Saving…">
          Save settings
        </SubmitButton>
      </form>

      <Panel title="Email delivery (contact form)" className="mt-10">
        <ul className="divide-y divide-fg-3/15">
          {configChecks().map((c) => (
            <li key={c.name} className="flex flex-col gap-1 py-3 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="font-mono text-sm text-fg">{c.name}</p>
                <p className="text-sm text-fg-3">{c.note}</p>
              </div>
              <StatusPill status={c.ok ? "sent" : c.required ? "failed" : "not_sent"} label={c.ok ? "set" : c.required ? "missing" : "not set"} />
            </li>
          ))}
        </ul>
        <p className="mt-4 text-sm text-fg-3">
          Only whether each value is set is shown, never the values. Sender in use: {routing.from}
          {routing.usingTestSender ? " (Resend test sender)" : ""}.
        </p>
        <div className="mt-6 border-t border-fg-3/15 pt-6">
          <TestEmailForm to={routing.to} />
        </div>
      </Panel>
    </>
  );
}
