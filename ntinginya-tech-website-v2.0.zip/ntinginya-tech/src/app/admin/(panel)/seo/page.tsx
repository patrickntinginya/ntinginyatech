import Link from "next/link";
import { Panel, PageHeader, StatusPill, Empty } from "@/components/admin/ui";
import { buttonStyles } from "@/components/ui/Button";
import { siteConfig } from "@/config/site";
import { getSeoOverview, getSettingsRow } from "@/lib/cms/admin-queries";
import { mergeSettings } from "@/lib/settings";

function Check({ ok, label }: { ok: boolean; label: string }) {
  return <StatusPill status={ok ? "published" : "draft"} label={ok ? label : `${label}: missing`} />;
}

export default async function SeoPage() {
  const [posts, settingsRow] = await Promise.all([getSeoOverview(), getSettingsRow()]);
  const settings = mergeSettings(settingsRow);
  const incomplete = posts.filter((p) => !p.seo_title || !p.seo_description || !(p.social_image || p.featured_image));

  return (
    <>
      <PageHeader
        title="SEO"
        description="How the site and each published article appear in search results and when shared."
        actions={
          <Link href="/admin/settings" className={buttonStyles({ variant: "tech" })}>
            Edit default SEO
          </Link>
        }
      />

      <div className="grid gap-6 xl:grid-cols-2">
        <Panel title="Site defaults">
          <dl className="space-y-4 text-[0.9375rem]">
            <div>
              <dt className="text-sm font-semibold text-fg">Default title</dt>
              <dd className="text-fg-2">{settings.defaultSeoTitle}</dd>
            </div>
            <div>
              <dt className="text-sm font-semibold text-fg">Default description</dt>
              <dd className="text-fg-2">{settings.defaultSeoDescription}</dd>
            </div>
            <div>
              <dt className="text-sm font-semibold text-fg">Site address used in links</dt>
              <dd className="break-all text-fg-2">{siteConfig.url}</dd>
            </div>
          </dl>
        </Panel>

        <Panel title="Sitemap and search engines">
          <ul className="space-y-3 text-[0.9375rem] text-fg-2">
            <li>
              <a href="/sitemap.xml" target="_blank" rel="noopener" className="font-semibold text-brand-light underline underline-offset-4">
                sitemap.xml<span className="sr-only"> (opens in a new tab)</span>
              </a>{" "}
              lists every page and every published article. It updates by itself when you publish or unpublish.
            </li>
            <li>
              <a href="/robots.txt" target="_blank" rel="noopener" className="font-semibold text-brand-light underline underline-offset-4">
                robots.txt<span className="sr-only"> (opens in a new tab)</span>
              </a>{" "}
              keeps the dashboard out of search results. Drafts and archived posts are never listed.
            </li>
          </ul>
        </Panel>
      </div>

      <Panel title={`Published articles (${posts.length})`} className="mt-6">
        {posts.length === 0 ? (
          <Empty>No published articles yet.</Empty>
        ) : (
          <>
            <p className="mb-4 text-[0.9375rem] text-fg-2">
              {incomplete.length === 0
                ? "Every published article has an SEO title, description and image."
                : `${incomplete.length} article${incomplete.length === 1 ? "" : "s"} could use more SEO detail. Missing fields fall back to the title, excerpt and featured image.`}
            </p>
            <ul className="divide-y divide-fg-3/15">
              {posts.map((p) => (
                <li key={p.id} className="flex flex-col gap-3 py-4 lg:flex-row lg:items-center lg:justify-between">
                  <div className="min-w-0">
                    <Link href={`/admin/posts/${p.id}/edit`} className="font-semibold text-fg hover:text-brand-light">
                      {p.title}
                    </Link>
                    <p className="mt-0.5 break-all text-sm text-fg-3">/news/{p.slug}</p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Check ok={Boolean(p.seo_title)} label="Title" />
                    <Check ok={Boolean(p.seo_description)} label="Description" />
                    <Check ok={Boolean(p.social_image || p.featured_image)} label="Image" />
                  </div>
                </li>
              ))}
            </ul>
          </>
        )}
      </Panel>
    </>
  );
}
