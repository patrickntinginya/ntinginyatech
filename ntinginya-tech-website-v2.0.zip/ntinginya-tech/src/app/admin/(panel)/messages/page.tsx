import Link from "next/link";
import { Mail, Phone } from "lucide-react";
import { SubmitButton } from "@/components/admin/SubmitButton";
import { Empty, Notice, PageHeader, Pager, StatusPill } from "@/components/admin/ui";
import { buttonStyles } from "@/components/ui/Button";
import { ADMIN_PAGE_SIZE, listMessages } from "@/lib/cms/admin-queries";
import { formatDateTime } from "@/lib/format";
import { cn } from "@/lib/cn";
import { deleteMessageAction, setMessageStatusAction } from "../../actions/messages";

type SP = { filter?: string; page?: string; notice?: string; error?: string };

const TABS = [
  { value: "", label: "All" },
  { value: "unread", label: "Unread" },
  { value: "read", label: "Read" },
];

const EMAIL_NOTES: Record<string, string> = {
  failed: "The email notification did not go through, but the message is safe here. Check docs/CONTACT_FORM_SETUP.md.",
  not_configured: "Email notifications are not set up yet (RESEND_API_KEY is missing), so this message was saved here only.",
  not_sent: "No email notification was attempted for this message.",
};

export default async function MessagesPage({ searchParams }: { searchParams: Promise<SP> | SP }) {
  const sp = await searchParams;
  const filter = sp.filter === "unread" || sp.filter === "read" ? sp.filter : "";
  const page = Math.max(1, Number.parseInt(sp.page ?? "1", 10) || 1);
  const { rows, total } = await listMessages({ filter, page });
  const hrefFor = (n: number) => `/admin/messages?${new URLSearchParams({ ...(filter ? { filter } : {}), ...(n > 1 ? { page: String(n) } : {}) }).toString()}`;

  return (
    <>
      <PageHeader title="Contact messages" description="Messages sent through the website contact form. Each one is also emailed to you when email is set up." />
      <Notice notice={sp.notice} error={sp.error} />

      <nav aria-label="Filter messages" className="mb-6">
        <ul className="flex flex-wrap gap-2">
          {TABS.map((t) => (
            <li key={t.value}>
              <Link
                href={t.value ? `/admin/messages?filter=${t.value}` : "/admin/messages"}
                aria-current={filter === t.value ? "page" : undefined}
                className={cn(
                  "inline-flex min-h-11 items-center rounded-full border px-4 text-sm font-semibold",
                  filter === t.value ? "border-brand bg-brand/15 text-brand-light" : "border-fg-3/30 text-fg-2 hover:border-brand-light hover:text-fg",
                )}
              >
                {t.label}
              </Link>
            </li>
          ))}
        </ul>
      </nav>

      {rows.length === 0 ? (
        <Empty>{filter ? "No messages in this view." : "No messages yet. When someone uses the contact form, it appears here."}</Empty>
      ) : (
        <ul className="space-y-3">
          {rows.map((m) => {
            const unread = m.status === "unread";
            const replySubject = encodeURIComponent(`Re: ${m.subject}`);
            return (
              <li key={m.id}>
                <details className={cn("card-surface group", unread && "border-info/40")}>
                  <summary className="flex cursor-pointer list-none flex-col gap-2 p-4 sm:flex-row sm:items-center sm:justify-between sm:p-5">
                    <div className="min-w-0">
                      <p className={cn("truncate text-[1.0625rem] text-fg", unread ? "font-bold" : "font-semibold")}>{m.subject}</p>
                      <p className="truncate text-sm text-fg-3">
                        {m.name} · {m.email}
                      </p>
                    </div>
                    <div className="flex shrink-0 flex-wrap items-center gap-2">
                      <StatusPill status={m.status} />
                      {m.email_status !== "sent" ? <StatusPill status={m.email_status} label={`email ${m.email_status.replace("_", " ")}`} /> : null}
                      <span className="text-sm text-fg-3">{formatDateTime(m.created_at)}</span>
                    </div>
                  </summary>

                  <div className="border-t border-fg-3/15 p-4 sm:p-5">
                    <dl className="grid gap-3 text-[0.9375rem] sm:grid-cols-2">
                      <div>
                        <dt className="text-sm font-semibold text-fg">Name</dt>
                        <dd className="text-fg-2">{m.name}</dd>
                      </div>
                      <div>
                        <dt className="text-sm font-semibold text-fg">Type of inquiry</dt>
                        <dd className="text-fg-2">{m.inquiry_type ?? "Not given"}</dd>
                      </div>
                      <div>
                        <dt className="text-sm font-semibold text-fg">Email</dt>
                        <dd className="break-all">
                          <a href={`mailto:${m.email}`} className="text-brand-light underline underline-offset-4">
                            {m.email}
                          </a>
                        </dd>
                      </div>
                      <div>
                        <dt className="text-sm font-semibold text-fg">Phone</dt>
                        <dd>
                          {m.phone ? (
                            <a href={`tel:${m.phone.replace(/[^\d+]/g, "")}`} className="text-brand-light underline underline-offset-4">
                              {m.phone}
                            </a>
                          ) : (
                            <span className="text-fg-2">Not given</span>
                          )}
                        </dd>
                      </div>
                    </dl>

                    {/* Rendered as plain text by React: a visitor cannot inject HTML or scripts through the form. */}
                    <p className="mt-5 whitespace-pre-wrap break-words rounded-xl bg-navy p-4 text-[0.9375rem] leading-relaxed text-fg">{m.message}</p>

                    {EMAIL_NOTES[m.email_status] ? <p className="mt-3 text-sm text-warning">{EMAIL_NOTES[m.email_status]}</p> : null}

                    <div className="mt-5 flex flex-wrap gap-2">
                      <a href={`mailto:${m.email}?subject=${replySubject}`} className={buttonStyles({ variant: "primary", className: "gap-2" })}>
                        <Mail aria-hidden="true" className="h-4 w-4" />
                        Reply via email
                      </a>
                      {m.phone ? (
                        <a href={`tel:${m.phone.replace(/[^\d+]/g, "")}`} className={buttonStyles({ variant: "secondary", className: "gap-2" })}>
                          <Phone aria-hidden="true" className="h-4 w-4" />
                          Call
                        </a>
                      ) : null}
                      <form action={setMessageStatusAction}>
                        <input type="hidden" name="id" value={m.id} />
                        <input type="hidden" name="to" value={unread ? "read" : "unread"} />
                        <input type="hidden" name="filter" value={filter} />
                        <SubmitButton variant="secondary">{unread ? "Mark as read" : "Mark as unread"}</SubmitButton>
                      </form>
                      <form action={deleteMessageAction}>
                        <input type="hidden" name="id" value={m.id} />
                        <input type="hidden" name="filter" value={filter} />
                        <SubmitButton variant="danger" confirm="Delete this message permanently?">
                          Delete
                        </SubmitButton>
                      </form>
                    </div>
                  </div>
                </details>
              </li>
            );
          })}
        </ul>
      )}

      <Pager page={page} total={total} size={ADMIN_PAGE_SIZE} hrefFor={hrefFor} />
    </>
  );
}
