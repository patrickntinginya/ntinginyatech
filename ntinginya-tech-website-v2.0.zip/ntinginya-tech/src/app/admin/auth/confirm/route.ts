import type { EmailOtpType } from "@supabase/supabase-js";
import { NextResponse, type NextRequest } from "next/server";
import { safeAdminPath } from "@/lib/auth";
import { createSupabaseServerClient } from "@/lib/supabase/server";

/**
 * Landing page for the link in a password-reset email. It supports both link styles Supabase can send:
 *  - ?token_hash=...&type=recovery  (works even if the email is opened in a different browser or app: recommended)
 *  - ?code=...                      (works only in the same browser that asked for the reset)
 */
export async function GET(request: NextRequest) {
  const params = request.nextUrl.searchParams;
  const tokenHash = params.get("token_hash");
  const type = params.get("type") as EmailOtpType | null;
  const code = params.get("code");
  const next = safeAdminPath(params.get("next"), "/admin/reset-password");

  const supabase = await createSupabaseServerClient();
  let ok = false;
  if (tokenHash && type) {
    ok = !(await supabase.auth.verifyOtp({ type, token_hash: tokenHash })).error;
  } else if (code) {
    ok = !(await supabase.auth.exchangeCodeForSession(code)).error;
  }

  return NextResponse.redirect(new URL(ok ? next : "/admin/forgot-password?error=expired", request.url));
}
