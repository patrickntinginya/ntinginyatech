"use server";

import { revalidatePath, revalidateTag } from "next/cache";
import { redirect } from "next/navigation";
import { adminDb } from "@/lib/admin-db";
import { logActivity } from "@/lib/activity";
import { POSTS_TAG } from "@/lib/cms/queries";
import { htmlToText, sanitizeArticleHtml } from "@/lib/cms/sanitize";
import { SLUG_PATTERN, slugify } from "@/lib/cms/slug";

export type EditorState = { error: string | null };

const text = (v: FormDataEntryValue | null, max: number) => (typeof v === "string" ? v.trim().slice(0, max) : "");
const httpsOrEmpty = (v: string) => v === "" || /^https:\/\/\S+$/i.test(v);

function refreshPublicPages(...slugs: (string | null | undefined)[]) {
  revalidateTag(POSTS_TAG);
  revalidatePath("/news");
  revalidatePath("/sitemap.xml");
  for (const s of new Set(slugs.filter(Boolean))) revalidatePath(`/news/${s}`);
}

/** Create or update a post. `intent` says what the person pressed: draft, save, publish, unpublish or archive. */
export async function savePostAction(_prev: EditorState, formData: FormData): Promise<EditorState> {
  const { db, staff } = await adminDb("posts:write");

  const id = text(formData.get("id"), 60);
  const intent = text(formData.get("intent"), 20);
  if (["publish", "unpublish"].includes(intent)) await adminDb("posts:publish");

  const title = text(formData.get("title"), 200);
  const slug = slugify(text(formData.get("slug"), 120) || title);
  const excerptInput = text(formData.get("excerpt"), 300);
  const content = sanitizeArticleHtml(typeof formData.get("content") === "string" ? (formData.get("content") as string).slice(0, 300_000) : "");
  const featuredImage = text(formData.get("featured_image"), 600);
  const featuredAlt = text(formData.get("featured_image_alt"), 200);
  const socialImage = text(formData.get("social_image"), 600);
  const seoTitle = text(formData.get("seo_title"), 70);
  const seoDescription = text(formData.get("seo_description"), 200);
  const categoryId = text(formData.get("category_id"), 60);
  const authorInput = text(formData.get("author_id"), 60);
  const isFeatured = formData.get("is_featured") === "on";
  const tagNames = Array.from(
    new Set(text(formData.get("tags"), 400).split(",").map((t) => t.trim().slice(0, 40)).filter(Boolean)),
  ).slice(0, 10);

  if (title.length < 3) return { error: "Add a title (at least 3 characters)." };
  if (!SLUG_PATTERN.test(slug)) return { error: "The web address (slug) may only contain letters, numbers and hyphens." };
  if (!httpsOrEmpty(featuredImage) || !httpsOrEmpty(socialImage)) return { error: "Images must be chosen from the media library." };

  let existing: { id: string; slug: string; status: string; published_at: string | null; author_id: string | null } | null = null;
  if (id) {
    const { data } = await db.from("posts").select("id, slug, status, published_at, author_id").eq("id", id).maybeSingle();
    if (!data) return { error: "This post no longer exists. It may have been deleted." };
    existing = data;
  }

  const clash = await db.from("posts").select("id").eq("slug", slug).neq("id", existing?.id ?? "00000000-0000-0000-0000-000000000000").maybeSingle();
  if (clash.data) return { error: "Another post already uses this web address. Change the slug." };

  let status = (existing?.status ?? "draft") as "draft" | "published" | "archived";
  if (intent === "publish") status = "published";
  if (intent === "unpublish") status = "draft";
  if (intent === "archive") status = "archived";

  if (status === "published" && htmlToText(content).length < 20) return { error: "Write some article content before publishing." };

  let authorId = existing?.author_id ?? staff.id;
  if (authorInput) {
    const { data: author } = await db.from("profiles").select("id").eq("id", authorInput).eq("is_active", true).maybeSingle();
    if (author) authorId = author.id;
  }
  if (categoryId) {
    const { data: category } = await db.from("categories").select("id").eq("id", categoryId).maybeSingle();
    if (!category) return { error: "That category no longer exists. Choose another." };
  }

  const row = {
    title,
    slug,
    excerpt: excerptInput || (htmlToText(content).slice(0, 157).trim() + (htmlToText(content).length > 157 ? "..." : "")) || null,
    content,
    featured_image: featuredImage || null,
    featured_image_alt: featuredImage ? featuredAlt || null : null,
    category_id: categoryId || null,
    author_id: authorId,
    status,
    is_featured: isFeatured,
    published_at: status === "published" ? existing?.published_at ?? new Date().toISOString() : existing?.published_at ?? null,
    seo_title: seoTitle || null,
    seo_description: seoDescription || null,
    social_image: socialImage || null,
  };

  const saved = existing
    ? await db.from("posts").update(row).eq("id", existing.id).select("id").single()
    : await db.from("posts").insert(row).select("id").single();
  if (saved.error || !saved.data) {
    console.error("Saving post failed:", saved.error?.message);
    return { error: "The post could not be saved. Please try again." };
  }
  const postId = saved.data.id as string;

  // Tags: create any that are new, then replace this post's tag list.
  await db.from("post_tags").delete().eq("post_id", postId);
  if (tagNames.length > 0) {
    const tagRows = tagNames.map((name) => ({ name, slug: slugify(name, 60) })).filter((t) => t.slug);
    const { data: tags } = await db.from("tags").upsert(tagRows, { onConflict: "slug" }).select("id");
    if (tags?.length) await db.from("post_tags").insert(tags.map((t) => ({ post_id: postId, tag_id: t.id })));
  }

  const wasPublished = existing?.status === "published";
  const action =
    status === "published" && !wasPublished ? "post.published"
    : status !== "published" && wasPublished ? "post.unpublished"
    : status === "archived" && existing?.status !== "archived" ? "post.archived"
    : existing ? "post.edited" : "post.created";
  await logActivity({ user: staff, action, targetType: "post", targetId: postId, targetLabel: title });

  refreshPublicPages(slug, existing?.slug);
  const notice = action === "post.published" ? "published" : action === "post.unpublished" ? "unpublished" : action === "post.archived" ? "archived" : existing ? "saved" : "created";
  redirect(`/admin/posts/${postId}/edit?notice=${notice}`);
}

/** Publish / unpublish / archive straight from the posts list. */
export async function setPostStatusAction(formData: FormData) {
  const { db, staff } = await adminDb("posts:publish");
  const id = text(formData.get("id"), 60);
  const to = text(formData.get("to"), 20);
  if (!["draft", "published", "archived"].includes(to)) redirect("/admin/posts?error=invalid");

  const { data: post } = await db.from("posts").select("id, title, slug, status, content, published_at").eq("id", id).maybeSingle();
  if (!post) redirect("/admin/posts?error=missing");
  if (to === "published" && htmlToText(post.content as string).length < 20) redirect("/admin/posts?error=empty");

  const { error } = await db
    .from("posts")
    .update({ status: to, published_at: to === "published" ? (post.published_at as string | null) ?? new Date().toISOString() : post.published_at })
    .eq("id", id);
  if (error) redirect("/admin/posts?error=failed");

  const action = to === "published" ? "post.published" : post.status === "published" ? "post.unpublished" : "post.archived";
  await logActivity({ user: staff, action, targetType: "post", targetId: id, targetLabel: post.title as string });
  refreshPublicPages(post.slug as string);
  redirect(`/admin/posts?notice=${to === "published" ? "published" : to === "archived" ? "archived" : "unpublished"}`);
}

export async function deletePostAction(formData: FormData) {
  const { db, staff } = await adminDb("posts:delete");
  const id = text(formData.get("id"), 60);
  const { data: post } = await db.from("posts").select("title, slug").eq("id", id).maybeSingle();
  if (!post) redirect("/admin/posts?error=missing");
  const { error } = await db.from("posts").delete().eq("id", id);
  if (error) redirect("/admin/posts?error=failed");
  await logActivity({ user: staff, action: "post.deleted", targetType: "post", targetId: id, targetLabel: post.title as string });
  refreshPublicPages(post.slug as string);
  redirect("/admin/posts?notice=deleted");
}
