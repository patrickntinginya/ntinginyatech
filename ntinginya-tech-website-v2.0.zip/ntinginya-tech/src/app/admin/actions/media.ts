"use server";

import { randomUUID } from "node:crypto";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { adminDb } from "@/lib/admin-db";
import { logActivity } from "@/lib/activity";
import { listMediaItems } from "@/lib/cms/admin-queries";
import type { MediaItem } from "@/lib/cms/types";

const MAX_BYTES = 5 * 1024 * 1024; // same as the storage bucket limit
const BUCKET = "media";

/** The file type is decided from the file's own first bytes, never from its name or the type the browser claims. */
function detectImage(bytes: Uint8Array): { mime: string; ext: string } | null {
  if (bytes.length > 12 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return { mime: "image/jpeg", ext: "jpg" };
  if (bytes.length > 12 && bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47) return { mime: "image/png", ext: "png" };
  if (
    bytes.length > 12 &&
    String.fromCharCode(...bytes.slice(0, 4)) === "RIFF" &&
    String.fromCharCode(...bytes.slice(8, 12)) === "WEBP"
  ) {
    return { mime: "image/webp", ext: "webp" };
  }
  return null; // SVG, GIF, HTML and everything else are refused
}

export type UploadResult = { ok: true; item: MediaItem } | { ok: false; error: string };

export async function uploadMediaAction(formData: FormData): Promise<UploadResult> {
  const { db, staff } = await adminDb("media:manage");

  const file = formData.get("file");
  if (!(file instanceof File) || file.size === 0) return { ok: false, error: "Choose an image to upload." };
  if (file.size > MAX_BYTES) return { ok: false, error: "That image is larger than 5 MB. Choose a smaller one." };

  const buffer = new Uint8Array(await file.arrayBuffer());
  const type = detectImage(buffer);
  if (!type) return { ok: false, error: "Only JPEG, PNG and WebP images can be uploaded." };

  const dim = (v: FormDataEntryValue | null) => {
    const n = typeof v === "string" ? Number.parseInt(v, 10) : NaN;
    return Number.isFinite(n) && n > 0 && n <= 20000 ? n : null;
  };
  const width = dim(formData.get("width"));
  const height = dim(formData.get("height"));
  if ((width && width > 6000) || (height && height > 6000)) return { ok: false, error: "That image is too large in pixels (maximum 6000)." };

  const alt = typeof formData.get("alt") === "string" ? (formData.get("alt") as string).trim().slice(0, 200) : "";
  const baseName = file.name.replace(/\.[^.]+$/, "").replace(/[^a-zA-Z0-9-_ ]+/g, "").trim().slice(0, 60) || "image";
  const now = new Date();
  const path = `${now.getUTCFullYear()}/${String(now.getUTCMonth() + 1).padStart(2, "0")}/${randomUUID()}.${type.ext}`;

  const { error: uploadError } = await db.storage.from(BUCKET).upload(path, buffer, { contentType: type.mime, cacheControl: "31536000", upsert: false });
  if (uploadError) {
    console.error("Media upload failed:", uploadError.message);
    return { ok: false, error: "The image could not be saved. Check the Supabase storage setup and try again." };
  }
  const url = db.storage.from(BUCKET).getPublicUrl(path).data.publicUrl;

  const { data, error } = await db
    .from("media")
    .insert({ path, url, filename: `${baseName}.${type.ext}`, alt: alt || null, mime_type: type.mime, size_bytes: file.size, width, height, uploaded_by: staff.id })
    .select("id, url, filename, alt, width, height, size_bytes, created_at")
    .single();
  if (error || !data) {
    console.error("Saving media record failed:", error?.message);
    await db.storage.from(BUCKET).remove([path]); // do not leave an orphan file behind
    return { ok: false, error: "The image could not be recorded. Please try again." };
  }

  await logActivity({ user: staff, action: "media.uploaded", targetType: "media", targetId: data.id, targetLabel: data.filename });
  revalidatePath("/admin/media");
  return { ok: true, item: data as MediaItem };
}

/** Used by the image picker inside the post editor. */
export async function listMediaAction(query: string): Promise<MediaItem[]> {
  const { rows } = await listMediaItems({ q: query, limit: 30 });
  return rows;
}

export async function deleteMediaAction(formData: FormData) {
  const { db, staff } = await adminDb("media:manage");
  const id = typeof formData.get("id") === "string" ? (formData.get("id") as string) : "";
  const { data: item } = await db.from("media").select("id, path, filename").eq("id", id).maybeSingle();
  if (!item) redirect("/admin/media?error=missing");

  await db.storage.from(BUCKET).remove([item.path as string]);
  const { error } = await db.from("media").delete().eq("id", id);
  if (error) redirect("/admin/media?error=failed");

  await logActivity({ user: staff, action: "media.deleted", targetType: "media", targetId: id, targetLabel: item.filename as string });
  revalidatePath("/admin/media");
  redirect("/admin/media?notice=deleted");
}
