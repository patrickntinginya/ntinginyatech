"use server";

import { redirect } from "next/navigation";
import { adminDb } from "@/lib/admin-db";
import { logActivity } from "@/lib/activity";

const id = (formData: FormData) => (typeof formData.get("id") === "string" ? (formData.get("id") as string).slice(0, 60) : "");
const back = (formData: FormData, extra: string) => {
  const f = formData.get("filter");
  return `/admin/messages?${f === "unread" || f === "read" ? `filter=${f}&` : ""}${extra}`;
};

export async function setMessageStatusAction(formData: FormData) {
  const { db } = await adminDb("messages:manage");
  const to = formData.get("to") === "unread" ? "unread" : "read";
  const { error } = await db.from("contact_messages").update({ status: to }).eq("id", id(formData));
  redirect(back(formData, error ? "error=failed" : `notice=${to}`));
}

export async function deleteMessageAction(formData: FormData) {
  const { db, staff } = await adminDb("messages:manage");
  const messageId = id(formData);
  const { data: m } = await db.from("contact_messages").select("subject").eq("id", messageId).maybeSingle();
  const { error } = await db.from("contact_messages").delete().eq("id", messageId);
  if (!error && m) await logActivity({ user: staff, action: "message.deleted", targetType: "message", targetId: messageId, targetLabel: m.subject as string });
  redirect(back(formData, error ? "error=failed" : "notice=message-deleted"));
}
