"use server";

import { adminDb } from "@/lib/admin-db";
import { logActivity } from "@/lib/activity";
import { sendViaResend, type EmailStatus } from "@/lib/email";
import { rateLimit } from "@/lib/rate-limit";

export type TestEmailState = { ran: boolean; status: EmailStatus | null; detail: string };

/**
 * Sends one real email through the same code path as the contact form and reports exactly what Resend said.
 * The explanation is shown only to signed-in admins, so visitors never see technical details.
 */
export async function sendTestEmailAction(_previous: TestEmailState, _formData: FormData): Promise<TestEmailState> {
  const { staff } = await adminDb("settings:write");
  if (!rateLimit(`test-email:${staff.id}`, 5, 10 * 60_000).ok) {
    return { ran: true, status: "failed", detail: "Too many test emails. Wait a few minutes and try again." };
  }
  const result = await sendViaResend({
    subject: "Ntinginya Tech website: test email",
    text: `This is a test email sent from the Ntinginya Tech admin dashboard by ${staff.fullName}.\n\nIf you can read this, contact form notifications will reach this inbox.`,
  });
  await logActivity({ user: staff, action: "email.test", targetType: "email", targetLabel: `Test email: ${result.status}` });
  return { ran: true, status: result.status, detail: result.detail };
}
