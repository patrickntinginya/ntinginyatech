"use server";

import { redirect } from "next/navigation";
import { adminDb } from "@/lib/admin-db";
import { logActivity } from "@/lib/activity";

const text = (v: FormDataEntryValue | null, max: number) => (typeof v === "string" ? v.trim().slice(0, max) : "");
const ROLES = ["owner", "admin", "editor", "author"];

/** Owner only. Creates a sign-in and gives it a role. Nobody can register themselves. */
export async function createUserAction(formData: FormData) {
  const { db, staff } = await adminDb("users:manage");
  const email = text(formData.get("email"), 200).toLowerCase();
  const fullName = text(formData.get("full_name"), 100);
  const role = text(formData.get("role"), 20);
  const password = typeof formData.get("password") === "string" ? (formData.get("password") as string) : "";

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) || fullName.length < 2 || !ROLES.includes(role) || role === "owner") redirect("/admin/users?error=invalid");
  if (password.length < 10 || password.length > 72) redirect("/admin/users?error=weak");

  const { data, error } = await db.auth.admin.createUser({ email, password, email_confirm: true, user_metadata: { full_name: fullName } });
  if (error || !data.user) {
    console.error("Creating user failed:", error?.message);
    redirect("/admin/users?error=failed");
  }
  // The database trigger created the profile as "author"; set the requested role.
  await db.from("profiles").update({ role, full_name: fullName }).eq("id", data.user.id);
  await logActivity({ user: staff, action: "user.created", targetType: "user", targetId: data.user.id, targetLabel: `${fullName} (${role})` });
  redirect("/admin/users?notice=created");
}

export async function setUserActiveAction(formData: FormData) {
  const { db, staff } = await adminDb("users:manage");
  const id = text(formData.get("id"), 60);
  const active = formData.get("active") === "true";
  if (id === staff.id) redirect("/admin/users?error=self");
  const { data: target } = await db.from("profiles").select("full_name, role").eq("id", id).maybeSingle();
  if (!target || target.role === "owner") redirect("/admin/users?error=invalid");
  const { error } = await db.from("profiles").update({ is_active: active }).eq("id", id);
  if (error) redirect("/admin/users?error=failed");
  await logActivity({ user: staff, action: active ? "user.activated" : "user.deactivated", targetType: "user", targetId: id, targetLabel: target.full_name as string });
  redirect("/admin/users?notice=updated");
}

export async function setUserRoleAction(formData: FormData) {
  const { db, staff } = await adminDb("users:manage");
  const id = text(formData.get("id"), 60);
  const role = text(formData.get("role"), 20);
  if (id === staff.id || !ROLES.includes(role) || role === "owner") redirect("/admin/users?error=invalid");
  const { data: target } = await db.from("profiles").select("full_name, role").eq("id", id).maybeSingle();
  if (!target || target.role === "owner") redirect("/admin/users?error=invalid");
  const { error } = await db.from("profiles").update({ role }).eq("id", id);
  if (error) redirect("/admin/users?error=failed");
  await logActivity({ user: staff, action: "user.role_changed", targetType: "user", targetId: id, targetLabel: `${target.full_name} → ${role}` });
  redirect("/admin/users?notice=updated");
}
