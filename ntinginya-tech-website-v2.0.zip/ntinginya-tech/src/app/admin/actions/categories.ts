"use server";

import { revalidatePath, revalidateTag } from "next/cache";
import { redirect } from "next/navigation";
import { adminDb } from "@/lib/admin-db";
import { logActivity } from "@/lib/activity";
import { POSTS_TAG } from "@/lib/cms/queries";
import { SLUG_PATTERN, slugify } from "@/lib/cms/slug";

const text = (v: FormDataEntryValue | null, max: number) => (typeof v === "string" ? v.trim().slice(0, max) : "");

function fields(formData: FormData) {
  const name = text(formData.get("name"), 80);
  const slug = slugify(text(formData.get("slug"), 80) || name, 80);
  const description = text(formData.get("description"), 300);
  return { name, slug, description: description || null };
}

function refresh() {
  revalidateTag(POSTS_TAG);
  revalidatePath("/news");
}

export async function saveCategoryAction(formData: FormData) {
  const { db, staff } = await adminDb("categories:manage");
  const id = text(formData.get("id"), 60);
  const c = fields(formData);
  if (c.name.length < 2 || !SLUG_PATTERN.test(c.slug)) redirect("/admin/categories?error=invalid");

  const { error } = id ? await db.from("categories").update(c).eq("id", id) : await db.from("categories").insert(c);
  if (error) redirect(`/admin/categories?error=${error.code === "23505" ? "duplicate" : "failed"}`);

  await logActivity({ user: staff, action: id ? "category.updated" : "category.created", targetType: "category", targetLabel: c.name });
  refresh();
  redirect(`/admin/categories?notice=${id ? "saved" : "created"}`);
}

export async function deleteCategoryAction(formData: FormData) {
  const { db, staff } = await adminDb("categories:manage");
  const id = text(formData.get("id"), 60);
  const { data: cat } = await db.from("categories").select("name").eq("id", id).maybeSingle();
  if (!cat) redirect("/admin/categories?error=missing");
  // Posts keep existing: their category simply becomes empty (database rule: on delete set null).
  const { error } = await db.from("categories").delete().eq("id", id);
  if (error) redirect("/admin/categories?error=failed");
  await logActivity({ user: staff, action: "category.deleted", targetType: "category", targetId: id, targetLabel: cat.name as string });
  refresh();
  redirect("/admin/categories?notice=deleted");
}
