"use server";

import { revalidatePath, revalidateTag } from "next/cache";
import { redirect } from "next/navigation";
import { adminDb } from "@/lib/admin-db";
import { logActivity } from "@/lib/activity";
import { SETTINGS_TAG, SOCIAL_LABELS, type SiteSettings } from "@/lib/settings";

const text = (v: FormDataEntryValue | null, max: number) => (typeof v === "string" ? v.trim().slice(0, max) : "");
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

/**
 * Validated so a typo cannot break the website: a bad value is rejected here, and the public site
 * also falls back to safe defaults for anything missing or malformed.
 */
export async function saveSettingsAction(formData: FormData) {
  const { db, staff } = await adminDb("settings:write");

  const phoneDigits = text(formData.get("phone"), 30).replace(/[^\d]/g, "");
  const whatsappDigits = text(formData.get("whatsapp"), 30).replace(/[^\d]/g, "");
  const email = text(formData.get("contactEmail"), 200);
  const siteTitle = text(formData.get("siteTitle"), 80);
  const siteDescription = text(formData.get("siteDescription"), 320);

  if (siteTitle.length < 2 || siteDescription.length < 20) redirect("/admin/settings?error=text");
  if (!EMAIL.test(email)) redirect("/admin/settings?error=email");
  if (phoneDigits.length < 9 || phoneDigits.length > 15 || whatsappDigits.length < 9 || whatsappDigits.length > 15) redirect("/admin/settings?error=phone");

  const socials = {} as SiteSettings["socials"];
  for (const key of Object.keys(SOCIAL_LABELS) as (keyof SiteSettings["socials"])[]) {
    const url = text(formData.get(`social_${key}`), 300);
    if (url && !/^https:\/\/[^\s]+\.[^\s]+$/i.test(url)) redirect("/admin/settings?error=social");
    socials[key] = url;
  }

  const value: SiteSettings = {
    siteTitle,
    siteDescription,
    contactEmail: email,
    phone: `+${phoneDigits}`,
    whatsapp: `+${whatsappDigits}`,
    location: text(formData.get("location"), 100) || "Based in Tanzania",
    socials,
    defaultSeoTitle: text(formData.get("defaultSeoTitle"), 70) || siteTitle,
    defaultSeoDescription: text(formData.get("defaultSeoDescription"), 200) || siteDescription,
  };

  const { error } = await db.from("site_settings").upsert({ key: "site", value, updated_by: staff.id }, { onConflict: "key" });
  if (error) {
    console.error("Saving settings failed:", error.message);
    redirect("/admin/settings?error=failed");
  }
  await logActivity({ user: staff, action: "settings.updated", targetType: "settings", targetLabel: "Site settings" });
  revalidateTag(SETTINGS_TAG);
  revalidatePath("/", "layout");
  redirect("/admin/settings?notice=saved");
}
