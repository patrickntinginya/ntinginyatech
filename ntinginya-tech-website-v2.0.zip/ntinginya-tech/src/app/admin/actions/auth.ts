"use server";

import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { siteConfig } from "@/config/site";
import { logActivity } from "@/lib/activity";
import { getStaff, safeAdminPath } from "@/lib/auth";
import { isSupabaseAdminConfigured } from "@/lib/env";
import { rateLimit } from "@/lib/rate-limit";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { createSupabaseServerClient } from "@/lib/supabase/server";

const text = (v: FormDataEntryValue | null, max = 200) => (typeof v === "string" ? v.trim().slice(0, max) : "");

async function clientIp(): Promise<string> {
  const h = await headers();
  return h.get("x-nf-client-connection-ip") ?? h.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
}

/** Email + password sign-in. Only active owners/admins get in; everyone else is signed straight back out. */
export async function signInAction(formData: FormData) {
  const email = text(formData.get("email")).toLowerCase();
  const password = typeof formData.get("password") === "string" ? (formData.get("password") as string).slice(0, 200) : "";
  const next = safeAdminPath(formData.get("next"));

  if (!isSupabaseAdminConfigured()) redirect("/admin/login?error=config");

  // Slow down password guessing: per address and per person.
  const ip = await clientIp();
  if (!rateLimit(`login-ip:${ip}`, 10, 15 * 60_000).ok || (email && !rateLimit(`login-email:${email}`, 6, 15 * 60_000).ok)) {
    redirect("/admin/login?error=rate");
  }
  if (!email || !password) redirect("/admin/login?error=invalid");

  const supabase = await createSupabaseServerClient();
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error || !data.user) redirect("/admin/login?error=invalid");

  const { data: profile } = await createSupabaseAdminClient()
    .from("profiles")
    .select("full_name, role, is_active")
    .eq("id", data.user.id)
    .maybeSingle();

  if (!profile || !profile.is_active || !["owner", "admin"].includes(profile.role as string)) {
    await supabase.auth.signOut();
    redirect("/admin/login?error=unauthorized");
  }

  await logActivity({ user: { id: data.user.id, fullName: (profile.full_name as string) || email, email }, action: "auth.login" });
  redirect(next);
}

export async function signOutAction() {
  const staff = await getStaff();
  if (staff) await logActivity({ user: staff, action: "auth.logout" });
  const supabase = await createSupabaseServerClient();
  await supabase.auth.signOut();
  redirect("/admin/login?notice=signed-out");
}

/** Always answers the same way, so nobody can use this form to discover which emails have accounts. */
export async function forgotPasswordAction(formData: FormData) {
  const email = text(formData.get("email")).toLowerCase();
  const ip = await clientIp();
  if (!rateLimit(`reset-ip:${ip}`, 5, 15 * 60_000).ok) redirect("/admin/forgot-password?error=rate");

  if (email && isSupabaseAdminConfigured()) {
    const supabase = await createSupabaseServerClient();
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${siteConfig.url}/admin/auth/confirm?next=/admin/reset-password`,
    });
    if (error) console.error("Password reset request failed:", error.message);
  }
  redirect("/admin/forgot-password?sent=1");
}

/** Sets a new password for the person who just opened a valid reset link (they hold a session). */
export async function resetPasswordAction(formData: FormData) {
  const password = typeof formData.get("password") === "string" ? (formData.get("password") as string) : "";
  const confirm = typeof formData.get("confirm") === "string" ? (formData.get("confirm") as string) : "";

  const supabase = await createSupabaseServerClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/admin/forgot-password?error=expired");

  if (password.length < 10 || password.length > 72) redirect("/admin/reset-password?error=weak");
  if (password !== confirm) redirect("/admin/reset-password?error=mismatch");

  const { error } = await supabase.auth.updateUser({ password });
  if (error) {
    console.error("Password update failed:", error.message);
    redirect("/admin/reset-password?error=failed");
  }
  const staff = await getStaff();
  if (staff) await logActivity({ user: staff, action: "auth.password_changed" });
  redirect("/admin?notice=password-updated");
}
