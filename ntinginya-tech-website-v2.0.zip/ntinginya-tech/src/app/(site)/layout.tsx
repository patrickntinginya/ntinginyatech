import type { ReactNode } from "react";
import { siteConfig } from "@/config/site";
import { Footer } from "@/components/layout/Footer";
import { Header } from "@/components/layout/Header";
import { contactLinks, getSiteSettings, socialLinks } from "@/lib/settings";

export default async function SiteLayout({ children }: { children: ReactNode }) {
  const settings = await getSiteSettings();
  const links = contactLinks(settings);
  const sameAs = socialLinks(settings).map((s) => s.url);

  // Only facts the company has provided. No address, founding date, staff numbers, ratings or invented profiles.
  const structuredData = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "Organization",
        "@id": `${siteConfig.url}/#organization`,
        name: settings.siteTitle,
        url: siteConfig.url,
        description: settings.siteDescription,
        slogan: siteConfig.tagline,
        email: links.email,
        telephone: `+${settings.phone.replace(/[^\d]/g, "")}`,
        ...(sameAs.length > 0 ? { sameAs } : {}),
        contactPoint: [
          {
            "@type": "ContactPoint",
            contactType: "customer support",
            email: links.email,
            telephone: `+${settings.phone.replace(/[^\d]/g, "")}`,
          },
        ],
      },
      {
        "@type": "WebSite",
        "@id": `${siteConfig.url}/#website`,
        url: siteConfig.url,
        name: settings.siteTitle,
        description: settings.siteDescription,
        publisher: { "@id": `${siteConfig.url}/#organization` },
        inLanguage: "en",
      },
    ],
  };

  return (
    <>
      <a href="#main" className="skip-link">
        Skip to main content
      </a>
      <Header />
      <main id="main">{children}</main>
      <Footer />
      <script
        type="application/ld+json"
        // Static JSON built from site settings. Escape "<" so the JSON can never close the script tag.
        dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData).replace(/</g, "\\u003c") }}
      />
    </>
  );
}
