import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { PostCard } from "@/components/news/PostCard";
import { ButtonLink } from "@/components/ui/Button";
import { CmsImage } from "@/components/ui/CmsImage";
import { Container } from "@/components/ui/Container";
import { siteConfig } from "@/config/site";
import { getPostBySlug, getPublishedPosts } from "@/lib/cms/queries";
import { readingMinutes, sanitizeArticleHtml } from "@/lib/cms/sanitize";
import { formatDate } from "@/lib/format";
import { getSiteSettings } from "@/lib/settings";

// Articles are cached for a minute and refreshed the moment the admin publishes or edits them.
export const revalidate = 60;

type Props = { params: Promise<{ slug: string }> | { slug: string } };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const [post, settings] = await Promise.all([getPostBySlug(slug), getSiteSettings()]);

  // Drafts, archived and unknown posts are never indexed.
  if (!post) return { title: "Article not found", robots: { index: false, follow: false } };

  const title = post.seo_title || post.title;
  const description = post.seo_description || post.excerpt || settings.defaultSeoDescription;
  const image = post.social_image || post.featured_image || "/opengraph-image";
  const path = `/news/${post.slug}`;

  return {
    title,
    description,
    alternates: { canonical: path },
    openGraph: {
      type: "article",
      siteName: settings.siteTitle,
      title,
      description,
      url: path,
      publishedTime: post.published_at ?? undefined,
      modifiedTime: post.updated_at,
      authors: post.author?.full_name ? [post.author.full_name] : undefined,
      images: [{ url: image, alt: post.title }],
    },
    twitter: { card: "summary_large_image", title, description, images: [image] },
  };
}

export default async function ArticlePage({ params }: Props) {
  const { slug } = await params;
  const post = await getPostBySlug(slug);
  if (!post) notFound();

  const settings = await getSiteSettings();
  const { posts: latest } = await getPublishedPosts({ limit: 4 });
  const related = latest.filter((p) => p.id !== post.id).slice(0, 3);

  const html = sanitizeArticleHtml(post.content); // cleaned again at render time, as defence in depth
  const minutes = readingMinutes(post.content);
  const url = `${siteConfig.url}/news/${post.slug}`;
  const image = post.social_image || post.featured_image;

  const articleData = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: post.title,
    description: post.seo_description || post.excerpt || undefined,
    image: image ? [image] : undefined,
    datePublished: post.published_at ?? undefined,
    dateModified: post.updated_at,
    mainEntityOfPage: { "@type": "WebPage", "@id": url },
    author: post.author?.full_name
      ? { "@type": "Person", name: post.author.full_name }
      : { "@type": "Organization", name: settings.siteTitle },
    publisher: { "@type": "Organization", name: settings.siteTitle, url: siteConfig.url },
  };

  return (
    <>
      <article>
        <header className="band-hero relative overflow-hidden border-b border-brand/15">
          <Container className="py-14 sm:py-20">
            <nav aria-label="Breadcrumb" className="text-sm text-fg-3">
              <ol className="flex flex-wrap items-center gap-2">
                <li>
                  <Link href="/" className="underline-offset-4 hover:text-fg hover:underline">
                    Home
                  </Link>
                </li>
                <li aria-hidden="true">/</li>
                <li>
                  <Link href="/news" className="underline-offset-4 hover:text-fg hover:underline">
                    News &amp; Insights
                  </Link>
                </li>
              </ol>
            </nav>

            {post.category ? (
              <p className="mt-8 text-xs font-semibold uppercase tracking-wider text-brand-light">{post.category.name}</p>
            ) : null}
            <h1 className="mt-3 max-w-4xl font-sans text-3xl font-semibold leading-[1.1] tracking-[-0.03em] text-fg text-balance sm:text-5xl">
              {post.title}
            </h1>
            {post.excerpt ? <p className="mt-5 max-w-3xl text-lg leading-relaxed text-fg-2 sm:text-xl">{post.excerpt}</p> : null}
            <p className="mt-6 text-sm text-fg-3">
              {post.published_at ? <time dateTime={post.published_at}>{formatDate(post.published_at)}</time> : null}
              {post.author?.full_name ? <span> · {post.author.full_name}</span> : null}
              <span> · {minutes} min read</span>
            </p>
          </Container>
        </header>

        <div className="band-ink py-12 sm:py-16">
          <Container>
            {post.featured_image ? (
              <figure className="mx-auto max-w-4xl">
                <div className="card-surface relative aspect-[16/9] overflow-hidden">
                  <CmsImage
                    src={post.featured_image}
                    alt={post.featured_image_alt ?? ""}
                    sizes="(min-width: 1024px) 896px, 100vw"
                    priority
                  />
                </div>
              </figure>
            ) : null}

            <div className="mx-auto mt-10 max-w-3xl">
              {/* The HTML was sanitized when saved and again just above: no scripts, handlers or iframes can get through. */}
              <div className="article" dangerouslySetInnerHTML={{ __html: html }} />

              {post.tags.length > 0 ? (
                <ul className="mt-10 flex flex-wrap gap-2" aria-label="Tags">
                  {post.tags.map((t) => (
                    <li key={t.slug} className="rounded-full border border-fg-3/30 px-3 py-1 text-sm text-fg-2">
                      {t.name}
                    </li>
                  ))}
                </ul>
              ) : null}

              <div className="mt-12 flex flex-col gap-3 border-t border-fg-3/15 pt-8 sm:flex-row sm:items-center sm:justify-between">
                <Link href="/news" className="inline-flex min-h-11 items-center gap-2 font-semibold text-brand-light underline-offset-4 hover:underline">
                  <ArrowLeft aria-hidden="true" className="h-4 w-4" />
                  All articles
                </Link>
                <ButtonLink href={`/contact?subject=${encodeURIComponent(`About: ${post.title}`.slice(0, 190))}`} variant="secondary">
                  Talk to Ntinginya Tech
                </ButtonLink>
              </div>
            </div>
          </Container>
        </div>
      </article>

      {related.length > 0 ? (
        <section aria-labelledby="related" className="band-navy py-16 sm:py-20">
          <Container>
            <h2 id="related" className="font-sans text-2xl font-semibold tracking-tight text-fg">
              More from News &amp; Insights
            </h2>
            <ul className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {related.map((p) => (
                <li key={p.id} className="min-w-0">
                  <PostCard post={p} />
                </li>
              ))}
            </ul>
          </Container>
        </section>
      ) : null}

      <script
        type="application/ld+json"
        // Built from the post's own fields. Escape "<" so the JSON can never close the script tag.
        dangerouslySetInnerHTML={{ __html: JSON.stringify(articleData).replace(/</g, "\\u003c") }}
      />
    </>
  );
}
