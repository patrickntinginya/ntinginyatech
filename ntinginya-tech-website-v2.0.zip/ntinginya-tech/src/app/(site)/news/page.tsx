import Link from "next/link";
import { Search } from "lucide-react";
import { FeaturedPostCard, PostCard } from "@/components/news/PostCard";
import { PageHero } from "@/components/sections/PageHero";
import { Section } from "@/components/ui/Section";
import { isSupabasePublicConfigured } from "@/lib/env";
import { getCategories, getFeaturedPost, getPublishedPosts, PAGE_SIZE } from "@/lib/cms/queries";
import { cn } from "@/lib/cn";
import { buildMetadata } from "@/lib/metadata";

export const metadata = buildMetadata({
  title: "News & Insights",
  description:
    "News, research notes and updates from Ntinginya Tech on software, agriculture and livestock technology, AI, education and innovation in Tanzania.",
  path: "/news",
});

type SearchParams = { q?: string | string[]; category?: string | string[]; page?: string | string[] };

const first = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) ?? "";

function href(params: { q?: string; category?: string; page?: number }): string {
  const sp = new URLSearchParams();
  if (params.q) sp.set("q", params.q);
  if (params.category) sp.set("category", params.category);
  if (params.page && params.page > 1) sp.set("page", String(params.page));
  const qs = sp.toString();
  return qs ? `/news?${qs}` : "/news";
}

export default async function NewsPage({ searchParams }: { searchParams: Promise<SearchParams> | SearchParams }) {
  const sp = await searchParams;
  const q = first(sp.q).trim().slice(0, 80);
  const category = first(sp.category).trim().slice(0, 80);
  const page = Math.max(1, Math.min(200, Number.parseInt(first(sp.page), 10) || 1));
  const filtering = Boolean(q || category);

  const [categories, featured, { posts, total }] = await Promise.all([
    getCategories(),
    !filtering && page === 1 ? getFeaturedPost() : Promise.resolve(null),
    getPublishedPosts({ q, category, page }),
  ]);

  const gridPosts = featured ? posts.filter((p) => p.id !== featured.id) : posts;
  const pageCount = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const configured = isSupabasePublicConfigured();

  return (
    <>
      <PageHero
        crumb="News & Insights"
        title="News & Insights"
        description="Practical technology, research notes and honest progress updates from Ntinginya Tech."
      />

      <Section tone="mist" spacing="tight">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
          <form action="/news" method="get" role="search" className="flex w-full max-w-md gap-2">
            {category ? <input type="hidden" name="category" value={category} /> : null}
            <label htmlFor="news-search" className="sr-only">
              Search articles
            </label>
            <input
              id="news-search"
              name="q"
              type="search"
              defaultValue={q}
              maxLength={80}
              placeholder="Search articles"
              className="min-h-11 w-full rounded-lg border border-fg-3/40 bg-navy px-3.5 text-base text-fg placeholder:text-fg-3 focus-visible:border-brand focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand"
            />
            <button
              type="submit"
              className="inline-flex min-h-11 shrink-0 items-center gap-2 rounded-lg bg-brand px-4 font-semibold text-navy transition-colors hover:bg-brand-light"
            >
              <Search aria-hidden="true" className="h-4 w-4" />
              Search
            </button>
          </form>

          <nav aria-label="Categories">
            <ul className="flex flex-wrap gap-2">
              <li>
                <Link
                  href={href({ q })}
                  aria-current={!category ? "page" : undefined}
                  className={cn(
                    "inline-flex min-h-9 items-center rounded-full border px-3.5 text-sm font-medium transition-colors",
                    !category ? "border-brand bg-brand/15 text-brand-light" : "border-fg-3/30 text-fg-2 hover:border-brand-light hover:text-fg",
                  )}
                >
                  All
                </Link>
              </li>
              {categories.map((c) => (
                <li key={c.id}>
                  <Link
                    href={href({ q, category: c.slug })}
                    aria-current={category === c.slug ? "page" : undefined}
                    className={cn(
                      "inline-flex min-h-9 items-center rounded-full border px-3.5 text-sm font-medium transition-colors",
                      category === c.slug ? "border-brand bg-brand/15 text-brand-light" : "border-fg-3/30 text-fg-2 hover:border-brand-light hover:text-fg",
                    )}
                  >
                    {c.name}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
        </div>

        {featured ? (
          <div className="mt-10">
            <FeaturedPostCard post={featured} />
          </div>
        ) : null}

        {gridPosts.length > 0 ? (
          <>
            <h2 className="mt-14 font-sans text-2xl font-semibold tracking-tight">{filtering ? "Results" : "Latest articles"}</h2>
            <ul className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {gridPosts.map((post) => (
                <li key={post.id} className="min-w-0">
                  <PostCard post={post} />
                </li>
              ))}
            </ul>
          </>
        ) : !featured ? (
          <div className="mt-12 rounded-2xl border border-dashed border-fg-3/40 p-8">
            <p className="font-sans text-lg font-semibold text-fg">
              {!configured ? "News is not available yet." : filtering ? "No articles match your search." : "No articles have been published yet."}
            </p>
            <p className="mt-1 max-w-xl text-[0.9375rem] leading-relaxed text-fg-2">
              {filtering ? (
                <>
                  Try a different word, or <Link href="/news" className="text-brand-light underline underline-offset-4">see all articles</Link>.
                </>
              ) : (
                "Check back soon. We publish here as we have something useful to share."
              )}
            </p>
          </div>
        ) : null}

        {pageCount > 1 ? (
          <nav aria-label="Pagination" className="mt-12 flex items-center justify-between gap-4">
            {page > 1 ? (
              <Link href={href({ q, category, page: page - 1 })} className="inline-flex min-h-11 items-center rounded-lg border border-fg-3/40 px-4 font-semibold text-fg hover:border-brand-light">
                Newer articles
              </Link>
            ) : (
              <span />
            )}
            <p className="text-sm text-fg-3">
              Page {page} of {pageCount}
            </p>
            {page < pageCount ? (
              <Link href={href({ q, category, page: page + 1 })} className="inline-flex min-h-11 items-center rounded-lg border border-fg-3/40 px-4 font-semibold text-fg hover:border-brand-light">
                Older articles
              </Link>
            ) : (
              <span />
            )}
          </nav>
        ) : null}
      </Section>
    </>
  );
}
