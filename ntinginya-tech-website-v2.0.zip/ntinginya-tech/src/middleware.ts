import { NextResponse, type NextRequest } from "next/server";
import { isSupabasePublicConfigured } from "@/lib/env";
import { updateSession } from "@/lib/supabase/middleware";

/** Pages inside /admin that must be reachable without being signed in. */
const OPEN_ADMIN_PATHS = ["/admin/login", "/admin/forgot-password", "/admin/reset-password", "/admin/auth"];

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const isOpen = OPEN_ADMIN_PATHS.some((p) => pathname === p || pathname.startsWith(`${p}/`));

  // Without Supabase nobody can sign in, so only the login page (which explains this) is reachable.
  if (!isSupabasePublicConfigured()) {
    return isOpen ? NextResponse.next() : NextResponse.redirect(new URL("/admin/login", request.url));
  }

  const { response, user } = await updateSession(request);

  if (!user && !isOpen) {
    const login = new URL("/admin/login", request.url);
    login.searchParams.set("next", pathname);
    return NextResponse.redirect(login);
  }
  if (user && pathname === "/admin/login") {
    return NextResponse.redirect(new URL("/admin", request.url));
  }

  response.headers.set("Cache-Control", "no-store");
  return response;
}

// Every /admin page. The pages and actions ALSO check permissions on the server (see lib/auth.ts).
export const config = { matcher: ["/admin/:path*"] };
