/**
 * Environment checks. NEVER return secret values from here: only whether they are set.
 * NEXT_PUBLIC_* values are read with literal names so Next.js can inline them at build time.
 */
export function supabaseUrl(): string {
  return process.env.NEXT_PUBLIC_SUPABASE_URL ?? "";
}

export function supabaseAnonKey(): string {
  return process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "";
}

/** Public reads and sign-in need only the URL and the anon (public) key. */
export function isSupabasePublicConfigured(): boolean {
  return Boolean(supabaseUrl() && supabaseAnonKey());
}

/** Admin features additionally need the service-role key, which exists on the server only. */
export function isSupabaseAdminConfigured(): boolean {
  return isSupabasePublicConfigured() && Boolean(process.env.SUPABASE_SERVICE_ROLE_KEY);
}

export type ConfigCheck = { name: string; ok: boolean; required: boolean; note: string };

/** Used by the admin overview so the owner can see what is missing. Booleans only. */
export function configChecks(): ConfigCheck[] {
  return [
    { name: "RESEND_API_KEY", ok: Boolean(process.env.RESEND_API_KEY), required: true, note: "Needed to email contact messages to you." },
    { name: "CONTACT_TO_EMAIL", ok: Boolean(process.env.CONTACT_TO_EMAIL), required: false, note: "Optional. Defaults to ntinginyatech@gmail.com." },
    { name: "CONTACT_FROM_EMAIL", ok: Boolean(process.env.CONTACT_FROM_EMAIL), required: false, note: "Optional until you verify a domain in Resend. Defaults to Resend's test sender." },
    { name: "NEXT_PUBLIC_SUPABASE_URL", ok: Boolean(supabaseUrl()), required: true, note: "Database, sign-in and images." },
    { name: "NEXT_PUBLIC_SUPABASE_ANON_KEY", ok: Boolean(supabaseAnonKey()), required: true, note: "Public key for reading published content." },
    { name: "SUPABASE_SERVICE_ROLE_KEY", ok: Boolean(process.env.SUPABASE_SERVICE_ROLE_KEY), required: true, note: "Server-only key for admin actions and saving messages." },
    { name: "NEXT_PUBLIC_SITE_URL", ok: Boolean(process.env.NEXT_PUBLIC_SITE_URL), required: false, note: "Your real domain. Until set, Netlify's automatic URL is used." },
  ];
}
