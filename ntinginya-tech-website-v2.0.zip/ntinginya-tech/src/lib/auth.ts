import "server-only";
import { cache } from "react";
import { redirect } from "next/navigation";
import { isSupabaseAdminConfigured } from "@/lib/env";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { createSupabaseServerClient } from "@/lib/supabase/server";

export type Role = "owner" | "admin" | "editor" | "author";

export type Staff = { id: string; email: string; fullName: string; role: Role };

/**
 * What each role may do. Today only owner and admin can enter the dashboard.
 * Editor and author are defined so that adding them later means changing this table and
 * ADMIN_ROLES, not rewriting every action.
 */
export type Permission =
  | "posts:write"
  | "posts:publish"
  | "posts:delete"
  | "categories:manage"
  | "media:manage"
  | "messages:manage"
  | "settings:write"
  | "users:manage";

const ALL: Permission[] = ["posts:write", "posts:publish", "posts:delete", "categories:manage", "media:manage", "messages:manage", "settings:write"];

const PERMISSIONS: Record<Role, Permission[]> = {
  owner: [...ALL, "users:manage"],
  admin: ALL,
  editor: ["posts:write", "posts:publish", "media:manage"],
  author: ["posts:write", "media:manage"],
};

/** Roles that may open the dashboard right now. */
const DASHBOARD_ROLES: Role[] = ["owner", "admin"];

export function can(staff: Staff, permission: Permission): boolean {
  return PERMISSIONS[staff.role].includes(permission);
}

/**
 * The signed-in, active owner/admin, or null. Verified against Supabase on every call
 * (the token is validated by Supabase, and the role is read from the database), never from the browser.
 */
export const getStaff = cache(async (): Promise<Staff | null> => {
  if (!isSupabaseAdminConfigured()) return null;

  const supabase = await createSupabaseServerClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return null;

  const admin = createSupabaseAdminClient();
  const { data: profile } = await admin
    .from("profiles")
    .select("id, full_name, role, is_active")
    .eq("id", user.id)
    .maybeSingle();

  if (!profile || !profile.is_active || !DASHBOARD_ROLES.includes(profile.role as Role)) return null;

  return {
    id: user.id,
    email: user.email ?? "",
    fullName: (profile.full_name as string) || (user.email ?? "Admin"),
    role: profile.role as Role,
  };
});

/** For pages and server actions: sends anyone who is not allowed back to the login page. */
export async function requireStaff(permission?: Permission): Promise<Staff> {
  const staff = await getStaff();
  if (!staff) redirect("/admin/login?error=unauthorized");
  if (permission && !can(staff, permission)) redirect("/admin?error=forbidden");
  return staff;
}

/** Only allow redirects to pages inside /admin, so a crafted "next" link cannot send people elsewhere. */
export function safeAdminPath(value: unknown, fallback = "/admin"): string {
  if (typeof value !== "string") return fallback;
  if (!value.startsWith("/admin") || value.startsWith("//") || value.includes("\\")) return fallback;
  return value;
}
