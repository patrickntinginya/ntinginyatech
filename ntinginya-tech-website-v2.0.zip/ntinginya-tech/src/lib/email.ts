import "server-only";
import { contactInfo } from "@/config/site";

export type EmailStatus = "sent" | "failed" | "not_configured";
export type EmailResult = { status: EmailStatus; detail: string };

/**
 * Resend's shared test sender. It needs no domain verification, BUT Resend only delivers mail sent
 * from it to the email address that owns the Resend account. Once a domain is verified in Resend,
 * set CONTACT_FROM_EMAIL to an address on that domain.
 */
export const DEFAULT_FROM = "Ntinginya Tech Website <onboarding@resend.dev>";

/** Where notifications go, and who they appear to come from. Neither value is a secret. */
export function emailRouting() {
  return {
    to: process.env.CONTACT_TO_EMAIL?.trim() || contactInfo.email,
    from: process.env.CONTACT_FROM_EMAIL?.trim() || DEFAULT_FROM,
    usingTestSender: !process.env.CONTACT_FROM_EMAIL?.trim(),
  };
}

/**
 * Sends one plain-text email through Resend. The API key is read here, on the server, and never leaves it.
 * `detail` is Resend's own explanation when something fails. It is written to the server log and shown
 * only inside the admin dashboard, never to website visitors.
 */
export async function sendViaResend(input: { subject: string; text: string; replyTo?: string }): Promise<EmailResult> {
  const apiKey = process.env.RESEND_API_KEY?.trim();
  if (!apiKey) {
    console.error("Email: RESEND_API_KEY is not set in this environment, so no email was sent.");
    return { status: "not_configured", detail: "RESEND_API_KEY is not set in this deployment." };
  }
  const { to, from } = emailRouting();

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 10_000);
  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from,
        to: [to],
        ...(input.replyTo ? { reply_to: input.replyTo } : {}),
        subject: input.subject.slice(0, 250),
        text: input.text,
      }),
      signal: controller.signal,
    });

    // "Sent" only when Resend itself accepted the message.
    if (response.ok) return { status: "sent", detail: "Accepted by Resend." };

    let detail = "";
    try {
      const body = (await response.json()) as { name?: string; message?: string };
      detail = `${body.name ?? ""} ${body.message ?? ""}`.trim();
    } catch {
      /* no JSON body */
    }
    console.error(`Email: Resend rejected the message (HTTP ${response.status}). ${detail}`);
    return { status: "failed", detail: `Resend answered HTTP ${response.status}. ${detail}`.trim() };
  } catch {
    console.error("Email: could not reach Resend (network error or timeout).");
    return { status: "failed", detail: "Could not reach Resend (network error or timeout)." };
  } finally {
    clearTimeout(timeout);
  }
}
