import "server-only";
import { adminDb } from "@/lib/admin-db";
import type { Category, MediaItem, PostStatus } from "./types";

export const ADMIN_PAGE_SIZE = 20;

export type AdminPostRow = {
  id: string;
  title: string;
  slug: string;
  status: PostStatus;
  updated_at: string;
  published_at: string | null;
  category: { name: string } | null;
  author: { full_name: string } | null;
};

export type AdminPost = {
  id: string;
  title: string;
  slug: string;
  excerpt: string | null;
  content: string;
  featured_image: string | null;
  featured_image_alt: string | null;
  category_id: string | null;
  author_id: string | null;
  status: PostStatus;
  is_featured: boolean;
  published_at: string | null;
  seo_title: string | null;
  seo_description: string | null;
  social_image: string | null;
  tags: string[];
};

export type MessageRow = {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  inquiry_type: string | null;
  subject: string;
  message: string;
  status: "unread" | "read";
  email_status: "sent" | "failed" | "not_configured" | "not_sent";
  created_at: string;
};

export type ActivityRow = {
  id: number;
  user_label: string | null;
  action: string;
  target_type: string | null;
  target_label: string | null;
  created_at: string;
};

export type UserRow = { id: string; email: string; full_name: string; role: string; is_active: boolean; created_at: string };

/** Escapes characters with meaning in PostgREST filters so search text cannot alter the query. */
export function safeTerm(value: string): string {
  return value.replace(/[%,()*\\]/g, " ").trim().slice(0, 80);
}

export async function getDashboard() {
  const { db } = await adminDb();
  const count = async (table: string, apply?: (q: any) => any) => {
    let q = db.from(table).select("id", { count: "exact", head: true });
    if (apply) q = apply(q);
    const { count: n } = await q;
    return n ?? 0;
  };
  const [posts, published, drafts, archived, categories, messages, unread] = await Promise.all([
    count("posts"),
    count("posts", (q) => q.eq("status", "published")),
    count("posts", (q) => q.eq("status", "draft")),
    count("posts", (q) => q.eq("status", "archived")),
    count("categories"),
    count("contact_messages"),
    count("contact_messages", (q) => q.eq("status", "unread")),
  ]);
  const [recentPosts, recentMessages, recentActivity] = await Promise.all([
    db.from("posts").select("id, title, status, updated_at").order("updated_at", { ascending: false }).limit(5),
    db.from("contact_messages").select("id, name, subject, status, created_at").order("created_at", { ascending: false }).limit(5),
    db.from("activity_logs").select("id, user_label, action, target_label, created_at").order("created_at", { ascending: false }).limit(8),
  ]);
  return {
    counts: { posts, published, drafts, archived, categories, messages, unread },
    recentPosts: (recentPosts.data ?? []) as { id: string; title: string; status: PostStatus; updated_at: string }[],
    recentMessages: (recentMessages.data ?? []) as { id: string; name: string; subject: string; status: string; created_at: string }[],
    recentActivity: (recentActivity.data ?? []) as { id: number; user_label: string | null; action: string; target_label: string | null; created_at: string }[],
  };
}

export async function getUnreadCount(): Promise<number> {
  const { db } = await adminDb();
  const { count } = await db.from("contact_messages").select("id", { count: "exact", head: true }).eq("status", "unread");
  return count ?? 0;
}

export async function listAdminPosts(f: { status?: string; q?: string; page?: number }) {
  const { db } = await adminDb();
  const page = Math.max(1, f.page ?? 1);
  let q = db
    .from("posts")
    .select("id, title, slug, status, updated_at, published_at, category:categories(name), author:profiles(full_name)", { count: "exact" })
    .order("updated_at", { ascending: false })
    .range((page - 1) * ADMIN_PAGE_SIZE, page * ADMIN_PAGE_SIZE - 1);
  if (f.status && ["draft", "published", "archived"].includes(f.status)) q = q.eq("status", f.status);
  const term = f.q ? safeTerm(f.q) : "";
  if (term) q = q.or(`title.ilike.%${term}%,slug.ilike.%${term}%`);
  const { data, count } = await q;
  return { rows: (data ?? []) as unknown as AdminPostRow[], total: count ?? 0 };
}

export async function getAdminPost(id: string): Promise<AdminPost | null> {
  const { db } = await adminDb();
  const { data } = await db
    .from("posts")
    .select("id, title, slug, excerpt, content, featured_image, featured_image_alt, category_id, author_id, status, is_featured, published_at, seo_title, seo_description, social_image, post_tags(tag:tags(name))")
    .eq("id", id)
    .maybeSingle();
  if (!data) return null;
  const row = data as unknown as AdminPost & { post_tags?: { tag: { name: string } | null }[] };
  const tags = (row.post_tags ?? []).map((t) => t.tag?.name).filter((n): n is string => Boolean(n));
  const { post_tags: _ignored, ...rest } = row;
  return { ...rest, tags };
}

export async function listAdminCategories(): Promise<(Category & { posts: number })[]> {
  const { db } = await adminDb();
  const { data } = await db.from("categories").select("id, name, slug, description, posts(count)").order("name");
  return ((data ?? []) as any[]).map((c) => ({ id: c.id, name: c.name, slug: c.slug, description: c.description, posts: c.posts?.[0]?.count ?? 0 }));
}

export async function listAuthors(): Promise<{ id: string; full_name: string }[]> {
  const { db } = await adminDb();
  const { data } = await db.from("profiles").select("id, full_name").eq("is_active", true).in("role", ["owner", "admin", "editor", "author"]).order("full_name");
  return (data ?? []) as { id: string; full_name: string }[];
}

export async function listMessages(f: { filter?: string; page?: number }) {
  const { db } = await adminDb();
  const page = Math.max(1, f.page ?? 1);
  let q = db
    .from("contact_messages")
    .select("id, name, email, phone, inquiry_type, subject, message, status, email_status, created_at", { count: "exact" })
    .order("created_at", { ascending: false })
    .range((page - 1) * ADMIN_PAGE_SIZE, page * ADMIN_PAGE_SIZE - 1);
  if (f.filter === "unread" || f.filter === "read") q = q.eq("status", f.filter);
  const { data, count } = await q;
  return { rows: (data ?? []) as MessageRow[], total: count ?? 0 };
}

export async function listMediaItems(f: { q?: string; page?: number; limit?: number }): Promise<{ rows: MediaItem[]; total: number }> {
  const { db } = await adminDb();
  const limit = f.limit ?? 24;
  const page = Math.max(1, f.page ?? 1);
  let q = db
    .from("media")
    .select("id, url, filename, alt, width, height, size_bytes, created_at", { count: "exact" })
    .order("created_at", { ascending: false })
    .range((page - 1) * limit, page * limit - 1);
  const term = f.q ? safeTerm(f.q) : "";
  if (term) q = q.or(`filename.ilike.%${term}%,alt.ilike.%${term}%`);
  const { data, count } = await q;
  return { rows: (data ?? []) as MediaItem[], total: count ?? 0 };
}

export async function listActivity(page = 1) {
  const { db } = await adminDb();
  const p = Math.max(1, page);
  const { data, count } = await db
    .from("activity_logs")
    .select("id, user_label, action, target_type, target_label, created_at", { count: "exact" })
    .order("created_at", { ascending: false })
    .range((p - 1) * 50, p * 50 - 1);
  return { rows: (data ?? []) as ActivityRow[], total: count ?? 0 };
}

export async function listUsers(): Promise<UserRow[]> {
  const { db } = await adminDb("users:manage");
  const [{ data: profiles }, authList] = await Promise.all([
    db.from("profiles").select("id, full_name, role, is_active, created_at").order("created_at"),
    db.auth.admin.listUsers({ perPage: 200 }),
  ]);
  const emails = new Map((authList.data?.users ?? []).map((u) => [u.id, u.email ?? ""]));
  return ((profiles ?? []) as any[]).map((p) => ({ ...p, email: emails.get(p.id) ?? "" }));
}

export async function getSettingsRow(): Promise<unknown> {
  const { db } = await adminDb();
  const { data } = await db.from("site_settings").select("value").eq("key", "site").maybeSingle();
  return data?.value ?? null;
}

export async function getSeoOverview() {
  const { db } = await adminDb();
  const { data } = await db
    .from("posts")
    .select("id, title, slug, seo_title, seo_description, social_image, featured_image, excerpt, status")
    .eq("status", "published")
    .order("published_at", { ascending: false })
    .limit(200);
  return (data ?? []) as {
    id: string; title: string; slug: string; seo_title: string | null; seo_description: string | null;
    social_image: string | null; featured_image: string | null; excerpt: string | null; status: string;
  }[];
}

