/** Plain-English wording for audit-log actions. Unknown actions fall back to the raw code. */
const LABELS: Record<string, string> = {
  "auth.login": "Signed in",
  "auth.logout": "Signed out",
  "auth.password_changed": "Changed password",
  "post.created": "Created a post",
  "post.edited": "Edited a post",
  "post.published": "Published a post",
  "post.unpublished": "Unpublished a post",
  "post.archived": "Archived a post",
  "post.deleted": "Deleted a post",
  "category.created": "Created a category",
  "category.updated": "Edited a category",
  "category.deleted": "Deleted a category",
  "media.uploaded": "Uploaded an image",
  "media.deleted": "Deleted an image",
  "message.deleted": "Deleted a message",
  "settings.updated": "Changed site settings",
  "email.test": "Sent a test email",
  "user.created": "Created a user",
  "user.activated": "Activated a user",
  "user.deactivated": "Deactivated a user",
  "user.role_changed": "Changed a user role",
};

export function activityLabel(action: string): string {
  return LABELS[action] ?? action;
}
