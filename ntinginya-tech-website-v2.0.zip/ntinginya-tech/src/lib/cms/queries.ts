import { unstable_cache } from "next/cache";
import { createPublicClient } from "@/lib/supabase/public";
import type { Category, PostCard, PostFull } from "./types";

/**
 * Public read queries. They use the anon key, so the database itself only ever returns PUBLISHED posts.
 * Results are cached for 60 seconds and cleared immediately when the admin publishes or edits
 * (revalidateTag("posts")), so a new article shows up on /news straight away.
 */
export const POSTS_TAG = "posts";
export const PAGE_SIZE = 9;

const CARD_COLUMNS =
  "id, title, slug, excerpt, featured_image, featured_image_alt, published_at, is_featured, category:categories(name, slug), author:profiles(full_name)";

type Filters = { q?: string; category?: string; page?: number; limit?: number };

function nowIso(): string {
  // Rounded to the minute so the cache key does not change on every request.
  const d = new Date();
  d.setSeconds(0, 0);
  return d.toISOString();
}

async function fetchPosts(filters: Filters): Promise<{ posts: PostCard[]; total: number }> {
  const supabase = createPublicClient();
  if (!supabase) return { posts: [], total: 0 };

  const limit = filters.limit ?? PAGE_SIZE;
  const page = Math.max(1, filters.page ?? 1);

  let query = supabase
    .from("posts")
    .select(CARD_COLUMNS, { count: "exact" })
    .eq("status", "published")
    .lte("published_at", nowIso())
    .order("published_at", { ascending: false })
    .range((page - 1) * limit, page * limit - 1);

  if (filters.category) {
    const { data: cat } = await supabase.from("categories").select("id").eq("slug", filters.category).maybeSingle();
    if (!cat) return { posts: [], total: 0 };
    query = query.eq("category_id", cat.id);
  }

  if (filters.q) {
    // Strip characters that have meaning in the PostgREST filter syntax.
    const term = filters.q.replace(/[%,()*\\]/g, " ").trim().slice(0, 80);
    if (term) query = query.or(`title.ilike.%${term}%,excerpt.ilike.%${term}%`);
  }

  const { data, error, count } = await query;
  if (error) {
    console.error("News query failed:", error.message);
    return { posts: [], total: 0 };
  }
  return { posts: (data ?? []) as unknown as PostCard[], total: count ?? 0 };
}

export function getPublishedPosts(filters: Filters = {}) {
  // Free-text searches are not cached: every search term would create its own cache entry.
  if (filters.q) return fetchPosts(filters);
  return unstable_cache(() => fetchPosts(filters), ["published-posts", JSON.stringify(filters)], {
    revalidate: 60,
    tags: [POSTS_TAG],
  })();
}

/** The featured article: a post flagged "featured", otherwise the newest published post. */
export const getFeaturedPost = unstable_cache(
  async (): Promise<PostCard | null> => {
    const supabase = createPublicClient();
    if (!supabase) return null;
    const base = () =>
      supabase.from("posts").select(CARD_COLUMNS).eq("status", "published").lte("published_at", nowIso());
    const flagged = await base().eq("is_featured", true).order("published_at", { ascending: false }).limit(1).maybeSingle();
    if (flagged.data) return flagged.data as unknown as PostCard;
    const latest = await base().order("published_at", { ascending: false }).limit(1).maybeSingle();
    return (latest.data as unknown as PostCard) ?? null;
  },
  ["featured-post"],
  { revalidate: 60, tags: [POSTS_TAG] },
);

export const getCategories = unstable_cache(
  async (): Promise<Category[]> => {
    const supabase = createPublicClient();
    if (!supabase) return [];
    const { data } = await supabase.from("categories").select("id, name, slug").order("name");
    return (data ?? []) as Category[];
  },
  ["categories"],
  { revalidate: 60, tags: [POSTS_TAG] },
);

export const getPostBySlug = (slug: string) =>
  unstable_cache(
    async (): Promise<PostFull | null> => {
      const supabase = createPublicClient();
      if (!supabase) return null;
      const { data, error } = await supabase
        .from("posts")
        .select(`${CARD_COLUMNS}, content, seo_title, seo_description, social_image, updated_at, post_tags(tag:tags(name, slug))`)
        .eq("slug", slug)
        .eq("status", "published")
        .lte("published_at", nowIso())
        .maybeSingle();
      if (error || !data) return null;
      const row = data as unknown as PostFull & { post_tags?: { tag: { name: string; slug: string } | null }[] };
      const tags = (row.post_tags ?? []).map((pt) => pt.tag).filter((t): t is { name: string; slug: string } => Boolean(t));
      return { ...row, tags };
    },
    ["post", slug],
    { revalidate: 60, tags: [POSTS_TAG] },
  )();

/** Used by the sitemap. */
export const getPublishedSlugs = unstable_cache(
  async (): Promise<{ slug: string; updated_at: string }[]> => {
    const supabase = createPublicClient();
    if (!supabase) return [];
    const { data } = await supabase
      .from("posts")
      .select("slug, updated_at")
      .eq("status", "published")
      .lte("published_at", nowIso())
      .order("published_at", { ascending: false })
      .limit(1000);
    return (data ?? []) as { slug: string; updated_at: string }[];
  },
  ["published-slugs"],
  { revalidate: 300, tags: [POSTS_TAG] },
);
