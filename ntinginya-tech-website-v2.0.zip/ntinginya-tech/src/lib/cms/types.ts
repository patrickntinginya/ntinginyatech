export type PostStatus = "draft" | "published" | "archived";

export type Category = { id: string; name: string; slug: string; description?: string | null };

export type PostCard = {
  id: string;
  title: string;
  slug: string;
  excerpt: string | null;
  featured_image: string | null;
  featured_image_alt: string | null;
  published_at: string | null;
  is_featured: boolean;
  category: { name: string; slug: string } | null;
  author: { full_name: string } | null;
};

export type PostFull = PostCard & {
  content: string;
  seo_title: string | null;
  seo_description: string | null;
  social_image: string | null;
  updated_at: string;
  tags: { name: string; slug: string }[];
};

export type MediaItem = {
  id: string;
  url: string;
  filename: string;
  alt: string | null;
  width: number | null;
  height: number | null;
  size_bytes: number;
  created_at: string;
};
