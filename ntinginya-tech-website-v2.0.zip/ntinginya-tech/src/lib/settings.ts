import { unstable_cache } from "next/cache";
import { contactInfo, siteConfig } from "@/config/site";
import { createPublicClient } from "@/lib/supabase/public";

export const SETTINGS_TAG = "site-settings";

export type SocialLink = { label: string; url: string };

export type SiteSettings = {
  siteTitle: string;
  siteDescription: string;
  contactEmail: string;
  phone: string;
  whatsapp: string;
  location: string;
  socials: { linkedin: string; x: string; facebook: string; instagram: string; youtube: string };
  defaultSeoTitle: string;
  defaultSeoDescription: string;
};

export const SOCIAL_LABELS: Record<keyof SiteSettings["socials"], string> = {
  linkedin: "LinkedIn",
  x: "X",
  facebook: "Facebook",
  instagram: "Instagram",
  youtube: "YouTube",
};

/** What the site uses until (and unless) the owner saves different values in /admin/settings. */
export const DEFAULT_SETTINGS: SiteSettings = {
  siteTitle: siteConfig.name,
  siteDescription: siteConfig.description,
  contactEmail: contactInfo.email,
  phone: contactInfo.phone,
  whatsapp: contactInfo.phoneE164,
  location: contactInfo.location,
  socials: { linkedin: "", x: "", facebook: "", instagram: "", youtube: "" },
  defaultSeoTitle: siteConfig.title,
  defaultSeoDescription: siteConfig.description,
};

function str(value: unknown, fallback: string): string {
  return typeof value === "string" && value.trim() ? value.trim() : fallback;
}

/** Merges saved values over the defaults. Anything missing or malformed falls back to the default. */
export function mergeSettings(raw: unknown): SiteSettings {
  const v = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const s = (v.socials && typeof v.socials === "object" ? v.socials : {}) as Record<string, unknown>;
  const d = DEFAULT_SETTINGS;
  return {
    siteTitle: str(v.siteTitle, d.siteTitle),
    siteDescription: str(v.siteDescription, d.siteDescription),
    contactEmail: str(v.contactEmail, d.contactEmail),
    phone: str(v.phone, d.phone),
    whatsapp: str(v.whatsapp, d.whatsapp),
    location: str(v.location, d.location),
    socials: {
      linkedin: typeof s.linkedin === "string" ? s.linkedin : "",
      x: typeof s.x === "string" ? s.x : "",
      facebook: typeof s.facebook === "string" ? s.facebook : "",
      instagram: typeof s.instagram === "string" ? s.instagram : "",
      youtube: typeof s.youtube === "string" ? s.youtube : "",
    },
    defaultSeoTitle: str(v.defaultSeoTitle, d.defaultSeoTitle),
    defaultSeoDescription: str(v.defaultSeoDescription, d.defaultSeoDescription),
  };
}

export const getSiteSettings = unstable_cache(
  async (): Promise<SiteSettings> => {
    const supabase = createPublicClient();
    if (!supabase) return DEFAULT_SETTINGS;
    const { data, error } = await supabase.from("site_settings").select("value").eq("key", "site").maybeSingle();
    if (error) {
      console.error("Reading site settings failed:", error.message);
      return DEFAULT_SETTINGS;
    }
    return mergeSettings(data?.value);
  },
  ["site-settings"],
  { revalidate: 300, tags: [SETTINGS_TAG] },
);

/** Derived link formats for the contact details. */
export function contactLinks(s: SiteSettings) {
  const digits = (value: string) => value.replace(/[^\d]/g, "");
  return {
    email: s.contactEmail,
    mailto: `mailto:${s.contactEmail}`,
    phone: s.phone,
    phoneHref: `tel:+${digits(s.phone)}`,
    whatsappHref: `https://wa.me/${digits(s.whatsapp)}?text=${encodeURIComponent(
      "Hello Ntinginya Tech, I found you through your website and would like to talk.",
    )}`,
    location: s.location,
  };
}

export function socialLinks(s: SiteSettings): SocialLink[] {
  return (Object.keys(s.socials) as (keyof SiteSettings["socials"])[])
    .filter((k) => s.socials[k])
    .map((k) => ({ label: SOCIAL_LABELS[k], url: s.socials[k] }));
}
