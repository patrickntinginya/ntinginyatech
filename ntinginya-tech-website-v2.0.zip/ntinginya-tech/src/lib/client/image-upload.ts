import { uploadMediaAction, type UploadResult } from "@/app/admin/actions/media";

const MAX_SIDE = 2000;

type Prepared = { file: File; width: number; height: number };

/**
 * Shrinks a photo in the browser before it is uploaded. A phone photo is often 4 to 10 MB; after this it is
 * usually well under 1 MB, which uploads fast on mobile data and stays inside Netlify's request size limit.
 */
async function prepareImage(input: File): Promise<Prepared> {
  if (!input.type.startsWith("image/")) throw new Error("Choose an image file.");

  let bitmap: ImageBitmap;
  try {
    bitmap = await createImageBitmap(input);
  } catch {
    throw new Error("This image format is not supported. Use a JPEG, PNG or WebP photo.");
  }

  const scale = Math.min(1, MAX_SIDE / Math.max(bitmap.width, bitmap.height));
  const width = Math.max(1, Math.round(bitmap.width * scale));
  const height = Math.max(1, Math.round(bitmap.height * scale));

  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Your browser could not process this image.");
  context.drawImage(bitmap, 0, 0, width, height);
  bitmap.close();

  const toBlob = (type: string, quality: number) => new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, type, quality));
  let blob = await toBlob("image/webp", 0.85);
  if (!blob || blob.type !== "image/webp") blob = await toBlob("image/jpeg", 0.88);
  if (!blob) throw new Error("Your browser could not process this image.");

  const base = input.name.replace(/\.[^.]+$/, "").replace(/[^a-zA-Z0-9-_ ]+/g, "").trim().slice(0, 60) || "image";
  const extension = blob.type === "image/webp" ? "webp" : "jpg";
  return { file: new File([blob], `${base}.${extension}`, { type: blob.type }), width, height };
}

/** Shrinks the image, then sends it to the server, which checks it again (size, real file type, permissions). */
export async function uploadImage(input: File, alt: string): Promise<UploadResult> {
  try {
    const prepared = await prepareImage(input);
    const body = new FormData();
    body.append("file", prepared.file);
    body.append("width", String(prepared.width));
    body.append("height", String(prepared.height));
    body.append("alt", alt);
    return await uploadMediaAction(body);
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : "The upload failed. Please try again." };
  }
}
