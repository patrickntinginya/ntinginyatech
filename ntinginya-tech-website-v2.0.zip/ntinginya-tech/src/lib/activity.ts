import "server-only";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import type { Staff } from "@/lib/auth";

export type ActivityInput = {
  user: Pick<Staff, "id" | "fullName" | "email"> | null;
  action: string; // e.g. "post.published"
  targetType?: string;
  targetId?: string;
  targetLabel?: string;
  meta?: Record<string, unknown>;
};

/** Writes one line to the audit log. A logging failure must never break the action itself. */
export async function logActivity(input: ActivityInput): Promise<void> {
  try {
    const admin = createSupabaseAdminClient();
    const { error } = await admin.from("activity_logs").insert({
      user_id: input.user?.id ?? null,
      user_label: input.user ? input.user.fullName || input.user.email : null,
      action: input.action,
      target_type: input.targetType ?? null,
      target_id: input.targetId ?? null,
      target_label: input.targetLabel ?? null,
      meta: input.meta ?? null,
    });
    if (error) console.error("Activity log write failed:", error.message);
  } catch (error) {
    console.error("Activity log write failed:", error instanceof Error ? error.message : "unknown error");
  }
}
