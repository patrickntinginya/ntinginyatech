import "server-only";
import { requireStaff, type Permission, type Staff } from "@/lib/auth";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";

/**
 * The ONLY way admin pages, queries and actions obtain a database client.
 * It verifies (on the server, against Supabase) that the caller is an active owner/admin holding the
 * permission before handing over the service-role client. A page that forgets to check still cannot read data.
 */
export async function adminDb(permission?: Permission) {
  const staff: Staff = await requireStaff(permission);
  return { db: createSupabaseAdminClient(), staff };
}
