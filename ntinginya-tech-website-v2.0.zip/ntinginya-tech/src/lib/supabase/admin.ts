import "server-only";
import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { supabaseUrl } from "@/lib/env";

/**
 * Service-role client. It BYPASSES Row Level Security, so:
 *  - import it only from server code (the "server-only" import above makes the build fail otherwise),
 *  - call it only after the caller has been checked with requireStaff() / getStaff(),
 *    or in the contact API route, which validates input itself.
 * SUPABASE_SERVICE_ROLE_KEY must never have a NEXT_PUBLIC_ prefix.
 */
export function createSupabaseAdminClient(): SupabaseClient {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const url = supabaseUrl();
  if (!url || !key) throw new Error("Supabase admin client is not configured.");
  return createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
}
