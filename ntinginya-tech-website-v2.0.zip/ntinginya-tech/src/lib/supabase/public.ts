import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { isSupabasePublicConfigured, supabaseAnonKey, supabaseUrl } from "@/lib/env";

/**
 * Read-only client for public pages. Uses the anon key with no user session, so the database's
 * Row Level Security rules decide what is visible: only PUBLISHED posts, categories and settings.
 * Returns null when Supabase is not configured, so the public site keeps working without it.
 */
export function createPublicClient(): SupabaseClient | null {
  if (!isSupabasePublicConfigured()) return null;
  return createClient(supabaseUrl(), supabaseAnonKey(), {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
  });
}
