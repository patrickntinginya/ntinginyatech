/* eslint-disable @next/next/no-img-element */
"use client";

import { useState } from "react";
import { ImageIcon } from "lucide-react";
import { MediaPicker } from "@/components/admin/MediaPicker";
import { inputClass } from "@/components/admin/ui";
import { buttonStyles } from "@/components/ui/Button";

/** Picks one image from the media library. `name` is submitted with the form as the image address. */
export function ImageField({
  label,
  name,
  value,
  onChange,
  alt,
  onAltChange,
  altName,
  hint,
}: {
  label: string;
  name: string;
  value: string;
  onChange: (url: string) => void;
  alt?: string;
  onAltChange?: (alt: string) => void;
  altName?: string;
  hint?: string;
}) {
  const [open, setOpen] = useState(false);
  const altId = `${name}-alt`;

  return (
    <div>
      <p className="mb-1.5 text-sm font-semibold text-fg">{label}</p>
      <input type="hidden" name={name} value={value} />

      {value ? (
        <div className="overflow-hidden rounded-xl border border-fg-3/30 bg-navy">
          <img src={value} alt="" className="aspect-[16/9] w-full object-cover" />
        </div>
      ) : (
        <div className="flex aspect-[16/9] items-center justify-center rounded-xl border border-dashed border-fg-3/40 text-fg-3">
          <ImageIcon aria-hidden="true" className="h-8 w-8" />
          <span className="sr-only">No image chosen</span>
        </div>
      )}

      <div className="mt-3 flex flex-wrap gap-2">
        <button type="button" onClick={() => setOpen(true)} className={buttonStyles({ variant: "secondary" })}>
          {value ? "Change image" : "Choose image"}
        </button>
        {value ? (
          <button type="button" onClick={() => onChange("")} className={buttonStyles({ variant: "secondary" })}>
            Remove
          </button>
        ) : null}
      </div>

      {value && onAltChange ? (
        <div className="mt-3">
          <label htmlFor={altId} className="mb-1.5 block text-sm font-semibold text-fg">
            Image description (alt text)
          </label>
          <input id={altId} name={altName} value={alt ?? ""} onChange={(e) => onAltChange(e.target.value)} maxLength={200} className={inputClass} />
        </div>
      ) : null}
      {hint ? <p className="mt-1.5 text-sm text-fg-3">{hint}</p> : null}

      <MediaPicker
        open={open}
        onClose={() => setOpen(false)}
        onSelect={(item) => {
          onChange(item.url);
          if (onAltChange && !alt && item.alt) onAltChange(item.alt);
          setOpen(false);
        }}
      />
    </div>
  );
}
