"use client";

import type { ReactNode } from "react";
import { useFormStatus } from "react-dom";
import { buttonStyles } from "@/components/ui/Button";

/** Submit button that disables itself while the form is sending, and can ask "are you sure?" first. */
export function SubmitButton({
  children,
  variant = "primary",
  size = "md",
  className,
  name,
  value,
  confirm,
  pendingLabel,
}: {
  children: ReactNode;
  variant?: "primary" | "secondary" | "tech" | "danger";
  size?: "md" | "lg";
  className?: string;
  name?: string;
  value?: string;
  confirm?: string;
  pendingLabel?: string;
}) {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      name={name}
      value={value}
      disabled={pending}
      aria-busy={pending}
      onClick={(event) => {
        if (confirm && !window.confirm(confirm)) event.preventDefault();
      }}
      className={buttonStyles({ variant, size, className })}
    >
      {pending ? (pendingLabel ?? "Working…") : children}
    </button>
  );
}
