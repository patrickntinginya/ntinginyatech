"use client";

import { useActionState } from "react";
import { sendTestEmailAction, type TestEmailState } from "@/app/admin/actions/diagnostics";
import { SubmitButton } from "@/components/admin/SubmitButton";

const initial: TestEmailState = { ran: false, status: null, detail: "" };

export function TestEmailForm({ to }: { to: string }) {
  const [state, action] = useActionState(sendTestEmailAction, initial);
  return (
    <form action={action}>
      <p className="text-[0.9375rem] text-fg-2">
        Sends one real email to <strong className="text-fg">{to}</strong> through Resend, the same way the contact form does.
      </p>
      <SubmitButton variant="secondary" className="mt-4" pendingLabel="Sending…">
        Send a test email
      </SubmitButton>
      <div aria-live="polite" className="mt-4">
        {state.ran && state.status === "sent" ? (
          <p role="status" className="rounded-lg border border-brand/40 bg-brand/10 p-3 text-sm text-fg">
            Resend accepted the test email. Check the inbox (and the spam folder) in a minute.
          </p>
        ) : null}
        {state.ran && state.status && state.status !== "sent" ? (
          <p role="alert" className="rounded-lg border border-danger/40 bg-danger/10 p-3 text-sm text-fg">
            The test email was not sent. {state.detail}
          </p>
        ) : null}
      </div>
    </form>
  );
}
