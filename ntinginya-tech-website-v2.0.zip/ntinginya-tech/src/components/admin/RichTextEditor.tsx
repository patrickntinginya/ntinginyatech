"use client";

import { useState, type ReactNode } from "react";
import { EditorContent, useEditor, type Editor } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import LinkExtension from "@tiptap/extension-link";
import Placeholder from "@tiptap/extension-placeholder";
import Table from "@tiptap/extension-table";
import TableCell from "@tiptap/extension-table-cell";
import TableHeader from "@tiptap/extension-table-header";
import TableRow from "@tiptap/extension-table-row";
import { Bold, Code, Heading2, Heading3, ImageIcon, Italic, Link2, List, ListOrdered, Pilcrow, Quote, Redo2, Table2, Undo2 } from "lucide-react";
import { MediaPicker } from "@/components/admin/MediaPicker";
import { cn } from "@/lib/cn";
import { Figure } from "./figure-extension";

function Tool({
  label,
  onClick,
  active,
  disabled = false,
  children,
}: {
  label: string;
  onClick: () => void;
  active?: boolean; // leave out for plain action buttons; true/false for toggles
  disabled?: boolean;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      title={label}
      aria-label={label}
      aria-pressed={active}
      disabled={disabled}
      // Keeps the cursor in the article (and the phone keyboard open) while a toolbar button is tapped.
      onMouseDown={(event) => event.preventDefault()}
      onClick={onClick}
      className={cn(
        "inline-flex h-11 min-w-11 shrink-0 items-center justify-center gap-1 rounded-lg px-2.5 text-sm font-semibold transition-colors disabled:opacity-40",
        active ? "bg-brand text-navy" : "text-fg hover:bg-fg/10",
      )}
    >
      {children}
    </button>
  );
}

const Divider = () => <span aria-hidden="true" className="mx-1 h-6 w-px shrink-0 bg-fg-3/30" />;

function normaliseUrl(value: string): string | null {
  const v = value.trim();
  if (!v) return "";
  if (/^(https?:\/\/|mailto:|tel:)/i.test(v)) return v;
  if (/^[\w.-]+\.[a-z]{2,}(\/.*)?$/i.test(v)) return `https://${v}`;
  return null;
}

function Toolbar({ editor, onImage }: { editor: Editor; onImage: () => void }) {
  const chain = () => editor.chain().focus();

  function setLink() {
    const previous = (editor.getAttributes("link").href as string | undefined) ?? "";
    const input = window.prompt("Link address (leave empty to remove the link)", previous);
    if (input === null) return;
    const href = normaliseUrl(input);
    if (href === null) {
      window.alert("Enter a full web address, for example https://example.org");
      return;
    }
    if (href === "") chain().extendMarkRange("link").unsetLink().run();
    else chain().extendMarkRange("link").setLink({ href }).run();
  }

  function setCaption() {
    const current = (editor.getAttributes("figure").caption as string | undefined) ?? "";
    const caption = window.prompt("Image caption (leave empty for none)", current);
    if (caption !== null) chain().updateAttributes("figure", { caption: caption.slice(0, 200) }).run();
  }

  return (
    <div role="toolbar" aria-label="Formatting" className="flex items-center gap-0.5 overflow-x-auto border-b border-fg-3/25 bg-card p-1.5">
      <Tool label="Paragraph" active={editor.isActive("paragraph")} onClick={() => chain().setParagraph().run()}>
        <Pilcrow aria-hidden="true" className="h-4 w-4" />
      </Tool>
      <Tool label="Heading" active={editor.isActive("heading", { level: 2 })} onClick={() => chain().toggleHeading({ level: 2 }).run()}>
        <Heading2 aria-hidden="true" className="h-5 w-5" />
      </Tool>
      <Tool label="Sub-heading" active={editor.isActive("heading", { level: 3 })} onClick={() => chain().toggleHeading({ level: 3 }).run()}>
        <Heading3 aria-hidden="true" className="h-5 w-5" />
      </Tool>
      <Divider />
      <Tool label="Bold" active={editor.isActive("bold")} onClick={() => chain().toggleBold().run()}>
        <Bold aria-hidden="true" className="h-4 w-4" />
      </Tool>
      <Tool label="Italic" active={editor.isActive("italic")} onClick={() => chain().toggleItalic().run()}>
        <Italic aria-hidden="true" className="h-4 w-4" />
      </Tool>
      <Tool label="Link" active={editor.isActive("link")} onClick={setLink}>
        <Link2 aria-hidden="true" className="h-4 w-4" />
      </Tool>
      <Divider />
      <Tool label="Bullet list" active={editor.isActive("bulletList")} onClick={() => chain().toggleBulletList().run()}>
        <List aria-hidden="true" className="h-4 w-4" />
      </Tool>
      <Tool label="Numbered list" active={editor.isActive("orderedList")} onClick={() => chain().toggleOrderedList().run()}>
        <ListOrdered aria-hidden="true" className="h-4 w-4" />
      </Tool>
      <Tool label="Quote" active={editor.isActive("blockquote")} onClick={() => chain().toggleBlockquote().run()}>
        <Quote aria-hidden="true" className="h-4 w-4" />
      </Tool>
      <Tool label="Code block" active={editor.isActive("codeBlock")} onClick={() => chain().toggleCodeBlock().run()}>
        <Code aria-hidden="true" className="h-4 w-4" />
      </Tool>
      <Divider />
      <Tool label="Insert image" onClick={onImage}>
        <ImageIcon aria-hidden="true" className="h-4 w-4" />
      </Tool>
      {editor.isActive("figure") ? (
        <Tool label="Edit image caption" onClick={setCaption}>
          Caption
        </Tool>
      ) : null}
      <Tool label="Insert table" onClick={() => chain().insertTable({ rows: 3, cols: 3, withHeaderRow: true }).run()}>
        <Table2 aria-hidden="true" className="h-4 w-4" />
      </Tool>
      {editor.isActive("table") ? (
        <>
          <Tool label="Add table row" onClick={() => chain().addRowAfter().run()}>
            + Row
          </Tool>
          <Tool label="Add table column" onClick={() => chain().addColumnAfter().run()}>
            + Col
          </Tool>
          <Tool label="Delete table" onClick={() => chain().deleteTable().run()}>
            Delete table
          </Tool>
        </>
      ) : null}
      <Divider />
      <Tool label="Undo" disabled={!editor.can().undo()} onClick={() => chain().undo().run()}>
        <Undo2 aria-hidden="true" className="h-4 w-4" />
      </Tool>
      <Tool label="Redo" disabled={!editor.can().redo()} onClick={() => chain().redo().run()}>
        <Redo2 aria-hidden="true" className="h-4 w-4" />
      </Tool>
    </div>
  );
}

/**
 * The article editor. The HTML it produces is cleaned again on the server before it is saved,
 * so the browser is never trusted. Every button has a 44 px touch target and the toolbar scrolls sideways on phones.
 */
export function RichTextEditor({ initialHtml, onChange }: { initialHtml: string; onChange: (html: string) => void }) {
  const [pickerOpen, setPickerOpen] = useState(false);

  const editor = useEditor({
    extensions: [
      StarterKit.configure({ heading: { levels: [2, 3, 4] } }),
      LinkExtension.configure({ openOnClick: false, autolink: true, HTMLAttributes: { rel: "noopener noreferrer" } }),
      Figure,
      Table.configure({ resizable: false }),
      TableRow,
      TableHeader,
      TableCell,
      Placeholder.configure({ placeholder: "Write your article here…" }),
    ],
    content: initialHtml,
    immediatelyRender: false,
    editorProps: {
      attributes: {
        class: "article tiptap min-h-[20rem] px-4 py-4 sm:px-5",
        role: "textbox",
        "aria-multiline": "true",
        "aria-label": "Article content",
      },
    },
    onUpdate: ({ editor: e }) => onChange(e.getHTML()),
  });

  return (
    <div className="overflow-hidden rounded-xl border border-fg-3/40 bg-navy focus-within:border-brand focus-within:ring-2 focus-within:ring-brand">
      {editor ? (
        <>
          <Toolbar editor={editor} onImage={() => setPickerOpen(true)} />
          <MediaPicker
            open={pickerOpen}
            onClose={() => setPickerOpen(false)}
            onSelect={(item) => {
              editor
                .chain()
                .focus()
                .insertContent({ type: "figure", attrs: { src: item.url, alt: item.alt ?? "", caption: "" } })
                .run();
              setPickerOpen(false);
            }}
          />
        </>
      ) : (
        <div className="h-12 border-b border-fg-3/25 bg-card" aria-hidden="true" />
      )}
      <EditorContent editor={editor} />
    </div>
  );
}
