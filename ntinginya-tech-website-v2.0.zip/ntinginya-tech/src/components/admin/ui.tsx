import type { ReactNode } from "react";
import { cn } from "@/lib/cn";

export const inputClass =
  "min-h-11 w-full rounded-lg border border-fg-3/40 bg-navy px-3.5 py-2.5 text-base text-fg placeholder:text-fg-3 focus-visible:border-brand focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand";

/** Messages come from short codes in the URL, never from free text, so a crafted link cannot show arbitrary content. */
const NOTICES: Record<string, string> = {
  saved: "Saved.",
  created: "Created.",
  published: "Published. It is now live on the website.",
  unpublished: "Unpublished. It is no longer public.",
  archived: "Archived. It is no longer public.",
  deleted: "Deleted.",
  read: "Marked as read.",
  unread: "Marked as unread.",
  "message-deleted": "Message deleted.",
  updated: "Updated.",
  "signed-out": "You have signed out.",
  "password-updated": "Your password has been updated.",
};

const ERRORS: Record<string, string> = {
  forbidden: "You do not have permission to do that.",
  unauthorized: "That account is not allowed to use the dashboard.",
  invalid: "Please check the details and try again.",
  failed: "Something went wrong. Please try again.",
  missing: "That item no longer exists.",
  duplicate: "That name or web address is already in use.",
  empty: "Write some article content before publishing.",
  text: "Enter a site title and a description of at least 20 characters.",
  email: "Enter a valid contact email address.",
  phone: "Phone and WhatsApp numbers need 9 to 15 digits, including the country code.",
  social: "Social links must start with https://",
  weak: "Use a password of at least 10 characters.",
  self: "You cannot change your own account here.",
};

const first = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) ?? "";

export function Notice({ notice, error }: { notice?: string | string[]; error?: string | string[] }) {
  const n = NOTICES[first(notice)];
  const e = ERRORS[first(error)];
  if (!n && !e) return null;
  return (
    <div
      role={e ? "alert" : "status"}
      className={cn(
        "mb-6 rounded-xl border p-4 text-[0.9375rem]",
        e ? "border-danger/40 bg-danger/10 text-fg" : "border-brand/40 bg-brand/10 text-fg",
      )}
    >
      {e ?? n}
    </div>
  );
}

export function PageHeader({ title, description, actions }: { title: string; description?: string; actions?: ReactNode }) {
  return (
    <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-fg sm:text-3xl">{title}</h1>
        {description ? <p className="mt-1 max-w-2xl text-[0.9375rem] text-fg-2">{description}</p> : null}
      </div>
      {actions ? <div className="flex flex-wrap gap-2">{actions}</div> : null}
    </div>
  );
}

export function Panel({ title, children, className }: { title?: string; children: ReactNode; className?: string }) {
  return (
    <section className={cn("card-surface p-5 sm:p-6", className)}>
      {title ? <h2 className="mb-4 text-lg font-semibold text-fg">{title}</h2> : null}
      {children}
    </section>
  );
}

export function Field({ label, htmlFor, hint, children }: { label: string; htmlFor: string; hint?: string; children: ReactNode }) {
  return (
    <div>
      <label htmlFor={htmlFor} className="mb-1.5 block text-sm font-semibold text-fg">
        {label}
      </label>
      {children}
      {hint ? <p className="mt-1.5 text-sm text-fg-3">{hint}</p> : null}
    </div>
  );
}

const pills: Record<string, string> = {
  published: "bg-brand/15 text-brand-light border-brand/40",
  draft: "bg-warning/10 text-warning border-warning/40",
  archived: "bg-fg-3/10 text-fg-3 border-fg-3/40",
  unread: "bg-info/10 text-info border-info/40",
  read: "bg-fg-3/10 text-fg-3 border-fg-3/40",
  sent: "bg-brand/15 text-brand-light border-brand/40",
  failed: "bg-danger/10 text-danger border-danger/40",
  not_configured: "bg-warning/10 text-warning border-warning/40",
  not_sent: "bg-fg-3/10 text-fg-3 border-fg-3/40",
};

export function StatusPill({ status, label }: { status: string; label?: string }) {
  return (
    <span className={cn("inline-flex items-center rounded-md border px-2 py-0.5 text-xs font-semibold uppercase tracking-wide", pills[status] ?? pills.read)}>
      {label ?? status.replace("_", " ")}
    </span>
  );
}

export function Empty({ children }: { children: ReactNode }) {
  return <div className="rounded-2xl border border-dashed border-fg-3/40 p-8 text-center text-fg-2">{children}</div>;
}

export function Pager({ page, total, size, hrefFor }: { page: number; total: number; size: number; hrefFor: (p: number) => string }) {
  const pages = Math.max(1, Math.ceil(total / size));
  if (pages <= 1) return null;
  const link = "inline-flex min-h-11 items-center rounded-lg border border-fg-3/40 px-4 font-semibold text-fg hover:border-brand-light";
  return (
    <nav aria-label="Pagination" className="mt-8 flex items-center justify-between gap-3">
      {page > 1 ? <a className={link} href={hrefFor(page - 1)}>Newer</a> : <span />}
      <span className="text-sm text-fg-3">Page {page} of {pages}</span>
      {page < pages ? <a className={link} href={hrefFor(page + 1)}>Older</a> : <span />}
    </nav>
  );
}
