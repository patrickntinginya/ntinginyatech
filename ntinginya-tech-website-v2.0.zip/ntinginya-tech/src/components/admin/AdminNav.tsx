"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { FileText, History, Images, Inbox, LayoutDashboard, Search, Settings, Tags, Users } from "lucide-react";
import { cn } from "@/lib/cn";

const items = [
  { href: "/admin", label: "Overview", icon: LayoutDashboard },
  { href: "/admin/posts", label: "Posts", icon: FileText },
  { href: "/admin/categories", label: "Categories", icon: Tags },
  { href: "/admin/media", label: "Media", icon: Images },
  { href: "/admin/messages", label: "Messages", icon: Inbox },
  { href: "/admin/users", label: "Authors & users", icon: Users, ownerOnly: true },
  { href: "/admin/seo", label: "SEO", icon: Search },
  { href: "/admin/settings", label: "Settings", icon: Settings },
  { href: "/admin/activity", label: "Activity", icon: History },
];

export function AdminNav({ unread, isOwner }: { unread: number; isOwner: boolean }) {
  const pathname = usePathname();
  const active = (href: string) => (href === "/admin" ? pathname === "/admin" : pathname === href || pathname.startsWith(`${href}/`));

  return (
    <nav
      aria-label="Dashboard"
      className="sticky top-14 z-30 overflow-x-auto border-b border-fg-3/15 bg-ink/95 backdrop-blur lg:top-20 lg:self-start lg:overflow-visible lg:border-0 lg:bg-transparent lg:py-10"
    >
      <ul className="flex gap-1 px-3 py-2 lg:flex-col lg:px-0 lg:py-0">
        {items
          .filter((i) => !i.ownerOnly || isOwner)
          .map(({ href, label, icon: Icon }) => (
            <li key={href} className="shrink-0">
              <Link
                href={href}
                aria-current={active(href) ? "page" : undefined}
                className={cn(
                  "flex min-h-11 items-center gap-2.5 whitespace-nowrap rounded-lg px-3.5 text-[0.9375rem] font-medium transition-colors",
                  active(href) ? "bg-brand/15 text-brand-light" : "text-fg-2 hover:bg-fg/5 hover:text-fg",
                )}
              >
                <Icon aria-hidden="true" className="h-[1.125rem] w-[1.125rem]" />
                {label}
                {href === "/admin/messages" && unread > 0 ? (
                  <span className="ml-1 rounded-full bg-brand px-2 py-0.5 text-xs font-bold text-navy" aria-label={`${unread} unread`}>
                    {unread}
                  </span>
                ) : null}
              </Link>
            </li>
          ))}
      </ul>
    </nav>
  );
}
