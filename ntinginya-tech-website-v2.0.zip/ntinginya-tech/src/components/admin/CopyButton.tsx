"use client";

import { useState } from "react";
import { Check, Copy } from "lucide-react";

export function CopyButton({ value, label = "Copy link" }: { value: string; label?: string }) {
  const [done, setDone] = useState(false);
  return (
    <button
      type="button"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(value);
          setDone(true);
          setTimeout(() => setDone(false), 1800);
        } catch {
          window.prompt("Copy this link:", value);
        }
      }}
      className="inline-flex min-h-11 items-center gap-2 rounded-lg border border-fg-3/40 px-3 text-sm font-semibold text-fg hover:border-brand-light"
    >
      {done ? <Check aria-hidden="true" className="h-4 w-4 text-brand" /> : <Copy aria-hidden="true" className="h-4 w-4" />}
      {done ? "Copied" : label}
    </button>
  );
}
