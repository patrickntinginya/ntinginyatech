import { Node } from "@tiptap/core";

/**
 * An image with an optional caption, stored as <figure><img><figcaption>. It is one block that is selected
 * as a whole, which is easy to tap on a phone. The sanitizer allows exactly these three tags.
 */
export const Figure = Node.create({
  name: "figure",
  group: "block",
  atom: true,
  draggable: true,
  selectable: true,

  addAttributes() {
    return {
      src: { default: null },
      alt: { default: "" },
      caption: { default: "" },
    };
  },

  parseHTML() {
    return [
      {
        tag: "figure",
        getAttrs: (element) => {
          if (typeof element === "string") return false;
          const img = element.querySelector("img");
          if (!img) return false;
          return {
            src: img.getAttribute("src"),
            alt: img.getAttribute("alt") ?? "",
            caption: element.querySelector("figcaption")?.textContent ?? "",
          };
        },
      },
    ];
  },

  renderHTML({ node }) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const spec: any[] = ["figure", {}, ["img", { src: node.attrs.src, alt: node.attrs.alt }]];
    if (node.attrs.caption) spec.push(["figcaption", {}, node.attrs.caption]);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    return spec as any;
  },
});
