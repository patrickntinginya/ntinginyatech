"use client";

import { useActionState, useState } from "react";
import Link from "next/link";
import { ExternalLink } from "lucide-react";
import { savePostAction, type EditorState } from "@/app/admin/actions/posts";
import { ImageField } from "@/components/admin/ImageField";
import { RichTextEditor } from "@/components/admin/RichTextEditor";
import { SubmitButton } from "@/components/admin/SubmitButton";
import { Field, Panel, StatusPill, inputClass } from "@/components/admin/ui";
import type { AdminPost } from "@/lib/cms/admin-queries";
import { slugify } from "@/lib/cms/slug";
import type { Category } from "@/lib/cms/types";

const initialState: EditorState = { error: null };

/**
 * Create / edit a post. Every field is controlled by React state, so if the server rejects a save
 * (for example a duplicate web address) nothing you typed is lost.
 */
export function PostEditor({
  post,
  categories,
  authors,
  currentUserId,
  siteUrl,
}: {
  post?: AdminPost;
  categories: Category[];
  authors: { id: string; full_name: string }[];
  currentUserId: string;
  siteUrl: string;
}) {
  const [state, formAction] = useActionState(savePostAction, initialState);

  const [title, setTitle] = useState(post?.title ?? "");
  const [slug, setSlug] = useState(post?.slug ?? "");
  const [slugTouched, setSlugTouched] = useState(Boolean(post));
  const [excerpt, setExcerpt] = useState(post?.excerpt ?? "");
  const [content, setContent] = useState(post?.content ?? "");
  const [categoryId, setCategoryId] = useState(post?.category_id ?? "");
  const [authorId, setAuthorId] = useState(post?.author_id ?? currentUserId);
  const [tags, setTags] = useState((post?.tags ?? []).join(", "));
  const [isFeatured, setIsFeatured] = useState(post?.is_featured ?? false);
  const [featuredImage, setFeaturedImage] = useState(post?.featured_image ?? "");
  const [featuredAlt, setFeaturedAlt] = useState(post?.featured_image_alt ?? "");
  const [socialImage, setSocialImage] = useState(post?.social_image ?? "");
  const [seoTitle, setSeoTitle] = useState(post?.seo_title ?? "");
  const [seoDescription, setSeoDescription] = useState(post?.seo_description ?? "");

  const status = post?.status ?? "draft";
  const isNew = !post;

  return (
    <form action={formAction} className="pb-24">
      {post ? <input type="hidden" name="id" value={post.id} /> : null}
      <input type="hidden" name="content" value={content} />

      {state.error ? (
        <div role="alert" className="mb-6 rounded-xl border border-danger/40 bg-danger/10 p-4 text-[0.9375rem] text-fg">
          {state.error}
        </div>
      ) : null}

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_20rem] xl:grid-cols-[minmax(0,1fr)_22rem]">
        <div className="min-w-0 space-y-6">
          <Panel>
            <div className="space-y-5">
              <Field label="Title" htmlFor="title">
                <input
                  id="title"
                  name="title"
                  required
                  minLength={3}
                  maxLength={200}
                  value={title}
                  onChange={(e) => {
                    setTitle(e.target.value);
                    if (!slugTouched) setSlug(slugify(e.target.value));
                  }}
                  className={inputClass}
                />
              </Field>

              <Field
                label="Web address (slug)"
                htmlFor="slug"
                hint={`The article will live at ${siteUrl}/news/${slug || "your-slug"}`}
              >
                <input
                  id="slug"
                  name="slug"
                  maxLength={120}
                  value={slug}
                  onChange={(e) => {
                    setSlugTouched(true);
                    setSlug(slugify(e.target.value, 120));
                  }}
                  className={inputClass}
                />
              </Field>

              <Field label="Excerpt" htmlFor="excerpt" hint={`Shown on article cards and search results. ${excerpt.length}/300. Leave empty to use the opening of the article.`}>
                <textarea id="excerpt" name="excerpt" rows={3} maxLength={300} value={excerpt} onChange={(e) => setExcerpt(e.target.value)} className={inputClass} />
              </Field>
            </div>
          </Panel>

          <div>
            <p className="mb-1.5 text-sm font-semibold text-fg">Article</p>
            <RichTextEditor initialHtml={post?.content ?? ""} onChange={setContent} />
          </div>
        </div>

        <div className="min-w-0 space-y-6">
          <Panel title="Status">
            <div className="flex flex-wrap items-center gap-3">
              <StatusPill status={status} />
              {post?.status === "published" ? (
                <Link href={`/news/${post.slug}`} target="_blank" rel="noopener" className="inline-flex min-h-11 items-center gap-1.5 text-sm font-semibold text-brand-light underline underline-offset-4">
                  View article
                  <ExternalLink aria-hidden="true" className="h-4 w-4" />
                  <span className="sr-only">(opens in a new tab)</span>
                </Link>
              ) : null}
            </div>
            <p className="mt-3 text-sm text-fg-3">
              {status === "published" ? "This article is live on the website." : "Only published articles are visible to visitors."}
            </p>
          </Panel>

          <Panel title="Details">
            <div className="space-y-5">
              <Field label="Category" htmlFor="category_id">
                <select id="category_id" name="category_id" value={categoryId} onChange={(e) => setCategoryId(e.target.value)} className={inputClass}>
                  <option value="">No category</option>
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Author" htmlFor="author_id">
                <select id="author_id" name="author_id" value={authorId} onChange={(e) => setAuthorId(e.target.value)} className={inputClass}>
                  {authors.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.full_name}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Tags" htmlFor="tags" hint="Separate with commas. Up to 10.">
                <input id="tags" name="tags" value={tags} onChange={(e) => setTags(e.target.value)} className={inputClass} />
              </Field>
              <label className="flex min-h-11 items-center gap-3 text-[0.9375rem] text-fg">
                <input type="checkbox" name="is_featured" checked={isFeatured} onChange={(e) => setIsFeatured(e.target.checked)} className="h-5 w-5 accent-brand" />
                Feature this article at the top of News &amp; Insights
              </label>
            </div>
          </Panel>

          <Panel title="Featured image">
            <ImageField
              label="Shown on the article and its card"
              name="featured_image"
              value={featuredImage}
              onChange={setFeaturedImage}
              alt={featuredAlt}
              onAltChange={setFeaturedAlt}
              altName="featured_image_alt"
            />
          </Panel>

          <Panel title="Search and sharing (SEO)">
            <div className="space-y-5">
              <Field label="SEO title" htmlFor="seo_title" hint={`${seoTitle.length}/70. Leave empty to use the article title.`}>
                <input id="seo_title" name="seo_title" maxLength={70} value={seoTitle} onChange={(e) => setSeoTitle(e.target.value)} className={inputClass} />
              </Field>
              <Field label="SEO description" htmlFor="seo_description" hint={`${seoDescription.length}/200. About 150 characters works best. Leave empty to use the excerpt.`}>
                <textarea id="seo_description" name="seo_description" rows={3} maxLength={200} value={seoDescription} onChange={(e) => setSeoDescription(e.target.value)} className={inputClass} />
              </Field>
              <ImageField
                label="Social image"
                name="social_image"
                value={socialImage}
                onChange={setSocialImage}
                hint="Shown when the link is shared. Leave empty to use the featured image."
              />
            </div>
          </Panel>
        </div>
      </div>

      {/* Stays at the bottom of the screen so the buttons are always in reach on a phone. */}
      <div className="fixed inset-x-0 bottom-0 z-30 border-t border-brand/20 bg-navy/95 px-4 py-3 backdrop-blur lg:left-auto lg:right-0 lg:border-l lg:px-6" style={{ paddingBottom: "max(0.75rem, env(safe-area-inset-bottom))" }}>
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-end gap-2">
          {status === "published" ? (
            <>
              <SubmitButton name="intent" value="save" pendingLabel="Saving…">Save changes</SubmitButton>
              <SubmitButton name="intent" value="unpublish" variant="secondary" confirm="Unpublish this article? It will disappear from the website.">Unpublish</SubmitButton>
            </>
          ) : (
            <>
              <SubmitButton name="intent" value={isNew ? "draft" : "save"} variant="secondary" pendingLabel="Saving…">Save draft</SubmitButton>
              <SubmitButton name="intent" value="publish" pendingLabel="Publishing…">Publish</SubmitButton>
            </>
          )}
          {post && status !== "archived" ? (
            <SubmitButton name="intent" value="archive" variant="secondary" confirm="Archive this article? It will not be public.">Archive</SubmitButton>
          ) : null}
        </div>
      </div>
    </form>
  );
}
