"use client";

import { useId, useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2, Upload } from "lucide-react";
import { inputClass } from "@/components/admin/ui";
import { uploadImage } from "@/lib/client/image-upload";
import type { MediaItem } from "@/lib/cms/types";

/** Choose or take a photo, shrink it in the browser, upload it. Works with the Android camera and gallery. */
export function MediaUploader({ onUploaded }: { onUploaded?: (item: MediaItem) => void }) {
  const router = useRouter();
  const inputId = useId();
  const altId = useId();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [alt, setAlt] = useState("");

  async function onFile(files: FileList | null) {
    const file = files?.[0];
    if (!file) return;
    setBusy(true);
    setError(null);
    const result = await uploadImage(file, alt);
    setBusy(false);
    if (!result.ok) {
      setError(result.error);
      return;
    }
    setAlt("");
    if (onUploaded) onUploaded(result.item);
    else router.refresh();
  }

  return (
    <div className="space-y-3">
      <div>
        <label htmlFor={altId} className="mb-1.5 block text-sm font-semibold text-fg">
          Describe the image (alt text, recommended)
        </label>
        <input id={altId} value={alt} onChange={(e) => setAlt(e.target.value)} maxLength={200} className={inputClass} />
      </div>
      <div>
        <input
          id={inputId}
          type="file"
          accept="image/*"
          disabled={busy}
          className="peer sr-only"
          onChange={(e) => {
            void onFile(e.target.files);
            e.target.value = "";
          }}
        />
        <label
          htmlFor={inputId}
          className="inline-flex min-h-12 cursor-pointer items-center gap-2 rounded-lg bg-brand px-5 font-semibold text-navy transition-colors hover:bg-brand-light peer-focus-visible:outline peer-focus-visible:outline-2 peer-focus-visible:outline-offset-2 peer-focus-visible:outline-brand-light peer-disabled:opacity-60"
        >
          {busy ? <Loader2 aria-hidden="true" className="h-5 w-5 animate-spin" /> : <Upload aria-hidden="true" className="h-5 w-5" />}
          {busy ? "Uploading…" : "Upload an image"}
        </label>
      </div>
      <p className="text-sm text-fg-3">JPEG, PNG or WebP. Large photos are shrunk automatically before upload.</p>
      {error ? (
        <p role="alert" className="rounded-lg border border-danger/40 bg-danger/10 p-3 text-sm text-fg">
          {error}
        </p>
      ) : null}
    </div>
  );
}
