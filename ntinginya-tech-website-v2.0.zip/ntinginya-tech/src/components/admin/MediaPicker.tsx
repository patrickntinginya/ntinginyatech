/* eslint-disable @next/next/no-img-element */
"use client";

import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { X } from "lucide-react";
import { MediaUploader } from "@/components/admin/MediaUploader";
import { inputClass } from "@/components/admin/ui";
import { listMediaAction } from "@/app/admin/actions/media";
import type { MediaItem } from "@/lib/cms/types";

/** A pop-up library of uploaded images. Tap one to use it, or upload a new one. */
export function MediaPicker({ open, onClose, onSelect }: { open: boolean; onClose: () => void; onSelect: (item: MediaItem) => void }) {
  const [q, setQ] = useState("");
  const [items, setItems] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [failed, setFailed] = useState(false);
  const [reload, setReload] = useState(0);

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    setLoading(true);
    setFailed(false);
    const timer = setTimeout(async () => {
      try {
        const rows = await listMediaAction(q);
        if (!cancelled) setItems(rows);
      } catch {
        if (!cancelled) setFailed(true);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }, 250);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [open, q, reload]);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    document.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = previous;
      document.removeEventListener("keydown", onKey);
    };
  }, [open, onClose]);

  if (!open) return null;

  // Rendered outside the page's <form>, so pressing Enter in the search box can never submit the post.
  return createPortal(
    <div className="fixed inset-0 z-[80] flex items-end justify-center bg-black/70 sm:items-center sm:p-6" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="media-picker-title"
        className="max-h-[92vh] w-full overflow-y-auto rounded-t-2xl border border-brand/20 bg-card p-4 shadow-card sm:max-w-3xl sm:rounded-2xl sm:p-6"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="flex items-center justify-between gap-3">
          <h2 id="media-picker-title" className="text-lg font-semibold text-fg">
            Choose an image
          </h2>
          <button type="button" onClick={onClose} aria-label="Close" className="grid h-11 w-11 place-items-center rounded-lg border border-fg-3/40 text-fg hover:border-brand-light">
            <X aria-hidden="true" className="h-5 w-5" />
          </button>
        </div>

        <div className="mt-4 rounded-xl border border-fg-3/20 p-4">
          <MediaUploader
            onUploaded={(item) => {
              setItems((current) => [item, ...current]);
              setReload((n) => n + 1);
            }}
          />
        </div>

        <label htmlFor="media-search" className="mt-6 mb-1.5 block text-sm font-semibold text-fg">
          Search your images
        </label>
        <input id="media-search" type="search" value={q} onChange={(e) => setQ(e.target.value)} className={inputClass} />

        <div className="mt-5" aria-live="polite">
          {loading ? <p className="text-sm text-fg-3">Loading images…</p> : null}
          {failed ? <p role="alert" className="text-sm text-danger">The images could not be loaded. Please try again.</p> : null}
          {!loading && !failed && items.length === 0 ? <p className="text-sm text-fg-2">No images yet. Upload one above.</p> : null}
        </div>

        <ul className="mt-2 grid grid-cols-2 gap-3 sm:grid-cols-3">
          {items.map((item) => (
            <li key={item.id}>
              <button
                type="button"
                onClick={() => onSelect(item)}
                className="group block w-full overflow-hidden rounded-xl border border-fg-3/25 bg-navy text-left hover:border-brand-light"
              >
                <img src={item.url} alt={item.alt ?? ""} loading="lazy" className="aspect-[4/3] w-full object-cover" />
                <span className="block truncate px-2.5 py-2 text-xs text-fg-2 group-hover:text-fg">{item.filename}</span>
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>,
    document.body,
  );
}
