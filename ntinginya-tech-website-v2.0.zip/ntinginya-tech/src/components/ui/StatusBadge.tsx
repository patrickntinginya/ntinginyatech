import { cn } from "@/lib/cn";
import type { StatusKey } from "@/content/types";

const styles = {
  live: "bg-brand text-navy",
  mvp: "bg-info text-navy",
  "in-development": "border border-info/60 bg-info/10 text-info",
  proposed: "border border-dashed border-fg-3/60 text-fg-2",
  future: "border border-fg-3/50 text-fg",
} as const;

const config: Record<StatusKey, { label: string; light: string; dark: string }> = {
  live: { label: "LIVE", light: styles.live, dark: styles.live },
  mvp: { label: "MVP", light: styles.mvp, dark: styles.mvp },
  "in-development": { label: "IN DEVELOPMENT", light: styles["in-development"], dark: styles["in-development"] },
  proposed: { label: "PROPOSED", light: styles.proposed, dark: styles.proposed },
  future: { label: "FUTURE", light: styles.future, dark: styles.future },
};

export function StatusBadge({
  status,
  tone = "light",
  className,
}: {
  status: StatusKey;
  tone?: "light" | "dark";
  className?: string;
}) {
  const item = config[status];
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-md px-2 py-1 font-sans text-[0.6875rem] font-semibold leading-none tracking-wider",
        item[tone],
        className,
      )}
    >
      {item.label}
    </span>
  );
}

export function StatusBadges({
  statuses,
  tone,
  className,
}: {
  statuses: StatusKey[];
  tone?: "light" | "dark";
  className?: string;
}) {
  return (
    <div className={cn("flex flex-wrap items-center gap-2", className)}>
      {statuses.map((s) => (
        <StatusBadge key={s} status={s} tone={tone} />
      ))}
    </div>
  );
}
