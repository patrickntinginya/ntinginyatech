import type { ReactNode } from "react";
import { cn } from "@/lib/cn";
import { Container } from "./Container";

export type SectionTone = "mist" | "paper" | "deep" | "field";

// Deep navy dominates. Bands alternate so long pages have rhythm without adding colours.
const tones: Record<SectionTone, string> = {
  mist: "band-ink text-fg-2",
  paper: "band-navy text-fg-2",
  deep: "surface-dark band-blue text-fg-2",
  field: "surface-dark band-green text-fg-2",
};

const spacings = {
  tight: "py-16 sm:py-20",
  default: "py-20 sm:py-24 lg:py-28",
  loose: "py-24 sm:py-32 lg:py-36",
} as const;

export function Section({
  id,
  tone = "mist",
  spacing = "default",
  className,
  containerClassName,
  children,
}: {
  id?: string;
  tone?: SectionTone;
  spacing?: keyof typeof spacings;
  className?: string;
  containerClassName?: string;
  children: ReactNode;
}) {
  return (
    <section id={id} className={cn("relative scroll-mt-20", spacings[spacing], tones[tone], className)}>
      <Container className={containerClassName}>{children}</Container>
    </section>
  );
}
