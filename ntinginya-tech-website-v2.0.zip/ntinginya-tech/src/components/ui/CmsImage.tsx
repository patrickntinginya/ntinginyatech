/* eslint-disable @next/next/no-img-element */
import Image from "next/image";
import { supabaseUrl } from "@/lib/env";

function isOptimizable(src: string): boolean {
  try {
    const configured = supabaseUrl();
    return Boolean(configured) && new URL(src).host === new URL(configured).host;
  } catch {
    return false;
  }
}

/**
 * Fills its parent (which must be `relative` and have a size, e.g. an aspect ratio box).
 * Images stored in our Supabase bucket go through Next.js image optimization; any other https image
 * (for example an older link) is shown as-is so a missing configuration never breaks a page.
 */
export function CmsImage({
  src,
  alt,
  sizes,
  className = "",
  priority = false,
}: {
  src: string;
  alt: string;
  sizes: string;
  className?: string;
  priority?: boolean;
}) {
  if (isOptimizable(src)) {
    return <Image src={src} alt={alt} fill sizes={sizes} priority={priority} className={`object-cover ${className}`} />;
  }
  return (
    <img
      src={src}
      alt={alt}
      loading={priority ? "eager" : "lazy"}
      decoding="async"
      className={`absolute inset-0 h-full w-full object-cover ${className}`}
    />
  );
}
