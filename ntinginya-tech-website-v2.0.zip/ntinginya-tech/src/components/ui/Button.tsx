import Link from "next/link";
import type { ButtonHTMLAttributes, ComponentProps } from "react";
import { cn } from "@/lib/cn";

type Variant = "primary" | "secondary" | "tech" | "danger";
type Size = "md" | "lg";

const base =
  "inline-flex items-center justify-center rounded-lg text-center font-sans font-semibold transition-colors duration-200 focus-visible:outline-brand-light disabled:cursor-not-allowed disabled:opacity-60";

const variants: Record<Variant, string> = {
  // Green: primary call to action
  primary: "bg-brand text-navy hover:bg-brand-light",
  // Transparent with a subtle border
  secondary: "border border-fg-3/40 bg-transparent text-fg hover:border-brand-light hover:bg-fg/5",
  // Blue: technology / secondary emphasis
  tech: "border border-info/30 bg-navy-blue text-fg hover:bg-navy-blue/80",
  danger: "bg-danger text-white hover:bg-danger/85",
};

const sizes: Record<Size, string> = {
  md: "min-h-11 px-5 py-2.5 text-[0.9375rem]",
  lg: "min-h-12 px-6 py-3 text-base",
};

type Styling = { variant?: Variant; size?: Size; className?: string };

export function buttonStyles({ variant = "primary", size = "md", className }: Styling): string {
  return cn(base, variants[variant], sizes[size], className);
}

type ButtonLinkProps = Omit<ComponentProps<typeof Link>, "className"> & Styling;

export function ButtonLink({ variant, size, className, ...props }: ButtonLinkProps) {
  return <Link className={buttonStyles({ variant, size, className })} {...props} />;
}

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & Styling;

export function Button({ variant, size, className, type = "button", ...props }: ButtonProps) {
  return <button type={type} className={buttonStyles({ variant, size, className })} {...props} />;
}
