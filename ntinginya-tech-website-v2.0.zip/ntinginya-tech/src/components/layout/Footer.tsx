import Link from "next/link";
import { footerLinks, siteConfig } from "@/config/site";
import { Container } from "@/components/ui/Container";
import { contactLinks, getSiteSettings, socialLinks } from "@/lib/settings";
import { Logo } from "./Logo";

export async function Footer() {
  const settings = await getSiteSettings();
  const contact = contactLinks(settings);
  const socials = socialLinks(settings);

  return (
    <footer className="surface-dark border-t border-brand/15 bg-navy text-fg-2">
      <Container className="grid gap-12 py-16 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <Logo dark />
          <p className="mt-6 max-w-sm font-sans text-xl font-semibold leading-snug text-fg text-balance">{siteConfig.tagline}</p>
          <p className="mt-4 max-w-sm text-[0.9375rem] leading-relaxed text-fg-2">
            A Tanzanian technology and innovation company building practical software and applying research, education
            and technology to real problems.
          </p>
        </div>

        <nav aria-label="Footer" className="lg:col-span-4 lg:col-start-6">
          <h2 className="font-sans text-base font-semibold">Quick links</h2>
          <ul className="mt-4 grid grid-cols-2 gap-x-6 gap-y-2">
            {footerLinks.map((link) => (
              <li key={link.href}>
                <Link href={link.href} className="text-fg-2 underline-offset-4 transition-colors hover:text-brand-light hover:underline">
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div className="lg:col-span-3">
          <h2 className="font-sans text-base font-semibold">Contact</h2>
          <ul className="mt-4 space-y-2 text-fg-2">
            <li>
              <a href={contact.mailto} className="break-all underline-offset-4 hover:text-brand-light hover:underline">
                {contact.email}
              </a>
            </li>
            <li>
              <a href={contact.phoneHref} className="underline-offset-4 hover:text-brand-light hover:underline">
                {contact.phone}
              </a>
            </li>
            <li>
              <a
                href={contact.whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className="underline-offset-4 hover:text-brand-light hover:underline"
              >
                WhatsApp<span className="sr-only"> (opens in a new tab)</span>
              </a>
            </li>
            <li>{contact.location}</li>
          </ul>
          {socials.length > 0 ? (
            <ul aria-label="Social media" className="mt-4 flex flex-wrap gap-x-4 gap-y-2">
              {socials.map((s) => (
                <li key={s.label}>
                  <a href={s.url} target="_blank" rel="noopener noreferrer" className="underline-offset-4 hover:text-brand-light hover:underline">
                    {s.label}
                    <span className="sr-only"> (opens in a new tab)</span>
                  </a>
                </li>
              ))}
            </ul>
          ) : null}
        </div>
      </Container>

      <div className="border-t border-fg-3/20">
        <Container className="flex flex-col gap-3 py-6 text-sm text-fg-3">
          <p>{siteConfig.copyright}</p>
          <p className="max-w-3xl">
            Information on this website is general and is not agricultural, veterinary, medical, legal or financial advice.
            Products marked proposed or future have not launched.
          </p>
        </Container>
      </div>
    </footer>
  );
}
