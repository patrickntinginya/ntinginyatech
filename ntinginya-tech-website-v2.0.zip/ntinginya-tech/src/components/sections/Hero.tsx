import Link from "next/link";
import { siteConfig } from "@/config/site";
import { ButtonLink } from "@/components/ui/Button";
import { Container } from "@/components/ui/Container";
import { HeroVisual } from "@/components/visuals/HeroVisual";

const majorAreas = [
  { label: "Technology", note: "Software and digital platforms", href: "/solutions" },
  { label: "Agriculture", note: "Farm and livestock technology", href: "/agriculture" },
  { label: "Innovation", note: "Global AgriTech research", href: "/innovation" },
  { label: "AI", note: "Practical AI and digital systems", href: "/solutions#ai" },
  { label: "Education", note: "Professional learning", href: "/masterclass" },
  { label: "R&D", note: "Research before building", href: "/research" },
];

export function Hero() {
  return (
    <section className="band-hero relative overflow-hidden">
      <Container className="grid items-center gap-12 pb-12 pt-12 sm:pt-16 lg:grid-cols-[1.02fr_0.98fr] lg:gap-14 lg:pb-16 lg:pt-20">
        <div className="animate-fade-up">
          <p className="flex items-center gap-3 font-sans text-sm font-semibold text-brand-light">
            <span aria-hidden="true" className="h-px w-8 bg-brand" />
            {siteConfig.name}
          </p>

          <h1 className="mt-6 font-sans text-[2.6rem] font-semibold leading-[1.02] tracking-[-0.03em] text-balance sm:text-6xl xl:text-[4.25rem]">
            Building Technology.
            <br />
            <span className="text-brand-light">Solving Real-World Problems.</span>
          </h1>

          <p className="mt-6 max-w-xl text-lg leading-relaxed text-fg-2 text-pretty sm:text-xl sm:leading-relaxed">
            We design and develop practical technology, digital platforms and innovation systems for businesses,
            agriculture, education and other real-world challenges.
          </p>

          <div className="mt-9 flex flex-col gap-3 sm:flex-row">
            <ButtonLink href="/solutions" variant="primary" size="lg">
              Explore Solutions
            </ButtonLink>
            <ButtonLink href="/contact" variant="secondary" size="lg">
              Work With Us
            </ButtonLink>
          </div>

          <p className="mt-10 max-w-md border-l-2 border-brand pl-4 text-[0.9375rem] leading-relaxed text-fg-2">
            <span className="font-sans font-semibold text-fg">Where we are today:</span> Ntinginya Tech is an
            emerging company. Our first product, Ntinginya Business Manager, is an MVP in development. Everything else
            on this site is labelled proposed or future.
          </p>
        </div>

        <div className="mx-auto w-full max-w-[34rem] animate-fade-in [animation-delay:150ms] lg:max-w-none">
          <HeroVisual />
        </div>
      </Container>

      <Container className="pb-14">
        <nav aria-label="Major areas" className="border-t border-fg-3/20 pt-6">
          <ul className="grid grid-cols-2 gap-x-6 gap-y-5 sm:grid-cols-3 lg:grid-cols-6">
            {majorAreas.map((area) => (
              <li key={area.label}>
                <Link href={area.href} className="group block rounded-md">
                  <span className="block font-sans text-base font-semibold text-fg underline-offset-4 group-hover:underline">
                    {area.label}
                  </span>
                  <span className="mt-0.5 block text-sm leading-snug text-fg-2">{area.note}</span>
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </Container>
    </section>
  );
}
