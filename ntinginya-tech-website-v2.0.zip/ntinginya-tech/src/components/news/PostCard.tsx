import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { CmsImage } from "@/components/ui/CmsImage";
import { formatDate } from "@/lib/format";
import type { PostCard as Post } from "@/lib/cms/types";

/** Shown when a post has no featured image: a quiet navy panel, never a fake photo. */
function ImagePlaceholder() {
  return (
    <div aria-hidden="true" className="absolute inset-0 bg-gradient-to-br from-navy-blue/50 via-navy to-ink">
      <div className="absolute -right-8 -top-8 h-40 w-40 rounded-full border border-brand/20" />
      <div className="absolute -right-2 top-2 h-24 w-24 rounded-full border border-brand/20" />
    </div>
  );
}

export function PostCard({ post, priority = false }: { post: Post; priority?: boolean }) {
  return (
    <article className="card-surface card-hover group relative flex h-full flex-col overflow-hidden">
      <div className="relative aspect-[16/9] overflow-hidden bg-navy">
        {post.featured_image ? (
          <CmsImage
            src={post.featured_image}
            alt={post.featured_image_alt ?? ""}
            sizes="(min-width: 1024px) 384px, (min-width: 640px) 50vw, 100vw"
            priority={priority}
            className="transition-transform duration-500 group-hover:scale-[1.03]"
          />
        ) : (
          <ImagePlaceholder />
        )}
      </div>

      <div className="flex flex-1 flex-col p-5 sm:p-6">
        {post.category ? (
          <p className="font-sans text-xs font-semibold uppercase tracking-wider text-brand-light">{post.category.name}</p>
        ) : null}
        <h3 className="mt-2 font-sans text-xl font-semibold leading-snug tracking-tight text-fg text-balance">
          {/* The ::after makes the whole card clickable while keeping a single, accessible link. */}
          <Link href={`/news/${post.slug}`} className="after:absolute after:inset-0 after:content-['']">
            {post.title}
          </Link>
        </h3>
        {post.excerpt ? <p className="mt-3 line-clamp-3 text-[0.9375rem] leading-relaxed text-fg-2">{post.excerpt}</p> : null}

        <div className="mt-auto pt-5">
          <p className="text-sm text-fg-3">
            {post.published_at ? <time dateTime={post.published_at}>{formatDate(post.published_at)}</time> : null}
            {post.author?.full_name ? <span> · {post.author.full_name}</span> : null}
          </p>
          <p className="mt-3 inline-flex items-center gap-1.5 font-sans text-[0.9375rem] font-semibold text-brand-light">
            Read Article
            <ArrowRight aria-hidden="true" className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
            <span className="sr-only">: {post.title}</span>
          </p>
        </div>
      </div>
    </article>
  );
}

export function FeaturedPostCard({ post }: { post: Post }) {
  return (
    <article className="card-surface card-hover group relative grid overflow-hidden lg:grid-cols-2">
      <div className="relative aspect-[16/10] overflow-hidden bg-navy lg:aspect-auto lg:min-h-80">
        {post.featured_image ? (
          <CmsImage
            src={post.featured_image}
            alt={post.featured_image_alt ?? ""}
            sizes="(min-width: 1024px) 560px, 100vw"
            priority
            className="transition-transform duration-500 group-hover:scale-[1.03]"
          />
        ) : (
          <ImagePlaceholder />
        )}
      </div>
      <div className="flex flex-col justify-center p-6 sm:p-10">
        <p className="font-sans text-xs font-semibold uppercase tracking-wider text-brand-light">
          Featured{post.category ? ` · ${post.category.name}` : ""}
        </p>
        <h2 className="mt-3 font-sans text-2xl font-semibold leading-tight tracking-tight text-fg text-balance sm:text-3xl">
          <Link href={`/news/${post.slug}`} className="after:absolute after:inset-0 after:content-['']">
            {post.title}
          </Link>
        </h2>
        {post.excerpt ? <p className="mt-4 text-base leading-relaxed text-fg-2">{post.excerpt}</p> : null}
        <p className="mt-5 text-sm text-fg-3">
          {post.published_at ? <time dateTime={post.published_at}>{formatDate(post.published_at)}</time> : null}
          {post.author?.full_name ? <span> · {post.author.full_name}</span> : null}
        </p>
        <p className="mt-5 inline-flex items-center gap-1.5 font-sans font-semibold text-brand-light">
          Read Article
          <ArrowRight aria-hidden="true" className="h-4 w-4" />
        </p>
      </div>
    </article>
  );
}
