-- =====================================================================
-- Ntinginya Tech CMS: database schema, security rules and storage bucket
-- Run this ONCE in the Supabase SQL Editor (Dashboard > SQL Editor > New query).
-- It is safe to run again: every statement is idempotent.
-- =====================================================================

-- ---------- Tables -------------------------------------------------------

create table if not exists public.profiles (
  id          uuid primary key references auth.users (id) on delete cascade,
  full_name   text not null default '',
  role        text not null default 'author' check (role in ('owner', 'admin', 'editor', 'author')),
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table if not exists public.categories (
  id          uuid primary key default gen_random_uuid(),
  name        text not null check (char_length(name) between 2 and 80),
  slug        text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  description text,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table if not exists public.tags (
  id          uuid primary key default gen_random_uuid(),
  name        text not null check (char_length(name) between 1 and 60),
  slug        text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  created_at  timestamptz not null default now()
);

create table if not exists public.posts (
  id                 uuid primary key default gen_random_uuid(),
  title              text not null check (char_length(title) between 3 and 200),
  slug               text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  excerpt            text,
  content            text not null default '',
  featured_image     text,
  featured_image_alt text,
  category_id        uuid references public.categories (id) on delete set null,
  author_id          uuid references public.profiles (id) on delete set null,
  status             text not null default 'draft' check (status in ('draft', 'published', 'archived')),
  is_featured        boolean not null default false,
  published_at       timestamptz,
  seo_title          text,
  seo_description    text,
  social_image       text,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now(),
  constraint published_needs_date check (status <> 'published' or published_at is not null)
);

create table if not exists public.post_tags (
  post_id uuid not null references public.posts (id) on delete cascade,
  tag_id  uuid not null references public.tags (id) on delete cascade,
  primary key (post_id, tag_id)
);

create table if not exists public.media (
  id          uuid primary key default gen_random_uuid(),
  path        text not null unique,
  url         text not null,
  filename    text not null,
  alt         text,
  mime_type   text not null,
  size_bytes  integer not null,
  width       integer,
  height      integer,
  uploaded_by uuid references public.profiles (id) on delete set null,
  created_at  timestamptz not null default now()
);

create table if not exists public.contact_messages (
  id            uuid primary key default gen_random_uuid(),
  name          text not null,
  email         text not null,
  phone         text,
  inquiry_type  text,
  subject       text not null,
  message       text not null,
  status        text not null default 'unread' check (status in ('unread', 'read')),
  -- Did the notification email reach Resend? Lets the owner spot email problems from the dashboard.
  email_status  text not null default 'not_sent' check (email_status in ('sent', 'failed', 'not_configured', 'not_sent')),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create table if not exists public.site_settings (
  key         text primary key,
  value       jsonb not null,
  updated_at  timestamptz not null default now(),
  updated_by  uuid references public.profiles (id) on delete set null
);

create table if not exists public.activity_logs (
  id           bigint generated always as identity primary key,
  user_id      uuid references public.profiles (id) on delete set null,
  user_label   text,
  action       text not null,
  target_type  text,
  target_id    text,
  target_label text,
  meta         jsonb,
  created_at   timestamptz not null default now()
);

-- ---------- Indexes ------------------------------------------------------

create index if not exists posts_status_published_idx on public.posts (status, published_at desc);
create index if not exists posts_category_idx         on public.posts (category_id);
create index if not exists messages_status_idx        on public.contact_messages (status, created_at desc);
create index if not exists media_created_idx          on public.media (created_at desc);
create index if not exists activity_created_idx       on public.activity_logs (created_at desc);

-- ---------- Triggers -----------------------------------------------------

create or replace function public.set_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

do $$
declare t text;
begin
  foreach t in array array['profiles', 'categories', 'posts', 'contact_messages', 'site_settings'] loop
    execute format('drop trigger if exists set_updated_at on public.%I', t);
    execute format('create trigger set_updated_at before update on public.%I for each row execute function public.set_updated_at()', t);
  end loop;
end $$;

-- Every new auth user gets a profile with the LOWEST role ("author").
-- Nobody becomes an admin automatically: the owner is promoted with the SQL in docs/CMS_SETUP.md.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name, role)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'full_name', split_part(new.email, '@', 1)), 'author')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- Helper used by the security rules ----------------------------

create or replace function public.is_staff() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and is_active and role in ('owner', 'admin')
  );
$$;

-- ---------- Row Level Security -------------------------------------------
-- RLS is ON for every table. With no matching policy, access is denied.
-- The website's server code also uses the service-role key for admin work, but only after
-- checking that the signed-in user is an active owner/admin.

alter table public.profiles          enable row level security;
alter table public.categories        enable row level security;
alter table public.tags              enable row level security;
alter table public.posts             enable row level security;
alter table public.post_tags         enable row level security;
alter table public.media             enable row level security;
alter table public.contact_messages  enable row level security;
alter table public.site_settings     enable row level security;
alter table public.activity_logs     enable row level security;

-- Visitors (anon) may read ONLY published content.
drop policy if exists "public reads published posts" on public.posts;
create policy "public reads published posts" on public.posts
  for select to anon, authenticated
  using (status = 'published' and published_at <= now());

drop policy if exists "staff manage posts" on public.posts;
create policy "staff manage posts" on public.posts
  for all to authenticated using (public.is_staff()) with check (public.is_staff());

drop policy if exists "public reads categories" on public.categories;
create policy "public reads categories" on public.categories
  for select to anon, authenticated using (true);
drop policy if exists "staff manage categories" on public.categories;
create policy "staff manage categories" on public.categories
  for all to authenticated using (public.is_staff()) with check (public.is_staff());

drop policy if exists "public reads tags" on public.tags;
create policy "public reads tags" on public.tags
  for select to anon, authenticated using (true);
drop policy if exists "staff manage tags" on public.tags;
create policy "staff manage tags" on public.tags
  for all to authenticated using (public.is_staff()) with check (public.is_staff());

drop policy if exists "public reads tags of published posts" on public.post_tags;
create policy "public reads tags of published posts" on public.post_tags
  for select to anon, authenticated
  using (exists (
    select 1 from public.posts p
    where p.id = post_id and p.status = 'published' and p.published_at <= now()
  ));
drop policy if exists "staff manage post tags" on public.post_tags;
create policy "staff manage post tags" on public.post_tags
  for all to authenticated using (public.is_staff()) with check (public.is_staff());

-- Author names are shown on articles. Visitors can read ONLY id and full_name (column-level grant below).
drop policy if exists "public reads author names" on public.profiles;
create policy "public reads author names" on public.profiles
  for select to anon using (true);
drop policy if exists "staff read profiles" on public.profiles;
create policy "staff read profiles" on public.profiles
  for select to authenticated using (public.is_staff() or id = auth.uid());

-- Media, messages and the activity log are private: staff only.
drop policy if exists "staff manage media" on public.media;
create policy "staff manage media" on public.media
  for all to authenticated using (public.is_staff()) with check (public.is_staff());

-- No INSERT policy on contact_messages: messages can only be written by the server (service role),
-- so nobody can flood the table straight from a browser.
drop policy if exists "staff read messages" on public.contact_messages;
create policy "staff read messages" on public.contact_messages
  for select to authenticated using (public.is_staff());
drop policy if exists "staff update messages" on public.contact_messages;
create policy "staff update messages" on public.contact_messages
  for update to authenticated using (public.is_staff()) with check (public.is_staff());
drop policy if exists "staff delete messages" on public.contact_messages;
create policy "staff delete messages" on public.contact_messages
  for delete to authenticated using (public.is_staff());

-- Settings hold public information only (contact details, SEO text). Never store secrets here.
drop policy if exists "public reads settings" on public.site_settings;
create policy "public reads settings" on public.site_settings
  for select to anon, authenticated using (true);
drop policy if exists "staff manage settings" on public.site_settings;
create policy "staff manage settings" on public.site_settings
  for all to authenticated using (public.is_staff()) with check (public.is_staff());

drop policy if exists "staff read activity" on public.activity_logs;
create policy "staff read activity" on public.activity_logs
  for select to authenticated using (public.is_staff());

-- Column and table level hardening for the anonymous (public) role.
revoke all on public.media, public.contact_messages, public.activity_logs from anon;
revoke select on public.profiles from anon;
grant select (id, full_name) on public.profiles to anon;

-- ---------- Storage bucket for images ------------------------------------
-- Public bucket: anyone can VIEW images by URL. Only the server can upload or delete.

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('media', 'media', true, 5242880, array['image/webp', 'image/jpeg', 'image/png'])
on conflict (id) do update
  set public = true, file_size_limit = 5242880, allowed_mime_types = array['image/webp', 'image/jpeg', 'image/png'];

-- ---------- Starter categories -------------------------------------------

insert into public.categories (name, slug) values
  ('Technology', 'technology'),
  ('Software & Digital Solutions', 'software-digital-solutions'),
  ('AI & Digital Innovation', 'ai-digital-innovation'),
  ('Agriculture & Livestock', 'agriculture-livestock'),
  ('Global AgriTech Innovation', 'global-agritech-innovation'),
  ('Research & Innovation', 'research-innovation'),
  ('Education & Masterclass', 'education-masterclass'),
  ('Ntinginya Tech Updates', 'ntinginya-tech-updates')
on conflict (slug) do nothing;
