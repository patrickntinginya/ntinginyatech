-- OPTIONAL. Creates the first test article as a DRAFT so you can practise publishing it from /admin.
-- Run it in the Supabase SQL Editor AFTER schema.sql and AFTER you have promoted your owner account.
insert into public.posts (title, slug, excerpt, content, category_id, author_id, status)
select
  'Welcome to Ntinginya Tech News & Insights',
  'welcome-to-ntinginya-tech-news-and-insights',
  'What we will share here: practical technology, research notes and honest progress updates from Ntinginya Tech.',
  '<p>Welcome to Ntinginya Tech News &amp; Insights.</p><p>This is where we will share practical technology ideas, research notes and honest updates on what we are building. We are an emerging Tanzanian technology and innovation company, and we would rather show real progress than make big promises.</p><h2>What to expect</h2><ul><li>Notes on software and digital solutions</li><li>Research on agriculture and livestock technology</li><li>Updates on our products, clearly labelled by status</li></ul>',
  (select id from public.categories where slug = 'ntinginya-tech-updates'),
  (select id from public.profiles where role = 'owner' order by created_at limit 1),
  'draft'
where not exists (select 1 from public.posts where slug = 'welcome-to-ntinginya-tech-news-and-insights');
